/**
 * Create A modified notification
 */

// Success Notification 
function show_notification0(Msg){  
        apex.message.showPageSuccess(Msg); 
        $('#t_Alert_Success').attr('style','background-color: #497620;');
        $('.t-Alert-title').attr('style','color: white;font-weight: bold;');
        $('#t_Alert_Success div div.t-Alert-icon span').removeClass('t-Icon').addClass('fa fa-check fa-2x fa-anim-flash');
        $('#t_Alert_Success  div div.t-Alert-icon span').attr('style','color: white');
}

// Alert Notification
function show_Alert(Msg){  
        apex.message.showErrors([
    {
        type:       "error",
        location:   [ "page" ],
        message:    Msg,
        unsafe:     false
    }
        ]); 
        $('#t_Alert_Notification').attr('style','background-color: #FFB929;');
        $('.a-Notification-title').attr('style','color: #3A3632 ;font-weight: bold;');
        $('.a-Notification-title').text("Oops, hold on! ");
        $('.a-Notification-list').attr('style', 'list-style-type : none');
        $('.a-Notification-item').attr('style', 'color: #3A3632 ;font-weight: bold;');
        $('#t_Alert_Notification div div.t-Alert-icon span').removeClass('t-Icon').addClass('fa fa-hand-stop-o fa-2x fa fa-anim-vertical-shake ');
        $('#t_Alert_Notification  div div.t-Alert-icon span').attr('style','color: #3A3632');


        setTimeout(()=>apex.message.clearErrors(), 15000);
}