prompt --application/shared_components/files/navigation_style_min_css
begin
--   Manifest
--     APP STATIC FILES: 214711
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>6662355588643785590
,p_default_application_id=>214711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_RSWSP'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '2E61742D4E617669676174696F6E7B6D617267696E3A31323070783B666F6E742D66616D696C793A22436F7572696572204E6577222C436F75726965722C6D6F6E6F73706163657D237365617263682D6E61767B77696474683A31323070783B626F7264';
wwv_flow_imp.g_varchar2_table(2) := '65723A3130707820736F6C696420233030307D';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(20807177187490217644)
,p_file_name=>'navigation_style.min.css'
,p_mime_type=>'text/css'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
