prompt --application/shared_components/files/navigation_style_css
begin
--   Manifest
--     APP STATIC FILES: 214711
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>6662355588643785590
,p_default_application_id=>214711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_RSWSP'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '2E61742D4E617669676174696F6E7B0A202020206D617267696E3A2031323070783B0A20202020666F6E742D66616D696C793A2027436F7572696572204E6577272C20436F75726965722C206D6F6E6F73706163653B0A7D0A0A237365617263682D6E61';
wwv_flow_imp.g_varchar2_table(2) := '76207B0A2020202077696474683A2031323070783B0A20202020626F726465723A203130707820736F6C696420626C61636B3B0A7D';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(20807173457273217111)
,p_file_name=>'navigation_style.css'
,p_mime_type=>'text/css'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
