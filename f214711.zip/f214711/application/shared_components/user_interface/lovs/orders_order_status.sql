prompt --application/shared_components/user_interface/lovs/orders_order_status
begin
--   Manifest
--     ORDERS.ORDER_STATUS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>6662355588643785590
,p_default_application_id=>214711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_RSWSP'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(19472047194938505562)
,p_lov_name=>'ORDERS.ORDER_STATUS'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'ORDERS'
,p_return_column_name=>'ORDER_ID'
,p_display_column_name=>'ORDER_STATUS'
,p_default_sort_column_name=>'ORDER_STATUS'
,p_default_sort_direction=>'ASC'
);
wwv_flow_imp.component_end;
end;
/
