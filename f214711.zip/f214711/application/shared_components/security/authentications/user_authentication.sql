prompt --application/shared_components/security/authentications/user_authentication
begin
--   Manifest
--     AUTHENTICATION: User Authentication
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>6662355588643785590
,p_default_application_id=>214711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_RSWSP'
);
wwv_flow_imp_shared.create_authentication(
 p_id=>wwv_flow_imp.id(19858520399562056296)
,p_name=>'User Authentication'
,p_scheme_type=>'NATIVE_CUSTOM'
,p_attribute_03=>'user_auth'
,p_attribute_05=>'N'
,p_plsql_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'FUNCTION user_auth (p_username IN VARCHAR2, p_password IN VARCHAR2) RETURN BOOLEAN IS',
'    l_user_is_admin NUMBER := 0;',
'    l_user_is_customer NUMBER := 0;',
'    l_firstname customer.firstName%TYPE;',
'    l_lastname customer.lastName%TYPE;',
'BEGIN',
'    -- Check if the user is admin',
'    SELECT COUNT(*)',
'    INTO l_user_is_admin',
'    FROM admins',
'    WHERE lower(admin_email) = lower(p_username)',
'    AND admin_password = p_password;',
'',
'    IF(l_user_is_admin = 0) THEN',
'        -- Check if the user is customer',
'        SELECT COUNT(*)',
'        INTO l_user_is_customer',
'        FROM customer',
'        WHERE lower(email) = lower(p_username)',
'        AND password = MANAGE_CUSTOMERS.check_pw_authenticity(email, p_password, salt);',
'    END IF;',
'',
'    IF l_user_is_admin = 0 AND l_user_is_customer = 0 THEN',
'        RETURN FALSE; -- Authentication failed',
'    ELSE',
'        IF l_user_is_admin > 0 THEN',
'            SELECT admin_name,admin_id',
'                INTO :USERNAME, :USER_ID',
'                FROM admins',
'                WHERE lower(admin_email) = lower(p_username);',
'            :USER_ROLE := ''ADMIN'';',
'            RETURN TRUE; -- Authentication successful and user is an administrator',
'        ELSE',
'        ',
'            --getting customer first and last name',
'            SELECT customer_id, firstName, lastName',
'              INTO :USER_ID, l_firstname,l_lastname',
'              FROM customer',
'              WHERE lower(email) = lower(p_username);',
'            :USERNAME := l_firstname || '' '' || l_lastname;',
'',
'            --getting customer role',
'            SELECT upper(cus_type_name)',
'                INTO :USER_ROLE',
'                FROM Customer_type ct, customer c',
'                WHERE  lower(c.email) = lower(p_username)',
'                AND ct.cus_type_id = c.cus_type_id;',
'            RETURN TRUE; -- Authentication successful and user is an either a seller or buyer',
'        END IF;',
'    END IF;',
'END user_auth;',
'',
''))
,p_invalid_session_type=>'LOGIN'
,p_use_secure_cookie_yn=>'N'
,p_ras_mode=>0
);
wwv_flow_imp.component_end;
end;
/
