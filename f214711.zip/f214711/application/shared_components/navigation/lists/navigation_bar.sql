prompt --application/shared_components/navigation/lists/navigation_bar
begin
--   Manifest
--     LIST: Navigation Bar
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>6662355588643785590
,p_default_application_id=>214711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_RSWSP'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(19471989837765504361)
,p_name=>'Navigation Bar'
,p_list_status=>'PUBLIC'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(42209376227959468504)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>' '
,p_list_item_link_target=>'f?p=&APP_ID.:14:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-bell-o'
,p_list_text_01=>'&P0_USER_NOTIFICATIONS.'
,p_security_scheme=>'MUST_NOT_BE_PUBLIC_USER'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(20671959567239649839)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>' '
,p_list_item_link_target=>'f?p=&APP_ID.:19:&SESSION.::&DEBUG.:19:::'
,p_list_item_icon=>'&SHOPPING_CART_ICON.'
,p_list_text_01=>'&SHOPPING_CART_ITEMS.'
,p_list_text_02=>'js-shopping-cart-item'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(33816372477082858574)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>' '
,p_list_item_link_target=>'f?p=&APP_ID.:31:&SESSION.::&DEBUG.:31:::'
,p_list_item_icon=>'fa-heart'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(20021162835047703931)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Sign In'
,p_list_item_link_target=>'f?p=&APP_ID.:9999:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-sign-in'
,p_list_item_disp_cond_type=>'USER_IS_PUBLIC_USER'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(21467633970025320514)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Add Store'
,p_list_item_link_target=>'f?p=&APP_ID.:30:&SESSION.::&DEBUG.:30:::'
,p_list_item_icon=>'fa-plus-circle'
,p_security_scheme=>'MUST_NOT_BE_PUBLIC_USER'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(21241282232978866322)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Administration'
,p_list_item_link_target=>'f?p=&APP_ID.:10000:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-wrench'
,p_list_item_disp_cond_type=>'USER_IS_NOT_PUBLIC_USER'
,p_security_scheme=>wwv_flow_imp.id(20403697192616025455)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(19482269158832507253)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>'&USERNAME.'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-user'
,p_list_item_disp_cond_type=>'USER_IS_NOT_PUBLIC_USER'
,p_list_text_02=>'has-username'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(19482269631381507253)
,p_list_item_display_sequence=>80
,p_list_item_link_text=>'---'
,p_list_item_link_target=>'separator'
,p_list_item_disp_cond_type=>'USER_IS_NOT_PUBLIC_USER'
,p_parent_list_item_id=>wwv_flow_imp.id(19482269158832507253)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(42347342484962456805)
,p_list_item_display_sequence=>90
,p_list_item_link_text=>'My Messages'
,p_list_item_link_target=>'f?p=&APP_ID.:16:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-users-chat'
,p_parent_list_item_id=>wwv_flow_imp.id(19482269158832507253)
,p_list_text_01=>'&P0_NOTIFICATIONS.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(33812280560900789925)
,p_list_item_display_sequence=>100
,p_list_item_link_text=>'My Orders'
,p_list_item_link_target=>'f?p=&APP_ID.:13:&SESSION.::&DEBUG.:13:::'
,p_list_item_icon=>'fa-shopping-bag'
,p_parent_list_item_id=>wwv_flow_imp.id(19482269158832507253)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(20396759731919929020)
,p_list_item_display_sequence=>110
,p_list_item_link_text=>'My Stores'
,p_list_item_link_target=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-home'
,p_list_item_disp_cond_type=>'FUNCTION_BODY'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN ',
'    RETURN :USER_ROLE = ''SELLER'';',
'END;'))
,p_list_item_disp_condition2=>'PLSQL'
,p_parent_list_item_id=>wwv_flow_imp.id(19482269158832507253)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(21999325110607183114)
,p_list_item_display_sequence=>120
,p_list_item_link_text=>'Seller Dashboard'
,p_list_item_link_target=>'f?p=&APP_ID.:70:&SESSION.::&DEBUG.:70:::'
,p_list_item_icon=>'fa-dashboard'
,p_list_item_disp_cond_type=>'FUNCTION_BODY'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN ',
'    RETURN :USER_ROLE = ''SELLER'';',
'END;'))
,p_list_item_disp_condition2=>'PLSQL'
,p_parent_list_item_id=>wwv_flow_imp.id(19482269158832507253)
,p_security_scheme=>wwv_flow_imp.id(19994436662008524033)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(20395089036547413971)
,p_list_item_display_sequence=>130
,p_list_item_link_text=>'Account Settings'
,p_list_item_link_target=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.:17:::'
,p_list_item_icon=>'fa-user-wrench'
,p_parent_list_item_id=>wwv_flow_imp.id(19482269158832507253)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(42173720948844169149)
,p_list_item_display_sequence=>140
,p_list_item_link_text=>'About Us'
,p_list_item_link_target=>'f?p=&APP_ID.:9000:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-info-circle'
,p_parent_list_item_id=>wwv_flow_imp.id(19482269158832507253)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(19482270034591507254)
,p_list_item_display_sequence=>150
,p_list_item_link_text=>'Sign Out'
,p_list_item_link_target=>'&LOGOUT_URL.'
,p_list_item_icon=>'fa-sign-out'
,p_list_item_disp_cond_type=>'USER_IS_NOT_PUBLIC_USER'
,p_parent_list_item_id=>wwv_flow_imp.id(19482269158832507253)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
