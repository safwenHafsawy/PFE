prompt --application/shared_components/navigation/lists/product_update
begin
--   Manifest
--     LIST: Product Update
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>6662355588643785590
,p_default_application_id=>214711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_RSWSP'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(30346880219882947709)
,p_name=>'Product Update'
,p_list_status=>'PUBLIC'
);
wwv_flow_imp.component_end;
end;
/
