prompt --application/shared_components/navigation/lists/category_list
begin
--   Manifest
--     LIST: Category List
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>6662355588643785590
,p_default_application_id=>214711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_RSWSP'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(21230749909681782621)
,p_name=>'Category List'
,p_list_type=>'SQL_QUERY'
,p_list_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT LEVEL,',
'        category_name label,',
'        ''f?p=&APP_ID.:2:&SESSION.:::2:P2_CATEG_ID:'' || "CATEGORY_ID"  target,',
'       ''no'' is_current,',
'       null as image_value, ',
'       null as image_attr_value, ',
'       null as image_alt_value,                   ',
'      category_parent             ',
'             FROM categories                 ',
'       START WITH category_parent IS NULL',
'       CONNECT BY PRIOR category_id = category_parent',
'ORDER SIBLINGS BY category_id',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
''))
,p_list_status=>'PUBLIC'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(24536467126825578202)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Product List'
,p_list_item_link_target=>'f?p=&APP_ID.:3:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-table'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'3'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(28048505102135569209)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'dynamic_action'
,p_list_item_link_target=>'f?p=&APP_ID.:8:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-table'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'8'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(29468440307881824636)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Add Product'
,p_list_item_link_target=>'f?p=&APP_ID.:40:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-magic'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'40'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(31837226658582129529)
,p_list_item_display_sequence=>90
,p_list_item_link_text=>'Whishlist'
,p_list_item_link_target=>'f?p=&APP_ID.:31:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-table'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'31'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(33831359882228412202)
,p_list_item_display_sequence=>110
,p_list_item_link_text=>'orders'
,p_list_item_link_target=>'f?p=&APP_ID.:13:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-table'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'13'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(33838191538371159656)
,p_list_item_display_sequence=>120
,p_list_item_link_text=>'Edit Product'
,p_list_item_link_target=>'f?p=&APP_ID.:60:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-magic'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'60'
);
wwv_flow_imp.component_end;
end;
/
