prompt --application/shared_components/globalization/messages
begin
--   Manifest
--     MESSAGES: 214711
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>6662355588643785590
,p_default_application_id=>214711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_RSWSP'
);
null;
wwv_flow_imp.component_end;
end;
/
