prompt --application/shared_components/logic/application_computations/p0_order_change_list
begin
--   Manifest
--     APPLICATION COMPUTATION: P0_ORDER_CHANGE_LIST
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>6662355588643785590
,p_default_application_id=>214711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_RSWSP'
);
wwv_flow_imp_shared.create_flow_computation(
 p_id=>wwv_flow_imp.id(52746434340808861141)
,p_computation_sequence=>10
,p_computation_item=>'P0_ORDER_CHANGE_LIST'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation_processed=>'REPLACE_EXISTING'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE ',
'    l_list_of_orders VARCHAR2(4000 CHAR);',
'',
'BEGIN',
'    ',
'   SELECT LISTAGG(order_id, '', #'') WITHIN GROUP (ORDER BY order_id) ',
'        INTO l_list_of_orders',
'        FROM   orders o',
'        WHERE customer_id = to_number(:USER_ID) AND o.mutated_items = ''Yes'';',
'    return l_list_of_orders;',
'END;'))
);
wwv_flow_imp.component_end;
end;
/
