prompt --application/shared_components/logic/application_computations/app_notification_store_visites
begin
--   Manifest
--     APPLICATION COMPUTATION: APP_NOTIFICATION_STORE_VISITES
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>6662355588643785590
,p_default_application_id=>214711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_RSWSP'
);
wwv_flow_imp_shared.create_flow_computation(
 p_id=>wwv_flow_imp.id(47373525231977236522)
,p_computation_sequence=>10
,p_computation_item=>'APP_NOTIFICATION_STORE_VISITES'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation_processed=>'REPLACE_EXISTING'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
' ',
'',
'DECLARE',
'  l_count number := 0;',
'BEGIN',
'      SELECT',
'     COALESCE(SUM(CASE WHEN is_new = ''Yes'' AND customer_id != TO_NUMBER(:USER_ID) and store_id in (select store_id from stores where customer_id = to_number(:USER_ID)) THEN 1 ELSE 0 END),0)',
'     into l_count',
'     FROM CUSTOMER_STORE_VISITES ;',
'    RETURN l_count;',
'END;'))
);
wwv_flow_imp.component_end;
end;
/
