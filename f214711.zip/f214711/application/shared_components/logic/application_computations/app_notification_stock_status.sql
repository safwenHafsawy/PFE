prompt --application/shared_components/logic/application_computations/app_notification_stock_status
begin
--   Manifest
--     APPLICATION COMPUTATION: APP_NOTIFICATION_STOCK_STATUS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>6662355588643785590
,p_default_application_id=>214711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_RSWSP'
);
wwv_flow_imp_shared.create_flow_computation(
 p_id=>wwv_flow_imp.id(52776240661882908605)
,p_computation_sequence=>10
,p_computation_item=>'APP_NOTIFICATION_STOCK_STATUS'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation_processed=>'REPLACE_EXISTING'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE ',
'    l_current_status VARCHAR2(100 CHAR);',
'    l_last_status VARCHAR2(100 CHAR);',
'    l_count NUMBER := 0;',
'',
'    CURSOR c1 IS',
'        SELECT get_stock(product_id), LAST_STOCK_STATUS',
'        FROM   wishlist',
'        WHERE customer_id = to_number(:USER_ID);',
'BEGIN',
'    OPEN c1;',
'    loop',
'      fetch c1 into l_current_status, l_last_status;',
'      exit when c1%notfound;',
'',
'      if not l_current_status = l_last_status then',
'        l_count := l_count + 1;',
'      end if;',
'    end loop;',
'',
'    close c1;',
'    return l_count;',
'END; '))
);
wwv_flow_imp.component_end;
end;
/
