prompt --application/shared_components/logic/application_computations/app_notification_new_orders
begin
--   Manifest
--     APPLICATION COMPUTATION: APP_NOTIFICATION_NEW_ORDERS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>6662355588643785590
,p_default_application_id=>214711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_RSWSP'
);
wwv_flow_imp_shared.create_flow_computation(
 p_id=>wwv_flow_imp.id(52767356900000645098)
,p_computation_sequence=>10
,p_computation_item=>'APP_NOTIFICATION_NEW_ORDERS'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation_processed=>'REPLACE_EXISTING'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'  l_count NUMBER;',
'BEGIN',
'  SELECT COUNT(DISTINCT i.order_id)',
'  INTO l_count',
'  FROM order_items i',
'  INNER JOIN product p ON p.product_id = i.product_id',
'  INNER JOIN stores s ON s.store_id = p.store_id',
'  WHERE s.customer_id = (:USER_ID) AND i.is_new = ''Yes'';',
'',
'  RETURN l_count;',
'',
'END;'))
);
wwv_flow_imp.component_end;
end;
/
