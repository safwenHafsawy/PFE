prompt --application/shared_components/logic/application_items/app_notification_stock_status
begin
--   Manifest
--     APPLICATION ITEM: APP_NOTIFICATION_STOCK_STATUS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>6662355588643785590
,p_default_application_id=>214711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_RSWSP'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(49031555399496770526)
,p_name=>'APP_NOTIFICATION_STOCK_STATUS'
,p_protection_level=>'I'
);
wwv_flow_imp.component_end;
end;
/
