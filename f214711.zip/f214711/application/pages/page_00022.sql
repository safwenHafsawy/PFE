prompt --application/pages/page_00022
begin
--   Manifest
--     PAGE: 00022
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>6662355588643785590
,p_default_application_id=>214711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_RSWSP'
);
wwv_flow_imp_page.create_page(
 p_id=>22
,p_name=>'Test Search'
,p_alias=>'TEST-SEARCH'
,p_step_title=>'Test Search'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'26'
,p_last_updated_by=>'PFE94053@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20230723192915'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(42453383308044451817)
,p_plug_name=>'Search Results'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(19471806124228504263)
,p_plug_display_sequence=>20
,p_plug_source_type=>'NATIVE_SEARCH_REGION'
,p_attribute_02=>'N'
,p_attribute_04=>'Y'
,p_attribute_05=>'P22_SEARCH'
,p_attribute_06=>'N'
,p_attribute_11=>'Y'
,p_attribute_12=>'0'
,p_attribute_14=>'15'
,p_attribute_15=>'Y'
);
wwv_flow_imp_page.create_search_region_source(
 p_id=>wwv_flow_imp.id(42453383874009451818)
,p_region_id=>wwv_flow_imp.id(42453383308044451817)
,p_search_config_id=>wwv_flow_imp.id(42453370874989447827)
,p_use_as_initial_result=>false
,p_display_sequence=>10
,p_name=>'Global Search'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(42453384322529451820)
,p_name=>'P22_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(42453383308044451817)
,p_item_display_point=>'SEARCH_FIELD'
,p_prompt=>'Search'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_field_template=>wwv_flow_imp.id(19471879237081504302)
,p_item_icon_css_classes=>'fa-search'
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:t-Form-fieldContainer--large'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'SEARCH'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp.component_end;
end;
/
