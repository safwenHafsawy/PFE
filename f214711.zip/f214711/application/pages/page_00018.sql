prompt --application/pages/page_00018
begin
--   Manifest
--     PAGE: 00018
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>6662355588643785590
,p_default_application_id=>214711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_RSWSP'
);
wwv_flow_imp_page.create_page(
 p_id=>18
,p_name=>'Product Detail'
,p_alias=>'PRODUCT-DETAIL'
,p_step_title=>'&APP_NAME. - Product Details'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(function() {',
'  ''use strict'';',
'',
'  var slider = $(''#slider'');',
'  var sliderList = $(''<ul></ul>'');',
'  var bulletList = $(''<ul></ul>'');',
'  var sliderJSON = JSON.parse($v("P18_PRODUCT_SLIDER_JSON"));',
'  sliderJSON.sort(function(a, b) {',
'    return a.order - b.order;',
'  });',
'',
'  $.each(sliderJSON, function(index, element) {',
'    sliderList.append("<li><img class=''prod_image'' src=''" + element.imagePath + "'' alt=''''>");',
'    bulletList.append("<li id=''bullet_" + (index + 1) + "''></li>");',
'  });',
'',
'  sliderList.addClass(''sliderList'');',
'  bulletList.addClass(''bulletList'');',
'  slider.append(sliderList);',
'  slider.append(bulletList);',
'',
'  bulletList.find("li:first-child").addClass(''bulletActive'');',
'',
'  var firstSlide = sliderList.find("li:first-child");',
'  var lastSlide = sliderList.find("li:last-child");',
'  var buttonPrev = $(".button-prev");',
'  var buttonNext = $(".button-next");',
'  var sliderCount = sliderList.children().length;',
'  var sliderWidth = 100.0 / sliderCount;',
'  var slideIndex = 0;',
'  var intervalID;',
'',
'  lastSlide.clone().prependTo(sliderList);',
'  firstSlide.clone().appendTo(sliderList);',
'',
'  sliderList.css({ "width": (100 * sliderCount) + "%" });',
'  sliderList.css({ "margin-left": "-100%" });',
'',
'  sliderList.find("li").each(function(index) {',
'    var leftPercent = (sliderWidth * index) + "%";',
'    $(this).css({ "left": leftPercent });',
'    $(this).css({ "width": sliderWidth + "%" });',
'  });',
'',
'  buttonPrev.on(''click'', function() {',
'    slide(slideIndex - 1);',
'  });',
'',
'  buttonNext.on(''click'', function() {',
'    slide(slideIndex + 1);',
'  });',
'',
'  $(''.bulletList li'').on(''click'', function() {',
'    var id = ($(this).attr(''id'').split(''_'')[1]) - 1;',
'    slide(id);',
'  });',
'',
'  startTimer();',
'',
'  slider.on(''mouseenter mouseleave'', function(e) {',
'    var onMouEnt = (e.type === ''mouseenter'') ?',
'      clearInterval(intervalID) : startTimer();',
'  });',
'',
'  function slide(newSlideIndex) {',
'    var marginLeft = (newSlideIndex * (-100) - 100) + "%";',
'',
'    sliderList.animate({ "margin-left": marginLeft }, 400, function() {',
'      if (newSlideIndex < 0) {',
'        $(".bulletActive").removeClass(''bulletActive'');',
'        bulletList.find("li:last-child").addClass("bulletActive");',
'        sliderList.css({ "margin-left": ((sliderCount) * (-100)) + "%" });',
'        newSlideIndex = sliderCount - 1;',
'        slideIndex = newSlideIndex;',
'        return;',
'      } else if (newSlideIndex >= sliderCount) {',
'        $(".bulletActive").removeClass(''bulletActive'');',
'        bulletList.find("li:first-child").addClass("bulletActive");',
'        sliderList.css({ "margin-left": "-100%" });',
'        newSlideIndex = 0;',
'        slideIndex = newSlideIndex;',
'        return;',
'      }',
'',
'      $(".bulletActive").removeClass(''bulletActive'');',
'      bulletList.find(''li:nth-child('' + (newSlideIndex + 1) + '')'').addClass(''bulletActive'');',
'      slideIndex = newSlideIndex;',
'    });',
'  }',
'',
'  function startTimer() {',
'    intervalID = setInterval(function() { buttonNext.click(); }, 7000);',
'    return intervalID;',
'  }',
'});',
''))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(".heart").hover(function(){',
'  $(this).css("color", "#B43757");',
'  }, function(){',
'  $(this).css("color", "black");',
'});'))
,p_css_file_urls=>'#APP_FILES#Styling/main_style#MIN#.css'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.product-container {',
'  margin-bottom: 20px;',
'  border: 1px solid  var(--first-color);',
'  padding: 10px;',
'}',
'',
'.product-images-slider {',
'    border: none;',
'    box-shadow: -1px 33px 35px -13px rgba(207,193,193,0.59);',
'    -webkit-box-shadow: -1px 33px 35px -13px rgba(207,193,193,0.59);',
'    -moz-box-shadow: -1px 33px 35px -13px rgba(207,193,193,0.59);',
'}',
'',
'.product-details-container{',
'    box-shadow: -1px 33px 35px -13px rgba(207,193,193,0.59);',
'    -webkit-box-shadow: -1px 33px 35px -13px rgba(207,193,193,0.59);',
'    -moz-box-shadow: -1px 33px 35px -13px rgba(207,193,193,0.59);',
'    padding-bottom: 15px;',
'}',
'#product-name {',
'  font-weight: bold;',
'  font-family: var(--secondary-header-font);',
'}',
'',
'.product-description {',
'  margin-top: 5px;',
'  color: var(--gret-color);',
'  font-family: var(--regular-text-font);',
'  font-size: large;',
'}',
'',
'.price-header {',
'    font-family: var(--secondary-header-font);',
'    font-size: large;',
'}',
'',
'.unit-price {',
'  margin-top: 10px;',
'  padding: 10px;',
'  background-color: var(--first-color);',
'  margin: 5px;',
'  border-top: 1px solid var(--fouth-color);',
'  border-bottom: 1px solid var(--fouth-color);',
'  font-family: var(--regular-text-font);',
'}',
'',
'.old-price {',
'  text-decoration: line-through;',
'}',
'',
'.new-price {',
'  font-weight: bold;',
'}',
'',
'.save-money {',
'  padding: 5px;',
'  border-radius: 10px;',
'  color: var(--first-color);',
'  font-size: small;',
'  background-color: var(--success-color);',
'}',
'',
'#store-btn { ',
'  margin-top: 10px;',
'  width: 100%;',
'  text-align: center;',
'  border-top: 1px solid var(--fouth-color);',
'  font-family: var(--regular-text-font);',
'  font-size: medium;',
'  background-color: var(--fouth-color);',
'  border-radius: 10px;',
'  color: var(--first-color);',
'}',
'',
'#category-btn {',
'  margin-top: 10px;',
'  width: 100%;',
'  text-align: center;',
'  border-top: 1px solid var(--fouth-color);',
'  font-family: var(--regular-text-font);',
'  font-size: medium;',
'  background-color: var(--fouth-color);',
'  border-radius: 10px;',
'  color: var(--first-color);',
'}',
'',
'.variants{',
'    font-family: var(--regular-text-font);',
'}',
'',
'#P18_STOCK {',
'    background-color: var(--first-color);',
'    font-family: var(--regular-text-font);',
'}',
'',
'.out-of-stock-quantity {',
'    border-width: 2px !important;',
'    border-color: var(--danger-color) !important;',
'    color: var(--danger-color);',
'}',
'',
'.in-stock-quantity {',
'    border-width: 2px !important;',
'    border-color: var(--success-color) !important;',
'    color: var(--success-color);',
'}',
'',
'.action-container {',
'  margin-top: 10px;',
'  padding-top: 5px;',
'  border-radius: 0;',
'  border-top: 1px solid var(--fouth-color);',
'}',
'',
'.prod-qunatity {',
'  width: 100%;',
'  height: 50px;',
'  display: flex;',
'  justify-content: center;',
'  align-items: center;',
'  border-style: solid;',
'  border-color: var(--fouth-color);',
'  border-width: 2px 0 2px 0;',
'  border-radius: 0 !important;',
'}',
'',
'.quantity-btn {',
'  height: 50px;',
'  width: 100%;',
'  border-style: solid;',
'  border-color: var(--fouth-color);',
'  border-radius: 0;',
'  transition: all 100ms;',
'}',
'',
'.quantity-btn:hover {',
'    background-color: var(--fouth-color);',
'    color: var(--first-color);',
'}',
'',
'',
'#increment_quantity {',
'  border-width: 2px 2px 2px 0;',
'}',
'',
'#decrement_quantity {',
'  border-width: 2px 0 2px 2px;',
'}',
'',
'.action-btn {',
'  display: flex;',
'  justify-content: center;',
'  align-items: center;',
'  font-family: var(--secondary-header-font);',
'  font-size: large;',
'  font-weight: bold;',
'}',
'',
'.action-btn > button {',
'  border-radius: 5px;',
'}',
'',
'.action-btn > button:focus {',
'  outline: none;',
'}',
'',
'#add_wishlist_btn {',
'  background-color: var(--warning-color);',
'  color: var(--fouth-color);',
'}',
'',
'/*',
'  SLIDER',
'*/',
'',
'.slider {',
'  width: 100%;',
'  overflow: hidden;',
'  height: 550px;',
'  position: relative;',
'}',
'',
'.sliderList {',
'  position: absolute;',
'  top: 0;',
'  width: 100%;',
'  height: 100%;',
'  list-style: none;;',
'}',
'',
'.sliderList li {',
'  position: absolute;',
'  top: 0;',
'  bottom: 0;',
'  overflow: hidden;',
'  width: 100%;',
'  height: 100%;',
'  padding: 0;',
'  margin: 0;',
'}',
'',
'.sliderList li img {',
'  width: 100%;',
'  height: 100%;',
'  object-fit: contain;',
'  border: none;',
'}',
'',
'.bulletList {',
'  position: absolute;',
'  bottom: 15px;',
'  width: 100%;',
'  margin: 0px 450px;',
'  list-style: none;',
'}',
'',
'.bulletList li {',
'  display: inline-block;',
'  width: 12px;',
'  height: 12px;',
'  margin: 0 5px;',
'  -webkit-border-radius: 50%;',
'  -moz-border-radius: 50%;',
'  -ms-border-radius: 50%;',
'  border-radius: 50%;',
'  background-color: var(--first-color);',
'  cursor: pointer;',
'}',
'',
'.bulletList .bulletActive {',
'  background-color: var(--fouth-color);',
'}',
'',
'.content {',
'  position: absolute;',
'  top: 14px;',
'  left: 0;',
'  right: 0;',
'  text-align: center;',
'  font-size: 51px;',
'  color: #fff;',
'}',
'',
'.button {',
'  position: absolute;',
'  bottom: 50%;',
'  z-index: 2;',
'  display: block;',
'  width: 40px;',
'  height: 40px;',
'  box-sizing: border-box;',
'  margin: 0;',
'  padding: 0;',
'  border: none;',
'  border-radius: 50px;',
'  background-color: var(--fouth-color);',
'  color: var(--first-color);',
'}',
'',
'.button-prev {',
'  left: 15px;',
'}',
'',
'.button-next {',
'  right: 15px;',
'}',
'',
'.heart{',
'    position: absolute;',
'    top: 5px;',
'    left: 40%;',
'    background-color: transparent;',
'    filter: drop-shadow(0 0 0.5rem var(--fouth-color));',
'    transition: filter 200ms ease;',
'}',
'',
'.heart:hover,',
'.heart:focus-visible {',
'    filter: drop-shadow(0 0 0.1rem var(--danger-color));',
'}',
'',
'',
'.a-CardView-media {',
'    margin-top: 50px;',
'}',
'',
'/*Additional Info*/',
'.t-Tabs-link {',
'    font-family: var(--main-header-font);',
'}',
'',
'/*',
'    ADD NEW RATING & REVIEW',
'*/',
'.rating {',
'    padding-left: 30px !important;',
'    display: flex;',
'    flex-direction: row;',
'    justify-content: flex-start;',
'    align-items: flex-start;',
'}',
'',
'#P18_RATING_LABEL {',
'    font-size: larger;',
'    font-family: var(--secondary-header-font);',
'    color: var(--fouth-color);',
'',
'}',
'',
'.review-input {',
'    font-family: var(--regular-text-font);',
'}',
'',
'.a-StarRating-stars-fg > span {',
'    color: var(--warning-color) !important;',
'}',
'',
'',
'',
'/*',
'    LIST OF CUSTOMERS REIVEWS',
'*/',
'',
'.customer-review > li {',
'    margin: 10px;',
'    background-color: var(--second-color);',
'    padding: 15px;',
'    border-radius: 10px;',
'}',
'',
'.t-Comments-user {',
'    font-family: var(--secondary-header-font);',
'}',
'',
'.customer-rating {',
'    font-weight: bold;',
'    font-size: medium;',
'    display: flex;',
'    align-items: center;',
'    color: var(--second-color);',
'    background-color: var(--fouth-color);',
'    max-width: fit-content;',
'    padding: 5px;',
'    border-radius: 5px;',
'}',
'',
'.t-Comments-attributes {',
'    margin-top: 5px;',
'    font-family: var(--regular-text-font);',
'    color: var(--fouth-color);',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'23'
,p_last_updated_by=>'PFE94053@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20230819224149'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(22821461511976138518)
,p_plug_name=>'Customer Reviews'
,p_region_name=>'additional-informations'
,p_region_template_options=>'#DEFAULT#:js-useLocalStorage:t-TabsRegion-mod--fillLabels:t-TabsRegion-mod--simple:t-TabsRegion-mod--large:margin-top-sm'
,p_plug_template=>wwv_flow_imp.id(19471818692017504268)
,p_plug_display_sequence=>240
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(42887195006199190830)
,p_plug_name=>'Add Your Review'
,p_parent_plug_id=>wwv_flow_imp.id(22821461511976138518)
,p_region_template_options=>'#DEFAULT#:t-Region--stacked:t-Region--hiddenOverflow:margin-top-sm'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(42887195104622190831)
,p_plug_name=>'Our Customers Also Said '
,p_parent_plug_id=>wwv_flow_imp.id(22821461511976138518)
,p_region_sub_css_classes=>'customer-review'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--textContent:t-Region--scrollBody:margin-top-lg'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select REVIEW_ID,',
'       REVIEW,',
'       ''<span class="customer-rating"> ''|| RATING  || ''/5 <span class="fa fa-star" aria-hidden="true" style="margin-left: 2px;"></span></span>'' as rating,',
'       r.CUSTOMER_ID,',
'       c.firstname as customer_name,',
'       c.firstname || '' '' ||c.lastname as review_text,',
'       PRODUCT_ID',
'  from REVIEWS r',
'  left join customer c on r.CUSTOMER_ID = c.customer_id'))
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$COMMENTS'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'SET'
,p_plug_query_no_data_found=>'No Review Yet On this Products !'
,p_show_total_row_count=>false
,p_landmark_type=>'region'
,p_attribute_01=>'RATING'
,p_attribute_02=>'CUSTOMER_NAME'
,p_attribute_04=>'&REVIEW. dasdasdas'
,p_attribute_05=>'icon'
,p_attribute_09=>'fa-user'
,p_attribute_10=>'t-Avatar--rounded'
,p_attribute_11=>'Y'
,p_attribute_12=>'t-Comments--basic'
,p_attribute_13=>'Y'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(42887195246503190832)
,p_name=>'REVIEW_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'REVIEW_ID'
,p_data_type=>'NUMBER'
,p_display_sequence=>10
,p_use_as_row_header=>false
,p_is_primary_key=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(42887195353328190833)
,p_name=>'REVIEW'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'REVIEW'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(42887195417947190834)
,p_name=>'RATING'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'RATING'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(42887195560176190835)
,p_name=>'CUSTOMER_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CUSTOMER_ID'
,p_data_type=>'NUMBER'
,p_display_sequence=>40
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(42887195624079190836)
,p_name=>'PRODUCT_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PRODUCT_ID'
,p_data_type=>'NUMBER'
,p_display_sequence=>50
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(42887196345894190843)
,p_name=>'REVIEW_TEXT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'REVIEW_TEXT'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>60
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(42887196476373190844)
,p_name=>'CUSTOMER_NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CUSTOMER_NAME'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>70
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(42887196520202190845)
,p_plug_name=>'Product Description'
,p_parent_plug_id=>wwv_flow_imp.id(22821461511976138518)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--stacked:t-Region--scrollBody:margin-top-lg'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_productDesc product.product_description%TYPE;',
'BEGIN',
'    SELECT ',
'        product_description',
'    INTO',
'        l_productDesc',
'    FROM ',
'        product',
'    WHERE',
'        product_id = :P18_PRODUCT_ID;',
'    ',
'',
'    RETURN ',
'        ''<p class="product-description"> '' || l_productDesc || ''</p>'';',
'       ',
'END;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(26541545091537367337)
,p_plug_name=>'Product Details'
,p_region_css_classes=>'product-details-container'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--stacked:t-Region--hiddenOverflow:margin-top-sm:margin-bottom-sm'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>230
,p_plug_new_grid_row=>false
,p_plug_display_column=>7
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(26541544960163367336)
,p_plug_name=>'Product Details'
,p_parent_plug_id=>wwv_flow_imp.id(26541545091537367337)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>20
,p_plug_grid_column_css_classes=>'product-details'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(34869894082830248627)
,p_plug_name=>'Variants Container'
,p_parent_plug_id=>wwv_flow_imp.id(26541545091537367337)
,p_region_css_classes=>'variants-container'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(19471542261328504234)
,p_plug_display_sequence=>50
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(34869894253072248629)
,p_plug_name=>'Action-Container'
,p_parent_plug_id=>wwv_flow_imp.id(26541545091537367337)
,p_region_css_classes=>'action-container'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader js-removeLandmark:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>60
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(28046134095294995915)
,p_plug_name=>'Quantity'
,p_parent_plug_id=>wwv_flow_imp.id(34869894253072248629)
,p_region_css_classes=>'qunatity-container'
,p_region_template_options=>'#DEFAULT#:t-ItemContainer--alignCenter'
,p_plug_template=>wwv_flow_imp.id(19471801147464504260)
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>4
,p_attribute_01=>'Y'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(42887194787885190827)
,p_plug_name=>'Product name'
,p_region_name=>'product-name'
,p_parent_plug_id=>wwv_flow_imp.id(26541545091537367337)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>10
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(34869893068895248617)
,p_plug_name=>'Product Images'
,p_region_css_classes=>'product-images-slider'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noBorder:t-Region--scrollBody:margin-top-md:margin-bottom-md'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>210
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
' <div class="slider" id="slider">',
'	<button type="button" class="button button-prev">',
'		<i class="fa fa-chevron-left" aria-hidden="true"></i>',
'	</button>',
'	<button type="button" class="button button-next">',
'		<i class="fa fa-chevron-right" aria-hidden="true"></i>',
'	</button>',
'</div>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(71667913928993535014)
,p_plug_name=>'Similar Products'
,p_region_template_options=>'#DEFAULT#:t-Region--stacked:t-Region--scrollBody:margin-top-md'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>250
,p_plug_display_condition_type=>'FUNCTION_BODY'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_count number;',
'',
'begin',
'if to_number(:USER_ID) is not null then ',
'    select count(*) into v_count from customer_activity where customer_id = to_number(:USER_ID);',
'            if v_count = 0 then ',
'                    return false ;',
'            else',
'                    return true;',
'             end if;       ',
'else ',
'return false;',
'end if ;',
'end;'))
,p_plug_display_when_cond2=>'PLSQL'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(72436807694934506498)
,p_plug_name=>'Similar Products'
,p_parent_plug_id=>wwv_flow_imp.id(71667913928993535014)
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--styleC:margin-top-md'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(19471549395551504237)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT p.product_id,',
'        p.product_name,',
'        p.unit_price,',
'        discount,',
'        NEW_PRICE (P.PRODUCT_ID) new_price,',
'        AMOUNT_SOLD(P.PRODUCT_ID) amount_sold,',
'        pi.image,',
'        c.customer_id',
'FROM    product p',
'        join (SELECT image_id,',
'            product_id,',
'            image',
'            FROM(SELECT image_id,',
'                        product_id,',
'                        image,',
'                        Row_number()',
'                            over (',
'                            PARTITION BY product_id',
'                            ORDER BY image_id) AS rn',
'                FROM   product_images) img',
'                WHERE  rn = 1) pi',
'        ON p.product_id = pi.product_id',
'',
'        join (select distinct customer_id,',
'                product_id',
'            from customer_activity)c',
'            on p.product_id = c.product_id',
'WHERE to_number(:USER_ID) = c.customer_id;',
'',
'',
''))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(37838757005192245373)
,p_region_id=>wwv_flow_imp.id(72436807694934506498)
,p_layout_type=>'GRID'
,p_grid_column_count=>5
,p_title_adv_formatting=>false
,p_title_column_name=>'PRODUCT_NAME'
,p_sub_title_adv_formatting=>true
,p_sub_title_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{case DISCOUNT/}',
'{when 0/}',
'<b>&NEW_PRICE. TN</b>',
'{otherwise/}',
'&DISCOUNT.% &emsp;',
'<b>&NEW_PRICE. TN </b>&emsp;',
'<s> &UNIT_PRICE. TN</s>',
'',
'',
'{endcase/}'))
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_media_adv_formatting=>false
,p_media_source_type=>'BLOB'
,p_media_blob_column_name=>'IMAGE'
,p_media_display_position=>'FIRST'
,p_media_appearance=>'WIDESCREEN'
,p_media_sizing=>'COVER'
,p_pk1_column_name=>'PRODUCT_ID'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(37838758701178245376)
,p_card_id=>wwv_flow_imp.id(37838757005192245373)
,p_action_type=>'FULL_CARD'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:18:&SESSION.::&DEBUG.:18:P18_PRODUCT_ID:&PRODUCT_ID.'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(22821462276868138525)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(34869894253072248629)
,p_button_name=>'Add_To_Cart'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--iconLeft:t-Button--hoverIconPush:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(19471882117602504304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add to Cart'
,p_icon_css_classes=>'fa-plus-square'
,p_grid_column_css_classes=>'action-btn'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
,p_grid_column_span=>4
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(42887192530403190805)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(26541545091537367337)
,p_button_name=>'To_categories'
,p_button_static_id=>'category-btn'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(19471882000429504304)
,p_button_image_alt=>'.'
,p_button_redirect_url=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.:2:P2_CATEG_ID:&P18_CATEGORY_ID.'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(26571013322999157604)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(34869894253072248629)
,p_button_name=>'Add_To_Wishlist'
,p_button_static_id=>'add_wishlist_btn'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--iconLeft:t-Button--hoverIconPush:t-Button--pillEnd:t-Button--stretch:t-Button--padLeft'
,p_button_template_id=>wwv_flow_imp.id(19471882117602504304)
,p_button_image_alt=>'Add To Wishlist'
,p_icon_css_classes=>'fa-heart'
,p_grid_column_css_classes=>'action-btn'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
,p_grid_column_span=>4
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(33975093166806940947)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(26541545091537367337)
,p_button_name=>'To_Store'
,p_button_static_id=>'store-btn'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(19471882000429504304)
,p_button_image_alt=>'.'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(42887195770403190837)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(42887195006199190830)
,p_button_name=>'Submit_review'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--success:t-Button--iconLeft:t-Button--hoverIconPush:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(19471882117602504304)
,p_button_image_alt=>'Submit my  Review'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-star'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(28046133274890995907)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(28046134095294995915)
,p_button_name=>'Increment_quantity'
,p_button_static_id=>'increment_quantity'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(19471881378436504304)
,p_button_image_alt=>'Increment Quantity'
,p_button_position=>'BUTTON_END'
,p_warn_on_unsaved_changes=>null
,p_button_css_classes=>'quantity-btn'
,p_icon_css_classes=>'fa-plus'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(28046133169371995906)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(28046134095294995915)
,p_button_name=>'Decrement_quantity'
,p_button_static_id=>'decrement_quantity'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--hoverIconPush'
,p_button_template_id=>wwv_flow_imp.id(19471881378436504304)
,p_button_image_alt=>'Decrement Quantity'
,p_button_position=>'BUTTON_START'
,p_warn_on_unsaved_changes=>null
,p_button_css_classes=>'quantity-btn'
,p_icon_css_classes=>'fa-minus'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(28046135613385995931)
,p_branch_name=>'To Add To Shopping Cart'
,p_branch_action=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:6:P6_PRODUCT_ID,P6_QUNATITY,P6_STOCK_ID,P6_VARIANT_1_NAME,P6_VARIANT_2_NAME,P6_VARIANT_3_NAME:&P18_PRODUCT_ID.,&P18_QUANTITY.,&P18_STOCK_ID.,&P18_VARIANT_1_NAME.,&P18_VARIANT_2_NAME.,&P18_VARIANT_3_NAME.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(22821462276868138525)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(22821462164902138524)
,p_name=>'P18_QUANTITY'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(28046134095294995915)
,p_placeholder=>'Quantity'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>2
,p_tag_css_classes=>'prod-qunatity'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'0'
,p_attribute_03=>'center'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(26541541610181367303)
,p_name=>'P18_PRODUCT_NAME'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(26541541782165367304)
,p_name=>'P18_PRODUCT_ID'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(26541541996995367306)
,p_name=>'P18_PRODUCT_DESCRIPTION'
,p_item_sequence=>40
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(26541542018589367307)
,p_name=>'P18_UNIT_PRICE'
,p_item_sequence=>50
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(26541542741477367314)
,p_name=>'P18_STORE_NAME'
,p_item_sequence=>110
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(26571017328986157644)
,p_name=>'P18_VARIANT_1_NAME'
,p_item_sequence=>160
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(26571017438590157645)
,p_name=>'P18_VARIANT_2_NAME'
,p_item_sequence=>170
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(26571017557664157646)
,p_name=>'P18_VARIANT_3_NAME'
,p_item_sequence=>180
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(26571017622891157647)
,p_name=>'P18_DISCOUNT'
,p_item_sequence=>130
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(26571017743912157648)
,p_name=>'P18_CATEGORY_NAME'
,p_item_sequence=>80
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(33975089793187940913)
,p_name=>'P18_VARIANT_1'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(34869894082830248627)
,p_prompt=>'&P18_VARIANT_1_NAME.'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT',
'    variant_1 as display_value, variant_1 as return_value',
'FROM',
'    variant_stock',
'WHERE',
'    product_id = :P18_PRODUCT_ID;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'-- Select &P18_VARIANT_1_NAME. --'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(19471880875514504303)
,p_item_css_classes=>'variants'
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(33975089882724940914)
,p_name=>'P18_VARIANT_2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(34869894082830248627)
,p_prompt=>'&P18_VARIANT_2_NAME.'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT',
'    variant_2 as display_value, variant_2 as return_value',
'FROM',
'    variant_stock',
'WHERE',
'    product_id = :P18_PRODUCT_ID',
'AND',
'    variant_1 = :P18_VARIANT_1;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'-- Select &P18_VARIANT_2_NAME. --'
,p_lov_cascade_parent_items=>'P18_VARIANT_1'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_colspan=>4
,p_field_template=>wwv_flow_imp.id(19471880875514504303)
,p_item_css_classes=>'variants'
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>6662355588643785590
,p_default_application_id=>214711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_RSWSP'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(33975089946093940915)
,p_name=>'P18_VARIANT_3'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(34869894082830248627)
,p_prompt=>'&P18_VARIANT_3_NAME.'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT',
'    variant_3 as display_value, variant_3 as return_value',
'FROM',
'    variant_stock',
'WHERE',
'    product_id = :P18_PRODUCT_ID',
'    AND variant_1 = :P18_VARIANT_1',
'    AND variant_2 = :P18_VARIANT_2'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'-- Select &P18_VARIANT_3_NAME. --'
,p_lov_cascade_parent_items=>'P18_VARIANT_2'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(19471880875514504303)
,p_item_css_classes=>'variants'
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(33975091984047940935)
,p_name=>'P18_STOCK'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(34869894082830248627)
,p_item_default=>'Choose variants to get the quantity available in stock'
,p_prompt=>'Quantity Available in Stock'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(19471879586967504303)
,p_item_css_classes=>'available-stock'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(34869892054281248607)
,p_name=>'P18_STORE_ID'
,p_item_sequence=>100
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(34869892445052248611)
,p_name=>'P18_STORE_URL'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(26541545091537367337)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(34869893210850248619)
,p_name=>'P18_PRODUCT_SLIDER_JSON'
,p_item_sequence=>200
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(34869893936804248626)
,p_name=>'P18_NEW_PRICE'
,p_item_sequence=>140
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37036233395482922413)
,p_name=>'P18_STOCK_ID'
,p_item_sequence=>190
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(42374009587370189342)
,p_name=>'P18_STORE_OWNER_ID'
,p_item_sequence=>120
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(42887193722949190817)
,p_name=>'P18_CATEGORY_ID'
,p_item_sequence=>90
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(42887194846731190828)
,p_name=>'P18_REVIEW_INPUT'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(42887195006199190830)
,p_prompt=>'Describe your experience with this product (optional)'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(19471879586967504303)
,p_item_css_classes=>'review-input'
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:t-Form-fieldContainer--xlarge'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(42887194973796190829)
,p_name=>'P18_RATING'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(42887195006199190830)
,p_prompt=>'Add Rating '
,p_display_as=>'NATIVE_STAR_RATING'
,p_grid_row_css_classes=>'rating-row'
,p_grid_column_css_classes=>'rating-col'
,p_field_template=>wwv_flow_imp.id(19471879586967504303)
,p_item_css_classes=>'rating'
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--boldDisplay'
,p_attribute_01=>'5'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(28046135930191995934)
,p_validation_name=>'QUNTITY IS NOT 0 OR NULL'
,p_validation_sequence=>10
,p_validation=>'P18_QUANTITY'
,p_validation_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_error_message=>'Qunatity Cannot Be Empty !'
,p_always_execute=>'Y'
,p_associated_item=>wwv_flow_imp.id(22821462164902138524)
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(43793959108579167605)
,p_validation_name=>'Quantity is more than stock'
,p_validation_sequence=>20
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    IF  to_number(:P18_STOCK) < to_number(:P18_QUANTITY) THEN',
'        RETURN ''The quantity you entered for the product exceeds the available stock ! '';',
'    END IF;',
'END;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_always_execute=>'Y'
,p_when_button_pressed=>wwv_flow_imp.id(22821462276868138525)
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(26541542511349367312)
,p_name=>'Get Product Data'
,p_event_sequence=>10
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(28046136190587995936)
,p_event_id=>wwv_flow_imp.id(26541542511349367312)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'Get Product Info'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'MANAGE_PRODUCTS.get_product_data(',
'    :P18_PRODUCT_ID, ',
'    :P18_PRODUCT_NAME, ',
'    :P18_PRODUCT_DESCRIPTION, ',
'    :P18_UNIT_PRICE,',
'    :P18_DISCOUNT,',
'    :P18_NEW_PRICE,',
'    :P18_CATEGORY_ID,',
'    :P18_CATEGORY_NAME,',
'    :P18_STORE_ID,',
'    :P18_VARIANT_1_NAME,',
'    :P18_VARIANT_2_NAME,',
'    :P18_VARIANT_3_NAME',
');'))
,p_attribute_02=>'P18_PRODUCT_ID'
,p_attribute_03=>'P18_PRODUCT_NAME,P18_PRODUCT_DESCRIPTION,P18_UNIT_PRICE,P18_DISCOUNT,P18_NEW_PRICE,P18_CATEGORY_ID,P18_CATEGORY_NAME,P18_STORE_ID,P18_VARIANT_1_NAME,P18_VARIANT_2_NAME,P18_VARIANT_3_NAME'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(42887194527282190825)
,p_event_id=>wwv_flow_imp.id(26541542511349367312)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_name=>'Get Store Data'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    store_name,',
'    customer_id',
'INTO',
'    :P18_STORE_NAME,',
'    :P18_STORE_OWNER_ID',
'FROM ',
'    stores',
'WHERE',
'    store_id = :P18_STORE_ID;'))
,p_attribute_02=>'P18_STORE_ID'
,p_attribute_03=>'P18_STORE_NAME,P18_STORE_OWNER_ID'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(26541542807784367315)
,p_event_id=>wwv_flow_imp.id(26541542511349367312)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'const productName = document.getElementById("product-name");',
'const prodDesc = document.getElementsByClassName("product-details")[0];',
'const toStore = document.getElementById("store-btn");',
'const to_category = document.getElementById("category-btn");',
'',
'let priceDisplay =  parseInt($v("P18_DISCOUNT")) > 0 ?',
'    `<span class="old-price">${$v("P18_UNIT_PRICE")} TDN</span>&nbsp;<span class="new-price"> ${$v("P18_NEW_PRICE")} TDN</span>`',
'    :',
'    `<span class="new-price"> ${$v("P18_NEW_PRICE")} TDN</span>`;',
'',
'productName.innerHTML = `<h1>${$v("P18_PRODUCT_NAME")}</h1>`',
'prodDesc.innerHTML = `',
'    <h3 class="unit-price"><span class="price-header">Price : </span> ${priceDisplay} ',
'    ${parseFloat($v("P18_DISCOUNT")) > 0 ?',
'        `<span class="save-money">save ${parseInt($v("P18_UNIT_PRICE")) - parseInt($v("P18_NEW_PRICE"))} TDN</span>`: ''''}',
'    </h3>',
'  `;',
'',
'toStore.innerText =`Store : ${$v("P18_STORE_NAME")} `;',
'to_category.innerText = `Category : ${$v("P18_CATEGORY_NAME")} `'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(33975090615076940922)
,p_event_id=>wwv_flow_imp.id(26541542511349367312)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$s("P18_VARIANT_1_LABEL", $v("P18_VARIANT_1_NAME"));',
'$s("P18_VARIANT_2_LABEL", $v("P18_VARIANT_2_NAME"));',
'$s("P18_VARIANT_3_LABEL", $v("P18_VARIANT_3_NAME"));'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(28046132765931995902)
,p_name=>'Set Shopping Cart Icon'
,p_event_sequence=>20
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(26541545091537367337)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(28046132822686995903)
,p_event_id=>wwv_flow_imp.id(28046132765931995902)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':SHOPPING_CART_ITEMS := manage_orders.get_quantity;'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(28046134186286995916)
,p_name=>'Decrement Quantity'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(28046133169371995906)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(28046134327360995918)
,p_event_id=>wwv_flow_imp.id(28046134186286995916)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$s("P18_QUANTITY", parseInt($v("P18_QUANTITY")) - 1);',
''))
,p_client_condition_type=>'GREATER_THAN'
,p_client_condition_element=>'P18_QUANTITY'
,p_client_condition_expression=>'1'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(28046134503478995920)
,p_name=>'Increment Quantity '
,p_event_sequence=>50
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(28046133274890995907)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(28046134669713995921)
,p_event_id=>wwv_flow_imp.id(28046134503478995920)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if($v("P18_QUANTITY") === "" && $v("P18_VARIANT_3") !== "" && $v("P18_STOCK") != ''Out Of Stock !'') {',
'    $s("P18_QUANTITY", "1");',
'}else if($v("P18_VARIANT_3") === ""){',
'    apex.message.showErrors([',
'    {',
'        type:       "error",',
'        location:   [ "page" ],',
'        message:    "Variants are required before Choosing quantity",',
'        unsafe:     false',
'    },',
']);',
'setTimeout(apex.message.clearErrors, 3000);',
'}else if(parseInt($v("P18_QUANTITY")) < parseInt($v("P18_STOCK"))){',
'    console.log(parseInt($v("P18_STOCK")), parseInt($v("P18_QUANTITY")))',
'    $s("P18_QUANTITY", parseInt($v("P18_QUANTITY")) + 1);',
'}',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(33975092082324940936)
,p_name=>'Get New Stock Quantity'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P18_VARIANT_3'
,p_condition_element=>'P18_VARIANT_3'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(33975092183685940937)
,p_event_id=>wwv_flow_imp.id(33975092082324940936)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    STOCK_QUANTITY',
'INTO',
'    :P18_STOCK',
'FROM',
'    VARIANT_STOCK',
'WHERE',
'    product_id = :P18_PRODUCT_ID',
'    AND VARIANT_1 = :P18_VARIANT_1',
'    AND VARIANT_2 = :P18_VARIANT_2',
'    AND VARIANT_3 = :P18_VARIANT_3;'))
,p_attribute_02=>'P18_PRODUCT_ID,P18_VARIANT_1,P18_VARIANT_2,P18_VARIANT_3'
,p_attribute_03=>'P18_STOCK'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(43793958741269167601)
,p_event_id=>wwv_flow_imp.id(33975092082324940936)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if(parseInt($v("P18_STOCK")) === 0) {',
'    $s("P18_STOCK", "Out Of Stock !")',
'    $("#P18_STOCK").addClass("out-of-stock-quantity");',
'}else if(parseInt($v("P18_STOCK")) > 0){',
'    $("#P18_STOCK").addClass("in-stock-quantity");',
'}'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(33975092218736940938)
,p_event_id=>wwv_flow_imp.id(33975092082324940936)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P18_STOCK'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(42887196620349190846)
,p_event_id=>wwv_flow_imp.id(33975092082324940936)
,p_event_result=>'FALSE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$s("P18_STOCK", "Choose variants to get the quantity available in stock")'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(43793958874213167602)
,p_event_id=>wwv_flow_imp.id(33975092082324940936)
,p_event_result=>'FALSE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$("#P18_STOCK").removeClass("out-of-stock-quantity");',
'$("#P18_STOCK").removeClass("in-stock-quantity");'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(34869892166404248608)
,p_name=>'Redirect To Store'
,p_event_sequence=>70
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(33975093166806940947)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(34869892331017248610)
,p_event_id=>wwv_flow_imp.id(34869892166404248608)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
' :P18_STORE_URL := APEX_UTIL.PREPARE_URL(',
'     ''f?p=&APP_ID.:5:&APP_SESSION.::::P5_STORE_ID,P5_STORE_OWNER_ID,P5_STORE_NAME:'' ',
'     || :P18_STORE_ID ',
'     || '','' ',
'     ||:P18_STORE_OWNER_ID ',
'     ||'',''',
'     || :P18_STORE_NAME',
'  );',
'END;'))
,p_attribute_02=>'P18_PRODUCT_SLIDER_JSON'
,p_attribute_03=>'P18_STORE_URL'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(34869892571798248612)
,p_event_id=>wwv_flow_imp.id(34869892166404248608)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'let url = $v("P18_STORE_URL");',
'apex.navigation.redirect(url);'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(35414745458344934208)
,p_name=>'Customer_Activity'
,p_event_sequence=>80
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(35414745538308934209)
,p_event_id=>wwv_flow_imp.id(35414745458344934208)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'    ',
'begin',
'    INSERT INTO customer_activity (activity_id, customer_id, product_id, visit_date, number_visit, is_new)',
'    VALUES (customer_activity_id_seq.nextval, to_number(:USER_ID), :P18_PRODUCT_ID, SYSDATE, 1, ''Yes'');',
'end;'))
,p_attribute_02=>'P18_PRODUCT_ID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_server_condition_type=>'EXPRESSION'
,p_server_condition_expr1=>'to_number(:USER_ID) != :P18_STORE_OWNER_ID'
,p_server_condition_expr2=>'PLSQL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(37838802026844265013)
,p_name=>'wishlist'
,p_event_sequence=>90
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.heart'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_display_when_type=>'EXPRESSION'
,p_display_when_cond=>'APEX_AUTHENTICATION.IS_AUTHENTICATED'
,p_display_when_cond2=>'PLSQL'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(37838802980592265015)
,p_event_id=>wwv_flow_imp.id(37838802026844265013)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_name=>'set value'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P18_PRODUCT_ID'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'$(this.triggeringElement).data(''id'')'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(37838802486375265015)
,p_event_id=>wwv_flow_imp.id(37838802026844265013)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'console.log($v(''P18_PRODUCT_ID''))'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(37838803481179265015)
,p_event_id=>wwv_flow_imp.id(37838802026844265013)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_name=>'add_wishlist'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'  IF APEX_AUTHENTICATION.IS_AUTHENTICATED THEN',
'    ADD_TO_WISHLIST.ADD_PRODUCT(:P18_PRODUCT_ID, to_number(:USER_ID));',
'  ELSE',
'    apex_error.add_error (',
'      p_message => ''Login first to unlock this action.'',',
'      p_display_location => apex_error.c_inline_in_notification',
'    );',
'  END IF;',
'END;',
''))
,p_attribute_02=>'P18_PRODUCT_ID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(37838803978231265016)
,p_event_id=>wwv_flow_imp.id(37838802026844265013)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.message.showPageSuccess( ''Product added to wishlist'' );'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(37840529979121548877)
,p_name=>'wishlist_error'
,p_event_sequence=>100
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.heart'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_display_when_type=>'EXPRESSION'
,p_display_when_cond=>'not APEX_AUTHENTICATION.IS_AUTHENTICATED'
,p_display_when_cond2=>'PLSQL'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(37840530360241548879)
,p_event_id=>wwv_flow_imp.id(37840529979121548877)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.message.showErrors([',
'    {',
'        type:       "error",',
'        location:   [ "page" ],',
'        message:    "You Must Be Authenticated Before Adding Product To Wishlist !",',
'        unsafe:     false',
'    }',
']);',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(42887195889818190838)
,p_name=>'Submit Review'
,p_event_sequence=>110
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(42887195770403190837)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(42887196039920190840)
,p_event_id=>wwv_flow_imp.id(42887195889818190838)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if(parseInt($v("P18_RATING")) === 0) {',
'    apex.message.showErrors([',
'    {',
'        type:       "error",',
'        location:    "inline" ,',
'        pageItem:   "P18_RATING",',
'        message:    "Rating is required!",',
'        unsafe:     false',
'    }',
']);',
'}'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(42887195929833190839)
,p_event_id=>wwv_flow_imp.id(42887195889818190838)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'INSERT INTO reviews',
'VALUES (',
'    REVIEW_ID_SEQ.NEXTVAL,',
'    :P18_REVIEW_INPUT,',
'    :P18_RATING,',
'    to_number(:USER_ID),',
'    :P18_PRODUCT_ID',
');'))
,p_attribute_02=>'P18_REVIEW_INPUT,P18_RATING,P18_PRODUCT_ID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(42887196267359190842)
,p_event_id=>wwv_flow_imp.id(42887195889818190838)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'Review Added Successfully'
,p_attribute_03=>'success'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(43780272398810753390)
,p_name=>'disable add to cart button '
,p_event_sequence=>120
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P18_STOCK'
,p_condition_element=>'P18_STOCK'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'Out Of Stock !'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(43780272787581753390)
,p_event_id=>wwv_flow_imp.id(43780272398810753390)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(22821462276868138525)
,p_attribute_01=>'$("#B22821462276868138525").attr("disabled", true);'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(43780273204832753391)
,p_event_id=>wwv_flow_imp.id(43780272398810753390)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(22821462276868138525)
,p_attribute_01=>'$("#B22821462276868138525").attr("disabled", false);'
,p_client_condition_type=>'NOT_EQUALS'
,p_client_condition_element=>'P18_STOCK'
,p_client_condition_expression=>'0'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(43793958949786167603)
,p_name=>'Clear Items'
,p_event_sequence=>130
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(43793959063120167604)
,p_event_id=>wwv_flow_imp.id(43793958949786167603)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLEAR'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P18_VARIANT_1,P18_VARIANT_2,P18_VARIANT_3,P18_QUANTITY'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(37036233469882922414)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Fetch Stock ID'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'    SELECT ',
'        stock_id',
'    INTO ',
'        :P18_STOCK_ID',
'    FROM',
'        variant_stock',
'    WHERE',
'        variant_1 = :P18_VARIANT_1',
'        AND variant_2 = :P18_VARIANT_2',
'        AND variant_3 = :P18_VARIANT_3',
'        AND product_id = :P18_PRODUCT_ID;',
'   '))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(22821462276868138525)
,p_internal_uid=>37036233469882922414
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(35414747138060934225)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'add to wishlist'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'  IF APEX_AUTHENTICATION.IS_AUTHENTICATED THEN',
'    ADD_TO_WISHLIST.ADD_PRODUCT(:P18_PRODUCT_ID, to_number(:USER_ID));',
'  ELSE',
'    apex_error.add_error (',
'      p_message => ''Login first to unlock this action.'',',
'      p_display_location => apex_error.c_inline_in_notification',
'    );',
'  END IF;',
'END;',
'',
'',
'',
'',
'',
'',
'     '))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(26571013322999157604)
,p_process_success_message=>'product added to your wishlist !'
,p_internal_uid=>35414747138060934225
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(34869893308055248620)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'JSON FORMAT'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'  URL_SERVER_NAME VARCHAR2(500) := ''https://apex.oracle.com/pls/apex/rs_wsp/images/'';',
'',
'  CURSOR REPORT IS SELECT IMAGE_ID FROM PRODUCT_IMAGES WHERE PRODUCT_ID = :P18_PRODUCT_ID;',
'',
'  TYPE L_REPORT_TYPE IS RECORD (',
'    IMAGE_ID         PRODUCT_IMAGES.IMAGE_ID%TYPE',
'  );',
'',
'  TYPE L_REPORT_TAB IS TABLE OF L_REPORT_TYPE;',
'',
'  L_REPORT L_REPORT_TAB;',
'BEGIN',
'  OPEN REPORT;',
'',
'  FETCH REPORT BULK COLLECT INTO L_REPORT;',
'',
'  CLOSE REPORT;',
'',
'  APEX_JSON.INITIALIZE_CLOB_OUTPUT;',
'  APEX_JSON.OPEN_ARRAY; ',
'',
'  FOR L_CNT IN L_REPORT.FIRST .. L_REPORT.LAST LOOP',
'    APEX_JSON.OPEN_OBJECT; ',
'    APEX_JSON.WRITE(''imagePath'', URL_SERVER_NAME || L_REPORT(L_CNT).IMAGE_ID);',
'    APEX_JSON.WRITE(''order'', L_REPORT(L_CNT).IMAGE_ID);',
'    APEX_JSON.CLOSE_OBJECT; ',
'  END LOOP;',
'    ',
'  APEX_JSON.CLOSE_ARRAY; ',
'  :P18_PRODUCT_SLIDER_JSON := APEX_JSON.GET_CLOB_OUTPUT;',
'  DBMS_OUTPUT.PUT_LINE(APEX_JSON.GET_CLOB_OUTPUT);',
'  APEX_JSON.FREE_OUTPUT;',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>34869893308055248620
);
wwv_flow_imp.component_end;
end;
/
