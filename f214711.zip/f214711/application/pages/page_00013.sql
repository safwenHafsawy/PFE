prompt --application/pages/page_00013
begin
--   Manifest
--     PAGE: 00013
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>6662355588643785590
,p_default_application_id=>214711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_RSWSP'
);
wwv_flow_imp_page.create_page(
 p_id=>13
,p_name=>'My orders'
,p_alias=>'ORDERS'
,p_step_title=>'orders'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'[Headers ~= DETAILS]{',
'    background-color: #3A3632;',
'    border-radius: 5px;',
'    text-align: center;',
'    ',
'}',
'/*a:link{',
'    color: magenta;',
'}*/',
'/*.t-Report-cell a{',
'    color:white;',
'}*/',
'[Headers ~= DETAILS] a {',
'    color:white;',
'}',
'.col col-12 apex-col-auto col-start col-end{',
'    border: none;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'03'
,p_last_updated_by=>'PFE94053@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20230708220301'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(33829156032771289628)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>20
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(33831360957880412203)
,p_name=>'orders'
,p_template=>wwv_flow_imp.id(19471808805460504264)
,p_display_sequence=>40
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hideHeader:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--staticRowColors:t-Report--rowHighlight:t-Report--inline:t-Report--hideNoPagination'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct O.ORDER_ID,',
'       ORDER_DATETIME,',
'       CUSTOMER_ID,',
'       ORDER_STATUS,',
'       ORDER_INFORMATION,',
'        LISTAGG(P.PRODUCT_NAME, '', '') WITHIN GROUP (ORDER BY I.LINE_ITEM_ID) AS PRODUCT_NAMES,',
'        sum(I.UNIT_PRICE) || '' TND'' as TOTAL,',
'        ''details'' details',
'      ',
'  from ORDERS O, ORDER_ITEMS I , PRODUCT P',
'  WHERE O.ORDER_ID = I.ORDER_ID',
'  and P.PRODUCT_ID = I.PRODUCT_ID',
'  AND CUSTOMER_ID = to_number(:USER_ID)',
'  AND   Order_status = NVL(:P13_ORDER_STATUS, ORDER_status)',
'    GROUP BY O.ORDER_ID,',
'         O.ORDER_DATETIME,',
'         O.CUSTOMER_ID,',
'         O.ORDER_STATUS,',
'         O.ORDER_INFORMATION'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(19471847069031504283)
,p_query_num_rows=>50
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_prn_output=>'N'
,p_prn_format=>'PDF'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(33831361308343412205)
,p_query_column_id=>1
,p_column_alias=>'ORDER_ID'
,p_column_display_sequence=>1
,p_column_heading=>'Order Number'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(33831361799511412206)
,p_query_column_id=>2
,p_column_alias=>'ORDER_DATETIME'
,p_column_display_sequence=>2
,p_column_heading=>'Order Datetime'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(33831362165126412206)
,p_query_column_id=>3
,p_column_alias=>'CUSTOMER_ID'
,p_column_display_sequence=>3
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(33831362562418412206)
,p_query_column_id=>4
,p_column_alias=>'ORDER_STATUS'
,p_column_display_sequence=>4
,p_column_heading=>'Order Status'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(33831362924718412207)
,p_query_column_id=>5
,p_column_alias=>'ORDER_INFORMATION'
,p_column_display_sequence=>5
,p_column_heading=>'Order Information'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(33831363309530412207)
,p_query_column_id=>6
,p_column_alias=>'PRODUCT_NAMES'
,p_column_display_sequence=>6
,p_column_heading=>'Products'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(33831363776255412207)
,p_query_column_id=>7
,p_column_alias=>'TOTAL'
,p_column_display_sequence=>7
,p_column_heading=>'Total'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(33831364120263412207)
,p_query_column_id=>8
,p_column_alias=>'DETAILS'
,p_column_display_sequence=>8
,p_column_heading=>'Details'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:9:&SESSION.::&DEBUG.:9:P9_ORDER_ID:#ORDER_ID#'
,p_column_linktext=>'#DETAILS#'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(33829156144329289629)
,p_name=>'P13_ORDER_STATUS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(33829156032771289628)
,p_prompt=>'Order Satus'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select distinct order_status order1, order_status order2 from orders'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'-show all-'
,p_cHeight=>1
,p_colspan=>4
,p_field_template=>wwv_flow_imp.id(19471879586967504303)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(33829156288110289630)
,p_name=>'order status'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P13_ORDER_STATUS'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(33829156358045289631)
,p_event_id=>wwv_flow_imp.id(33829156288110289630)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp.component_end;
end;
/
