prompt --application/pages/page_00007
begin
--   Manifest
--     PAGE: 00007
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>6662355588643785590
,p_default_application_id=>214711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_RSWSP'
);
wwv_flow_imp_page.create_page(
 p_id=>7
,p_name=>'Seller Dashboard Statistics'
,p_alias=>'SELLER-DASHBOARD-STATISTICS'
,p_step_title=>'Seller Dashboard Statistics'
,p_autocomplete_on_off=>'OFF'
,p_css_file_urls=>'#APP_FILES#Styling/main_style#MIN#.css'
,p_step_template=>wwv_flow_imp.id(19471509145742504218)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'04'
,p_last_updated_by=>'PFE94053@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20230721133802'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(22817559429812470568)
,p_plug_name=>'Total Revenue Per Month'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>10
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(22817559816791470568)
,p_region_id=>wwv_flow_imp.id(22817559429812470568)
,p_chart_type=>'lineWithArea'
,p_height=>'400'
,p_animation_on_display=>'alphaFade'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'on'
,p_data_cursor_behavior=>'smooth'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>false
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'off'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function modifyOptions(options) {',
'    options.dataFilter = function(data) {',
'        for (var i = 0; i < data.series.length; i++) {',
'            for (var j = 0; j < data.series[i].items.length; j++) {',
'                    data.series[i].items[j].color = "#FFB929";',
'                    data.series[i].items[j].markerDisplayed = "on";',
'                    data.series[i].items[j].markerSize = 15;',
'            }',
'        }',
'',
'        return data;',
'    };',
'',
'    return options;',
'}',
''))
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(22817561537180470569)
,p_chart_id=>wwv_flow_imp.id(22817559816791470568)
,p_seq=>10
,p_name=>'Revenue'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH all_months AS (',
'  SELECT TO_CHAR(ADD_MONTHS(TRUNC(SYSDATE, ''YYYY''), LEVEL - 1), ''YYYY-MM'') AS month',
'  FROM DUAL',
'  CONNECT BY LEVEL <= 12 ',
')',
'SELECT am.month, COALESCE(SUM(oi.unit_price * oi.quantity), 0) AS sales',
'FROM all_months am',
'LEFT JOIN orders o ON am.month = TO_CHAR(o.order_datetime, ''YYYY-MM'')',
'                    AND o.order_status = ''Confirmed''',
'LEFT JOIN order_items oi ON o.order_id = oi.order_id',
'LEFT JOIN product p ON oi.product_id = p.product_id',
'LEFT JOIN stores s ON p.store_id = s.store_id',
'                   AND s.customer_id = to_number(:USER_ID)',
'GROUP BY am.month',
'ORDER BY am.month;',
''))
,p_items_value_column_name=>'SALES'
,p_items_label_column_name=>'MONTH'
,p_color=>'#3a3632'
,p_line_style=>'solid'
,p_line_type=>'curved'
,p_marker_rendered=>'on'
,p_marker_shape=>'square'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(39512633306982030901)
,p_chart_id=>wwv_flow_imp.id(22817559816791470568)
,p_axis=>'y2'
,p_is_rendered=>'off'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_split_dual_y=>'auto'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(39275505822032429149)
,p_chart_id=>wwv_flow_imp.id(22817559816791470568)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(39275505974423429150)
,p_chart_id=>wwv_flow_imp.id(22817559816791470568)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'currency'
,p_decimal_places=>0
,p_currency=>'TND'
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_step=>250
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(22817562137650470570)
,p_plug_name=>'Total Revenue By Store'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>20
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(22817562567777470570)
,p_region_id=>wwv_flow_imp.id(22817562137650470570)
,p_chart_type=>'bar'
,p_height=>'400'
,p_animation_on_display=>'zoom'
,p_animation_on_data_change=>'slideToRight'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'smooth'
,p_hover_behavior=>'dim'
,p_stack=>'on'
,p_stack_label=>'on'
,p_stack_font_family=>'Courier New'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>false
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'off'
,p_no_data_found_message=>'Nothing To Show Yet !'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(22817563032456470570)
,p_chart_id=>wwv_flow_imp.id(22817562567777470570)
,p_seq=>10
,p_name=>'Revenue'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT s.store_name, COALESCE(SUM(oi.unit_price * oi.quantity), 0) AS sales',
'FROM stores s',
'LEFT JOIN product p ON s.store_id = p.store_id',
'LEFT JOIN order_items oi ON p.product_id = oi.product_id',
'LEFT JOIN orders o ON o.order_id = oi.order_id ',
'WHERE o.order_status = ''Confirmed''',
'  AND s.customer_id = TO_NUMBER(:USER_ID)',
'GROUP BY s.store_name;',
''))
,p_max_row_count=>20
,p_items_value_column_name=>'SALES'
,p_items_label_column_name=>'STORE_NAME'
,p_color=>'#3a3632'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(39275505436936429145)
,p_chart_id=>wwv_flow_imp.id(22817562567777470570)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_tick_label_font_family=>'Courier New'
,p_tick_label_font_size=>'10'
,p_tick_label_font_color=>'#3a3632'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(39275505569455429146)
,p_chart_id=>wwv_flow_imp.id(22817562567777470570)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'currency'
,p_decimal_places=>0
,p_currency=>'TND'
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'start'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_font_family=>'Courier New'
,p_tick_label_font_style=>'italic'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(22817566300796470572)
,p_plug_name=>'Total Revenue By Product'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(22817566784981470572)
,p_region_id=>wwv_flow_imp.id(22817566300796470572)
,p_chart_type=>'bar'
,p_height=>'400'
,p_animation_on_display=>'zoom'
,p_animation_on_data_change=>'slideToLeft'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>false
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'off'
,p_no_data_found_message=>'Nothing To Show Yet !'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(22817568423162470573)
,p_chart_id=>wwv_flow_imp.id(22817566784981470572)
,p_seq=>10
,p_name=>'Revenue Per Product'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT p.product_name, SUM(new_price(oi.product_id) * oi.quantity) AS total_sold',
'FROM order_items oi',
'JOIN product p ON oi.product_id = p.product_id',
'JOIN stores s ON p.store_id = s.store_id',
'WHERE s.customer_id = TO_NUMBER(:USER_ID)',
'GROUP BY p.product_name',
'ORDER BY total_sold DESC;',
''))
,p_max_row_count=>20
,p_items_value_column_name=>'TOTAL_SOLD'
,p_items_label_column_name=>'PRODUCT_NAME'
,p_color=>'#3a3632'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>true
,p_items_label_position=>'center'
,p_items_label_font_family=>'Courier New'
,p_items_label_font_style=>'normal'
,p_items_label_font_size=>'12'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(39512633435026030902)
,p_chart_id=>wwv_flow_imp.id(22817566784981470572)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(39512633527719030903)
,p_chart_id=>wwv_flow_imp.id(22817566784981470572)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'currency'
,p_decimal_places=>0
,p_currency=>'TND'
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38242827072941699947)
,p_plug_name=>'Seller Dashbord Side Navigation'
,p_region_css_classes=>'dashboard-side-menu'
,p_region_sub_css_classes=>'dashboard-side-menu-list'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-LinksList--showBadge:t-LinksList--showArrow:t-LinksList--nowrap:t-LinksList--actions:t-LinksList--showIcons'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>50
,p_plug_display_point=>'REGION_POSITION_02'
,p_list_id=>wwv_flow_imp.id(38784043417088031374)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(19471863408174504294)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(39512633648529030904)
,p_plug_name=>'Customer Distribution by Region'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>50
,p_plug_grid_column_span=>6
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(39512633709009030905)
,p_region_id=>wwv_flow_imp.id(39512633648529030904)
,p_chart_type=>'pie'
,p_height=>'400'
,p_animation_on_display=>'alphaFade'
,p_animation_on_data_change=>'slideToRight'
,p_data_cursor=>'on'
,p_data_cursor_behavior=>'smooth'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_value_format_type=>'decimal'
,p_value_decimal_places=>0
,p_value_format_scaling=>'none'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>false
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_pie_other_threshold=>0
,p_pie_selection_effect=>'explode'
,p_no_data_found_message=>'Nothing To Show Yet !'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function modifyOptions(options) {',
'    const colors = ["#3A3632", "#FFB929", "#497620", "#F0E68C", "#BC4E98" , "#FFB929", "#497620", "#C33522"];',
'    options.dataFilter = function (data) {',
'        for (var i = 0; i < data.series.length; i++) {',
'        data.series[i].color = colors[i]',
'        }',
'',
'        return data;',
'    };',
'',
'    return options;',
'}',
''))
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(39512633802091030906)
,p_chart_id=>wwv_flow_imp.id(39512633709009030905)
,p_seq=>10
,p_name=>'Cus By State'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT st.state_id, state_name,',
'       count(DISTINCT o.customer_id) "number of customers"',
'FROM customer c,',
'     orders o,',
'     states st,',
'     cities ct',
'WHERE o.customer_id = c.customer_id',
'  AND c.city_id = ct.city_id',
'  AND st.state_id = ct.state_id',
'GROUP BY st.state_id,state_name',
'ORDER BY count(o.customer_id)',
'FETCH NEXT 5 ROWS ONLY;',
''))
,p_items_value_column_name=>'number of customers'
,p_items_label_column_name=>'STATE_NAME'
,p_items_label_rendered=>true
,p_items_label_position=>'aboveMarker'
,p_items_label_display_as=>'ALL'
,p_items_label_font_size=>'10'
,p_link_target=>'f?p=&APP_ID.:75:&SESSION.::&DEBUG.:75::'
,p_link_target_type=>'REDIRECT_PAGE'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(41154317089470227819)
,p_plug_name=>'Customer Delivery Preference Distribution'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>60
,p_plug_new_grid_row=>false
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(41154317131217227820)
,p_region_id=>wwv_flow_imp.id(41154317089470227819)
,p_chart_type=>'pie'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_value_format_type=>'decimal'
,p_value_decimal_places=>0
,p_value_format_scaling=>'none'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_pie_other_threshold=>0
,p_pie_selection_effect=>'highlight'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function modifyOptions(options) {',
'	options.dataFilter = function (data) {',
'	  for (var i = 0; i < data.series.length; i++) {',
'		var dataName = data.series[i].name;',
'		if (dataName.startsWith("Home Delivery")) {',
'		  data.series[i].color = "#FFB929";',
'		} else if (dataName.startsWith("Pickup")) {',
'		  data.series[i].color = "#3A3632";',
'	  }',
'      }',
'	  return data;',
'	};',
'  ',
'	return options;',
'  }',
''))
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(41154317298141227821)
,p_chart_id=>wwv_flow_imp.id(41154317131217227820)
,p_seq=>10
,p_name=>'Series 1'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    count(o.order_id),',
'    delivery_method',
'FROM',
'    orders o',
'LEFT JOIN delivery_type dt on o.delivery_type_id = dt.delivery_type_id',
'GROUP BY delivery_method;'))
,p_items_value_column_name=>'COUNT(O.ORDER_ID)'
,p_items_label_column_name=>'DELIVERY_METHOD'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_items_label_display_as=>'LABEL'
);
wwv_flow_imp.component_end;
end;
/
