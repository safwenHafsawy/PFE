prompt --application/pages/page_00073
begin
--   Manifest
--     PAGE: 00073
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>6662355588643785590
,p_default_application_id=>214711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_RSWSP'
);
wwv_flow_imp_page.create_page(
 p_id=>73
,p_name=>'Seller Dashboard Orders'
,p_alias=>'SELLER-DASHBOARD-ORDERS'
,p_step_title=>'Seller Dashboard Orders'
,p_autocomplete_on_off=>'OFF'
,p_css_file_urls=>'#APP_FILES#Styling/main_style#MIN#.css'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.overall-summary-region-container {',
'    padding: 20px;',
'}',
'',
'.overall-summary-region-row{',
'    padding: 0 0 50px;',
'}',
'',
'.overall-summary-region {',
'    margin: 0 10px 10px 10px;',
'    min-height: 100%;',
'    box-shadow: -1px 33px 35px -13px rgba(207,193,193,0.59);',
'    -webkit-box-shadow: -1px 33px 35px -13px rgba(207,193,193,0.59);',
'    -moz-box-shadow: -1px 33px 35px -13px rgba(207,193,193,0.59);',
'    border-radius: 10px !important;',
'    transition: all 300ms;',
'}',
'',
'.overall-summary-region:hover {',
'    transform: scale(1.05);',
'    box-shadow: -1px 33px 35px -20px rgba(207,193,193,0.99);',
'    -webkit-box-shadow: -1px 33px 35px -20px rgba(207,193,193,0.99);',
'    -moz-box-shadow: -1px 33px 35px -20px rgba(207,193,193,0.99);',
'}',
'',
'.overview {',
'    border-left: 10px solid var(--fouth-color);',
'    border-radius: 10px;',
'    padding-left: 10px;',
'    text-align: center;',
'    cursor: pointer;',
'}',
'',
'.overview-danger {',
'    border-left: 10px solid var(--danger-color);',
'    border-radius: 10px;',
'    padding-left: 10px;',
'    text-align: center;',
'    cursor: pointer;',
'}',
'',
'.overview-success{',
'    border-left: 10px solid var(--success-color);',
'    border-radius: 10px;',
'    padding-left: 10px;',
'    text-align: center;',
'    cursor: pointer;',
'}',
'',
'.overview-warning {',
'    border-left: 10px solid var(--warning-color);',
'    border-radius: 10px;',
'    padding-left: 10px;',
'    text-align: center;',
'    cursor: pointer;',
'}',
'',
'.overview-title {',
'    text-align: center;',
'    color: var(--fouth-color);',
'    font-family: var(--secondary-header-font);',
'    border-bottom: 1px solid rgba(211, 211, 211, 0.5);',
'    padding: 2px;',
'}',
'',
'.overview-title > span {',
'    margin-right: 5px;',
'}',
'',
'.overview-data {',
'    font-family: var(--regular-text-font );',
'}',
'',
'.overview-data-prod > span {',
'    font-size: xx-small;',
'    opacity: 0.6;',
'}',
'',
'',
'.t-Report-colHead{',
'    font-family: var(--secondary-header-font);',
'    text-align: center;',
'}',
'',
'.t-Report-cell{',
'    font-family: var(--regular-text-font);',
'    text-align: center;',
'}',
'',
'',
'.del-order-item {',
'    color: var(--danger-color);',
'}',
'',
'.confirm-order {',
'    color: var(--fouth-color);',
'}',
'',
''))
,p_step_template=>wwv_flow_imp.id(19471509145742504218)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'25'
,p_last_updated_by=>'PFE94053@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20230820113836'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(39275505242159429143)
,p_plug_name=>'Seller Dashboard Navigation'
,p_region_sub_css_classes=>'dashboard-side-menu-list'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-LinksList--showArrow:t-LinksList--nowrap:t-LinksList--actions:t-LinksList--showTopIcons'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_02'
,p_list_id=>wwv_flow_imp.id(38784043417088031374)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(19471863408174504294)
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(40242460151292369231)
,p_name=>'Order Item Overview'
,p_region_name=>'list-of-orders'
,p_template=>wwv_flow_imp.id(19471808805460504264)
,p_display_sequence=>70
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody:margin-top-md'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--altRowsDefault:t-Report--rowHighlight:t-Report--inline:t-Report--hideNoPagination'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    IF :P73_FILTER_ORDERS IS NULL THEN',
'        return q''~',
'        SELECT DISTINCT ',
'            oi.line_item_id, ',
'            o.order_id,',
'            ot.order_type,',
'            p.product_name,',
'            c.firstname || '' '' || c.lastname AS customer_name, ',
'            o.order_datetime, ',
'            oi.item_status, ',
'            ''Check Full Order Details'' AS check_order_details,',
'            ''Accept Purchase'' AS accept_purchase,',
'            ''Cancel Product'' AS cancel_product',
'        FROM ',
'            orders o',
'        INNER JOIN order_items oi ON o.order_id = oi.order_id',
'        INNER JOIN customer c ON o.customer_id = c.customer_id',
'        INNER JOIN product p ON oi.product_id = p.product_id',
'        INNER JOIN stores s ON p.store_id = s.store_id',
'        INNER JOIN order_type ot ON o.order_type_id = ot.order_type_id',
'        WHERE s.customer_id = TO_NUMBER(:USER_ID)',
'        ORDER BY o.order_datetime;',
'',
'        ~'';',
'    ELSIF :P73_FILTER_ORDERS = ''Composite'' OR :P73_FILTER_ORDERS = ''Individual'' THEN',
'        IF :P73_FILTER_ORDERS = ''Composite'' THEN',
'            return q''~',
'            SELECT DISTINCT ',
'                oi.line_item_id, ',
'                o.order_id,',
'                ot.order_type,',
'                p.product_name,',
'                c.firstname || '' '' || c.lastname AS customer_name, ',
'                o.order_datetime, ',
'                oi.item_status, ',
'                ''Check Full Order Details'' AS check_order_details,',
'                ''Accept Purchase'' AS accept_purchase,',
'                ''Cancel Product'' AS cancel_product',
'            FROM ',
'                orders o',
'            INNER JOIN order_items oi ON o.order_id = oi.order_id',
'            INNER JOIN customer c ON o.customer_id = c.customer_id',
'            INNER JOIN product p ON oi.product_id = p.product_id',
'            INNER JOIN stores s ON p.store_id = s.store_id',
'            INNER JOIN order_type ot ON o.order_type_id = ot.order_type_id',
'            WHERE s.customer_id = TO_NUMBER(:USER_ID) AND o.order_type_id = 2',
'            ORDER BY o.order_datetime;',
'',
'            ~''; ',
'        ELSE ',
'            return q''~',
'            SELECT DISTINCT ',
'                oi.line_item_id, ',
'                o.order_id,',
'                ot.order_type,',
'                p.product_name,',
'                c.firstname || '' '' || c.lastname AS customer_name, ',
'                o.order_datetime, ',
'                oi.item_status, ',
'                ''Check Full Order Details'' AS check_order_details,',
'                ''Accept Purchase'' AS accept_purchase,',
'                ''Cancel Product'' AS cancel_product',
'            FROM ',
'                orders o',
'            INNER JOIN order_items oi ON o.order_id = oi.order_id',
'            INNER JOIN customer c ON o.customer_id = c.customer_id',
'            INNER JOIN product p ON oi.product_id = p.product_id',
'            INNER JOIN stores s ON p.store_id = s.store_id',
'            INNER JOIN order_type ot ON o.order_type_id = ot.order_type_id',
'            WHERE s.customer_id = TO_NUMBER(:USER_ID) AND o.order_type_id = 1',
'            ORDER BY o.order_datetime;',
'',
'            ~''; ',
'        END IF;',
'    ELSE ',
'        return q''~',
'        SELECT DISTINCT ',
'            oi.line_item_id, ',
'            o.order_id,',
'            ot.order_type,',
'            p.product_name,',
'            c.firstname || '' '' || c.lastname AS customer_name, ',
'            o.order_datetime, ',
'            oi.item_status, ',
'            ''Check Full Order Details'' AS check_order_details,',
'            ''Accept Purchase'' AS accept_purchase,',
'            ''Cancel Product'' AS cancel_product',
'        FROM ',
'            orders o',
'        INNER JOIN order_items oi ON o.order_id = oi.order_id',
'        INNER JOIN customer c ON o.customer_id = c.customer_id',
'        INNER JOIN product p ON oi.product_id = p.product_id',
'        INNER JOIN stores s ON p.store_id = s.store_id',
'        INNER JOIN order_type ot ON o.order_type_id = ot.order_type_id',
'        WHERE s.customer_id = TO_NUMBER(:USER_ID) AND oi.item_status = :P73_FILTER_ORDERS',
'        ORDER BY o.order_datetime;',
'',
'        ~'';',
'    END IF;',
'ENd;'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P73_FILTER_ORDERS'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(19471847069031504283)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'No orders yet !'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(47738993888221838011)
,p_query_column_id=>1
,p_column_alias=>'LINE_ITEM_ID'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(40358075810028470113)
,p_query_column_id=>2
,p_column_alias=>'ORDER_ID'
,p_column_display_sequence=>40
,p_column_heading=>'Order Number'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(47738993920554838012)
,p_query_column_id=>3
,p_column_alias=>'ORDER_TYPE'
,p_column_display_sequence=>50
,p_column_heading=>'Order Type'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(47738994484356838017)
,p_query_column_id=>4
,p_column_alias=>'PRODUCT_NAME'
,p_column_display_sequence=>20
,p_column_heading=>'Product Name'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(50516530674781306401)
,p_query_column_id=>5
,p_column_alias=>'CUSTOMER_NAME'
,p_column_display_sequence=>80
,p_column_heading=>'Customer Name'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(40358076214976470117)
,p_query_column_id=>6
,p_column_alias=>'ORDER_DATETIME'
,p_column_display_sequence=>60
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(47738997607247838049)
,p_query_column_id=>7
,p_column_alias=>'ITEM_STATUS'
,p_column_display_sequence=>100
,p_column_heading=>'Item Status'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(50516530745698306402)
,p_query_column_id=>8
,p_column_alias=>'CHECK_ORDER_DETAILS'
,p_column_display_sequence=>90
,p_column_heading=>'Check Order Details'
,p_use_as_row_header=>'N'
,p_column_link=>'javascript:void(null)'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-view.png" class="apex-edit-view full-order" alt="">'
,p_column_link_attr=>'data-id=#ORDER_ID#'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(50516530885338306403)
,p_query_column_id=>9
,p_column_alias=>'ACCEPT_PURCHASE'
,p_column_display_sequence=>110
,p_column_heading=>'Accept Purchase'
,p_use_as_row_header=>'N'
,p_column_link=>'javascript:void(null)'
,p_column_linktext=>'<span class="fa fa-check-circle confirm-order" aria-hidden="true"></span>'
,p_column_link_attr=>'data-id=#LINE_ITEM_ID# data-status=#ITEM_STATUS# data-order=#ORDER_ID#'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(50516530985310306404)
,p_query_column_id=>10
,p_column_alias=>'CANCEL_PRODUCT'
,p_column_display_sequence=>120
,p_column_heading=>'Cancel Product'
,p_use_as_row_header=>'N'
,p_column_link=>'javascript:void(null)'
,p_column_linktext=>'<span aria-hidden="true" class="fa fa-times-circle del-order-item"></span>'
,p_column_link_attr=>'data-id=#LINE_ITEM_ID# data-status=#ITEM_STATUS# data-order=#ORDER_ID#'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(47738994727276838020)
,p_plug_name=>'Order Details'
,p_region_css_classes=>'order-details-region'
,p_region_template_options=>'#DEFAULT#:js-dialog-autoheight:t-DialogRegion--noPadding:js-dialog-size720x480:margin-top-lg:margin-bottom-lg:margin-left-lg:margin-right-lg'
,p_plug_template=>wwv_flow_imp.id(19471584494580504252)
,p_plug_display_sequence=>80
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(47738996874561838041)
,p_plug_name=>'Order General Details'
,p_parent_plug_id=>wwv_flow_imp.id(47738994727276838020)
,p_region_template_options=>'#DEFAULT#:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>10
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(47738996964195838042)
,p_plug_name=>'Collaborating Sellers'' Selection'
,p_parent_plug_id=>wwv_flow_imp.id(47738994727276838020)
,p_region_template_options=>'#DEFAULT#:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>60
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(47738996768696838040)
,p_plug_name=>'Partner''s  Products'
,p_parent_plug_id=>wwv_flow_imp.id(47738996964195838042)
,p_region_template_options=>'#DEFAULT#:t-Region--stacked:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>50
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    DISTINCT p.product_id,',
'    product_name,',
'    s.store_name,',
'    s.customer_id as owner',
'FROM product p',
'LEFT JOIN stores s ON s.store_id = p.store_id',
'LEFT JOIN customer c ON s.customer_id = c.customer_id',
'LEFT JOIN order_items oi ON p.product_id = oi.product_id',
'WHERE NOT c.customer_id = :USER_ID AND oi.order_id = :P73_ORDER_NUMBER;',
'',
''))
,p_plug_source_type=>'NATIVE_JQM_LIST_VIEW'
,p_ajax_items_to_submit=>'P73_ORDER_NUMBER'
,p_plug_query_num_rows=>15
,p_attribute_01=>'ADVANCED_FORMATTING'
,p_attribute_05=>'<h5>&PRODUCT_NAME.</h5>'
,p_attribute_07=>'Owner : &OWNER. From &STORE_NAME.'
,p_attribute_16=>'f?p=&APP_ID.:18:&SESSION.::&DEBUG.:18:P18_PRODUCT_ID:&PRODUCT_ID.'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(50516531392499306408)
,p_plug_name=>'Optimal Product Pairings Analysis'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>20
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(50516531446734306409)
,p_region_id=>wwv_flow_imp.id(50516531392499306408)
,p_chart_type=>'bar'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'off'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(50516531572683306410)
,p_chart_id=>wwv_flow_imp.id(50516531446734306409)
,p_seq=>10
,p_name=>'Series 1'
,p_data_source_type=>'TABLE'
,p_query_table=>'ORDER_ITEMS'
,p_include_rowid_column=>false
,p_items_value_column_name=>'QUANTITY'
,p_items_label_column_name=>'PRODUCT_ID'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(50516531621782306411)
,p_chart_id=>wwv_flow_imp.id(50516531446734306409)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(50516531768432306412)
,p_chart_id=>wwv_flow_imp.id(50516531446734306409)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(79066338432320077623)
,p_plug_name=>'Orders Overview'
,p_region_name=>'order-overview'
,p_region_css_classes=>'overall-summary-region-container'
,p_region_template_options=>'#DEFAULT#:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_08'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(40242459207027369222)
,p_plug_name=>'Cancelled'
,p_parent_plug_id=>wwv_flow_imp.id(79066338432320077623)
,p_region_css_classes=>'overall-summary-region'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--stacked:t-Region--scrollBody'
,p_region_attributes=>'data-id=Cancelled'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>60
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>4
,p_plug_display_point=>'SUB_REGIONS'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    l_count number;',
'begin',
'    select  count(distinct oi.line_item_id)',
'    into    l_count',
'    from    order_items oi, product p, stores s',
'    where   oi.item_status = ''Cancelled''  ',
'    and     oi.product_id = p.product_id',
'    and     p.store_id = s.store_id',
'    and     s.customer_id = to_number(:USER_ID) ;',
'',
'    return ',
'        '' <div class="overview-danger">',
'        <h3 class="overview-title"> Cancelled Order Items</h3>',
'        <h4 class="overview-data">'' || l_count || '' Order(s)',
'        </h4>',
'        </div> '';',
'end;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(40242459377251369223)
,p_plug_name=>'Confirmed'
,p_parent_plug_id=>wwv_flow_imp.id(79066338432320077623)
,p_region_css_classes=>'overall-summary-region'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--stacked:t-Region--scrollBody'
,p_region_attributes=>'data-id=Confirmed'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>4
,p_plug_display_point=>'SUB_REGIONS'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    l_count number;',
'begin',
'    select  count(distinct oi.line_item_id)',
'    into    l_count',
'    from    order_items oi, product p, stores s',
'    where   oi.item_status = ''Confirmed''  ',
'    and     oi.product_id = p.product_id',
'    and     p.store_id = s.store_id',
'    and     s.customer_id = to_number(:USER_ID) ;',
'',
'    return ',
'        '' <div class="overview-success">',
'        <h3 class="overview-title"> Confirmed Order Items</h3>',
'        <h4 class="overview-data">'' || l_count || '' Order(s)',
'        </h4>',
'        </div> '';',
'end;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(50516531207441306407)
,p_plug_name=>'Composite'
,p_parent_plug_id=>wwv_flow_imp.id(79066338432320077623)
,p_region_css_classes=>'overall-summary-region'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--stacked:t-Region--scrollBody'
,p_region_attributes=>'data-id=Composite'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>4
,p_plug_display_point=>'SUB_REGIONS'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_count NUMBER := 0;',
'BEGIN',
'    SELECT COUNT(DISTINCT o.order_id)',
'    INTO l_count',
'    FROM orders o',
'    JOIN order_items oi ON o.order_id = oi.order_id',
'    JOIN product p ON oi.product_id = p.product_id',
'    JOIN stores s ON p.store_id = s.store_id',
'    WHERE o.order_type_id = 2',
'    AND s.customer_id = TO_NUMBER(:USER_ID);',
'',
'    RETURN ''<div class="overview">',
'            <h3 class="overview-title"> Composite Orders </h3>',
'            <h4 class="overview-data">'' || l_count || '' order(s)',
'            </h4>',
'            </div>'';',
'END;',
''))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(79066338607683077625)
,p_plug_name=>'Total Orders'
,p_parent_plug_id=>wwv_flow_imp.id(79066338432320077623)
,p_region_css_classes=>'overall-summary-region'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--stacked:t-Region--scrollBody'
,p_region_attributes=>'data-id=Total'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>10
,p_plug_grid_row_css_classes=>'overall-summary-region-row'
,p_plug_grid_column_span=>4
,p_plug_display_point=>'SUB_REGIONS'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    l_number_of_orders number;',
'begin',
'     select  count(distinct o.order_id)',
'    into    l_number_of_orders',
'    from    orders o, order_items oi, product p, stores s',
'    where   o.order_id = oi.order_id',
'    and     oi.product_id = p.product_id',
'    and     p.store_id = s.store_id',
'    and     s.customer_id = to_number(:USER_ID) ;',
'',
'    return ',
'        '' <div class="overview" data-id="Total">',
'        <h3 class="overview-title"> Total Orders</h3>',
'        <h4 class="overview-data">'' || l_number_of_orders || '' Order(s)',
'        </h4>',
'        </div> '';',
'end;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(79066338740063077626)
,p_plug_name=>'Individual'
,p_parent_plug_id=>wwv_flow_imp.id(79066338432320077623)
,p_region_css_classes=>'overall-summary-region'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--stacked:t-Region--scrollBody'
,p_region_attributes=>'data-id=Individual'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>4
,p_plug_display_point=>'SUB_REGIONS'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_count NUMBER := 0;',
'BEGIN',
'    SELECT COUNT(DISTINCT o.order_id)',
'    INTO l_count',
'    FROM orders o',
'    JOIN order_items oi ON o.order_id = oi.order_id',
'    JOIN product p ON oi.product_id = p.product_id',
'    JOIN stores s ON p.store_id = s.store_id',
'    WHERE o.order_type_id = 1',
'    AND s.customer_id = TO_NUMBER(:USER_ID);',
'',
'    RETURN ''<div class="overview">',
'            <h3 class="overview-title"> Individual Orders </h3>',
'            <h4 class="overview-data">'' || l_count || '' order(s)',
'            </h4>',
'            </div>'';',
'END;',
''))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(79066338846821077627)
,p_plug_name=>'Pending'
,p_parent_plug_id=>wwv_flow_imp.id(79066338432320077623)
,p_region_css_classes=>'overall-summary-region'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--stacked:t-Region--scrollBody'
,p_region_attributes=>'data-id=Pending'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>40
,p_plug_grid_column_span=>4
,p_plug_display_point=>'SUB_REGIONS'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    l_count number;',
'begin',
'    select  count(distinct oi.line_item_id)',
'    into    l_count',
'    from    order_items oi, product p, stores s',
'    where   oi.item_status = ''Pending''  ',
'    and     oi.product_id = p.product_id',
'    and     p.store_id = s.store_id',
'    and     s.customer_id = to_number(:USER_ID) ;',
'',
'    return ',
'        '' <div class="overview-warning">',
'        <h3 class="overview-title"> Pending Order Items</h3>',
'        <h4 class="overview-data">'' || l_count || '' Order(s)',
'        </h4>',
'        </div> '';',
'end;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(40294674489649210444)
,p_name=>'P73_ORDER_ITEM_ID'
,p_item_sequence=>50
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(40294674556588210445)
,p_name=>'P73_ITEM_STATUS'
,p_item_sequence=>40
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41154319228211227841)
,p_name=>'P73_FILTER_ORDERS'
,p_item_sequence=>60
,p_prompt=>'Filter Order Items'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Pending Order Items;Pending,Confirmed Order Items;Confirmed,Cancelled Order Items;Cancelled,Individual Orders;Individual,Composite Orders;Composite'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Total Orders'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(19471879438844504303)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(47738995390525838026)
,p_name=>'P73_ORDER_TYPE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(47738996874561838041)
,p_prompt=>'Order Type'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(19471879586967504303)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(47738995450473838027)
,p_name=>'P73_ORDER_NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(47738996874561838041)
,p_prompt=>'Order Number'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(19471879586967504303)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(47738995683295838029)
,p_name=>'P73_ORDER_PARTNERS'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(47738996964195838042)
,p_prompt=>'Order Partners'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(19471879586967504303)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(47738997073508838043)
,p_name=>'P73_BUYER_NAME'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(47738996874561838041)
,p_prompt=>'Buyer Name'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(19471879586967504303)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(47738997165026838044)
,p_name=>'P73_BUYER_EMAIL'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(47738996874561838041)
,p_prompt=>'Buyer Name'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(19471879586967504303)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(47738997244190838045)
,p_name=>'P73_BUYER_PHONE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(47738996874561838041)
,p_prompt=>'Buyer Name'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(19471879586967504303)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(47738997379840838046)
,p_name=>'P73_ORDER_DATE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(47738996874561838041)
,p_prompt=>'Order Type'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(19471879586967504303)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(50516531144168306406)
,p_name=>'P73_ORDER_ID'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(40294673744313210437)
,p_name=>'Change cell color'
,p_event_sequence=>10
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(40294673802423210438)
,p_event_id=>wwv_flow_imp.id(40294673744313210437)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''td[headers="ITEM_STATUS"]'').each(function() {  ',
'',
'  if ( $(this).text() === ''Pending'' ) {',
'',
'    $(this).css({"background-color":"#FFB929"});',
'  }',
'',
'  if ( $(this).text() === ''Confirmed'' ) {',
'',
'    $(this).css({"background-color":"#497620", "color" : "#FFFFFF"});',
'',
'  }',
'',
'  if ( $(this).text() === ''Cancelled'' ) {',
'',
'    $(this).css({"background-color":"#C33522", "color" : "#FFFFFF"});',
'',
'  }',
'',
'});',
'',
'$(''td[headers="ORDER_TYPE"]'').each(function() {  ',
'',
'  if ( $(this).text() === ''Composite'' ) {',
'    $(this).css({"background-color":"#FDF1F3"});',
'  }',
'',
'  if ( $(this).text() === ''Individual'' ) {',
'',
'    $(this).css({"background-color":"#FBF9DB"});',
'',
'  }',
'',
'});'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(40358076827937470123)
,p_name=>'Change cell color after refresh'
,p_event_sequence=>20
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(40242460151292369231)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterrefresh'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(40358076997077470124)
,p_event_id=>wwv_flow_imp.id(40358076827937470123)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''td[headers="ITEM_STATUS"]'').each(function() {  ',
'',
'  if ( $(this).text() === ''Pending'' ) {',
'',
'    $(this).css({"background-color":"#FFB929"});',
'  }',
'',
'  if ( $(this).text() === ''Confirmed'' ) {',
'',
'    $(this).css({"background-color":"#497620", "color" : "#FFFFFF"});',
'',
'  }',
'',
'  if ( $(this).text() === ''Cancelled'' ) {',
'',
'    $(this).css({"background-color":"#C33522", "color" : "#FFFFFF"});',
'',
'  }',
'',
'});',
'',
'$(''td[headers="ORDER_TYPE"]'').each(function() {  ',
'',
'  if ( $(this).text() === ''Composite'' ) {',
'    $(this).css({"background-color":"#FDF1F3"});',
'  }',
'',
'  if ( $(this).text() === ''Individual'' ) {',
'',
'    $(this).css({"background-color":"#FBF9DB"});',
'',
'  }',
'',
'});'))
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>6662355588643785590
,p_default_application_id=>214711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_RSWSP'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(40294674622737210446)
,p_name=>'Fetching order status'
,p_event_sequence=>30
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.confirm-order'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(40294674752306210447)
,p_event_id=>wwv_flow_imp.id(40294674622737210446)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P73_ITEM_STATUS'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'$(this.triggeringElement).parent().data(''status'');'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(40358078049747470135)
,p_name=>'Fetching order status on cancel'
,p_event_sequence=>40
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.del-order-item'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(40358078156678470136)
,p_event_id=>wwv_flow_imp.id(40358078049747470135)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P73_ITEM_STATUS'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'$(this.triggeringElement).parent().data(''status'');'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(40294674157311210441)
,p_name=>'Confirm Order'
,p_event_sequence=>50
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.confirm-order'
,p_condition_element=>'P73_ITEM_STATUS'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'Pending'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(40294674220456210442)
,p_event_id=>wwv_flow_imp.id(40294674157311210441)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'You are about to confirm the availability of the following product in the order. Once confirmed, this action cannot be reversed. Please ensure that you have the product ready for shipment soon !'
,p_attribute_02=>'Confirm Product Availability'
,p_attribute_03=>'success'
,p_attribute_04=>'fa-map-marker-check-o'
,p_attribute_06=>'Confirm Order'
,p_attribute_07=>'Canel'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(40313841690737579003)
,p_event_id=>wwv_flow_imp.id(40294674157311210441)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'Cannot Confirm an already confirmed/cancelled item'
,p_attribute_02=>'Confirm/Cancel Order'
,p_attribute_03=>'warning'
,p_attribute_04=>'fa-warning'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(40294674947077210449)
,p_event_id=>wwv_flow_imp.id(40294674157311210441)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P73_ORDER_ITEM_ID'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'$(this.triggeringElement).parent().data(''id'');'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(50516532558435306420)
,p_event_id=>wwv_flow_imp.id(40294674157311210441)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P73_ORDER_ID'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'$(this.triggeringElement).parent().data(''order'');'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(40294675079715210450)
,p_event_id=>wwv_flow_imp.id(40294674157311210441)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'MANAGE_ORDERS.update_order(''Confirmed'', :P73_ORDER_ITEM_ID, :P73_ORDER_ID);'
,p_attribute_02=>'P73_ORDER_ITEM_ID,P73_ORDER_ID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(40313841818540579005)
,p_event_id=>wwv_flow_imp.id(40294674157311210441)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'$(''#list-of-orders'').trigger(''apexrefresh'');'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(40358077074916470125)
,p_event_id=>wwv_flow_imp.id(40294674157311210441)
,p_event_result=>'TRUE'
,p_action_sequence=>70
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(79066338740063077626)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(40358077144816470126)
,p_event_id=>wwv_flow_imp.id(40294674157311210441)
,p_event_result=>'TRUE'
,p_action_sequence=>80
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(79066338846821077627)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(40358077245351470127)
,p_name=>'Cacel Order'
,p_event_sequence=>60
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.del-order-item'
,p_condition_element=>'P73_ITEM_STATUS'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'Pending'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(40358077373873470128)
,p_event_id=>wwv_flow_imp.id(40358077245351470127)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'Are you sure you want to cancel this order ? this action is irreversible and the buyer will be notified of the cancel !'
,p_attribute_02=>'Decline Order Item'
,p_attribute_03=>'danger'
,p_attribute_04=>'fa-map-marker-check-o'
,p_attribute_06=>'Cancel Order'
,p_attribute_07=>'Canel'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(40358077447948470129)
,p_event_id=>wwv_flow_imp.id(40358077245351470127)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'Cannot Confirm an already confirmed/cancelled order item'
,p_attribute_02=>'Confirm/Cancel Order'
,p_attribute_03=>'warning'
,p_attribute_04=>'fa-warning'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(40358077506791470130)
,p_event_id=>wwv_flow_imp.id(40358077245351470127)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P73_ORDER_ITEM_ID'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'$(this.triggeringElement).parent().data(''id'');'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(50516532688676306421)
,p_event_id=>wwv_flow_imp.id(40358077245351470127)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P73_ORDER_ID'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'$(this.triggeringElement).parent().data(''order'');'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(40358077652238470131)
,p_event_id=>wwv_flow_imp.id(40358077245351470127)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'MANAGE_ORDERS.update_order(''Cancelled'', :P73_ORDER_ITEM_ID, :P73_ORDER_ID);'
,p_attribute_02=>'P73_ORDER_ITEM_ID,P73_ORDER_ID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(40358077706612470132)
,p_event_id=>wwv_flow_imp.id(40358077245351470127)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'$(''#list-of-orders'').trigger(''apexrefresh'');'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(40358077830614470133)
,p_event_id=>wwv_flow_imp.id(40358077245351470127)
,p_event_result=>'TRUE'
,p_action_sequence=>70
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(79066338846821077627)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(40358077932310470134)
,p_event_id=>wwv_flow_imp.id(40358077245351470127)
,p_event_result=>'TRUE'
,p_action_sequence=>80
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(40242459207027369222)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(41154319019134227839)
,p_name=>'Jump To list of orders'
,p_event_sequence=>70
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.overall-summary-region'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(50516531859578306413)
,p_event_id=>wwv_flow_imp.id(41154319019134227839)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($(this.triggeringElement).data("id") === ''Total'') {',
'    $s("P73_FILTER_ORDERS", null);',
'} ',
'',
'else if (',
'    $(this.triggeringElement).data("id") === ''Pending'' || ',
'    $(this.triggeringElement).data("id") === ''Confirmed'' ||',
'    $(this.triggeringElement).data("id") === ''Cancelled'' ||',
'    $(this.triggeringElement).data("id") === ''Composite'' ||',
'    $(this.triggeringElement).data("id") === ''Individual'' ) {',
'        $s("P73_FILTER_ORDERS", $(this.triggeringElement).data("id"));',
'}'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(41154319125504227840)
,p_event_id=>wwv_flow_imp.id(41154319019134227839)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'let $region = $("#list-of-orders")[0]; ',
'',
'$region.scrollIntoView({ behavior: "smooth", block: "center", inline: "center" });'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(47738995127992838024)
,p_name=>'Toggle Full Order Details '
,p_event_sequence=>80
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.full-order'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(47738995819937838031)
,p_event_id=>wwv_flow_imp.id(47738995127992838024)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'console.log($(this.triggeringElement).parent().data(''id''))'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(47738995758215838030)
,p_event_id=>wwv_flow_imp.id(47738995127992838024)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_name=>'Setting Order ID'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P73_ORDER_NUMBER'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'$(this.triggeringElement).parent().data(''id'');'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(47738996443309838037)
,p_event_id=>wwv_flow_imp.id(47738995127992838024)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_name=>'Setting Order Type'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P73_ORDER_TYPE'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'$(this.triggeringElement).parent().data(''type'');'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(47738997450115838047)
,p_event_id=>wwv_flow_imp.id(47738995127992838024)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_name=>'Setting Other Order General Info'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    o.order_datetime,',
'    c.firstname || '' '' || c.lastname,',
'    c.phone,',
'    c.email',
'INTO ',
'    :P73_ORDER_DATE,',
'    :P73_BUYER_NAME,',
'    :P73_BUYER_PHONE,',
'    :P73_BUYER_EMAIL',
'FROM orders o',
'INNER JOIN customer c ON o.customer_id = c.customer_id',
'WHERE ORDER_ID = :P73_ORDER_NUMBER;',
''))
,p_attribute_02=>'P73_ORDER_NUMBER'
,p_attribute_03=>'P73_BUYER_NAME,P73_BUYER_EMAIL,P73_BUYER_PHONE,P73_ORDER_DATE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(47738995586973838028)
,p_event_id=>wwv_flow_imp.id(47738995127992838024)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_name=>'Setting Order Partners'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P73_ORDER_PARTNERS'
,p_attribute_01=>'FUNCTION_BODY'
,p_attribute_06=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE ',
'    l_sellers_name VARCHAR2(4000);',
'BEGIN',
'',
'    SELECT LISTAGG(c.firstname || '' '' ||c.lastname, '', '') WITHIN GROUP (ORDER BY c.firstname)',
'    INTO l_sellers_name',
'    FROM customer c',
'    LEFT JOIN stores s ON s.customer_id = c.customer_id',
'    LEFT JOIN product p ON p.store_id = s.store_id',
'    LEFT JOIN order_items oi ON p.product_id = oi.product_id',
'    WHERE NOT c.customer_id = :USER_ID AND oi.order_id = :P73_ORDER_NUMBER;',
'',
'    RETURN l_sellers_name;',
'END;'))
,p_attribute_07=>'P73_ORDER_NUMBER'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(47738995258796838025)
,p_event_id=>wwv_flow_imp.id(47738995127992838024)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_OPEN_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(47738994727276838020)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(52184847992700530111)
,p_event_id=>wwv_flow_imp.id(47738995127992838024)
,p_event_result=>'TRUE'
,p_action_sequence=>70
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(47738996768696838040)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(50516532151433306416)
,p_name=>'Filter Order Items'
,p_event_sequence=>90
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P73_FILTER_ORDERS'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(50516532203212306417)
,p_event_id=>wwv_flow_imp.id(50516532151433306416)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(40242460151292369231)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(52184850883192530140)
,p_name=>'Navigate To Orders List'
,p_event_sequence=>100
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(52184850964698530141)
,p_event_id=>wwv_flow_imp.id(52184850883192530140)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if($v("P73_FILTER_ORDERS") === ''Pending'') {',
'   setTimeout( ()=> {',
'        let $region = $("#list-of-orders")[0]; ',
'        $region.scrollIntoView({ behavior: "smooth", block: "center", inline: "center" });',
'   },500)',
'',
'}'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(52184851000256530142)
,p_event_id=>wwv_flow_imp.id(52184850883192530140)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_item_id NUMBER;',
' ',
'    CURSOR c1 IS',
'        SELECT line_item_id',
'        FROM order_items i',
'        JOIN product p ON p.product_id = i.product_id',
'        JOIN stores s ON s.store_id = p.store_id ',
'        WHERE s.customer_id = (:USER_ID); ',
'BEGIN',
'    IF :P73_FILTER_ORDERS = ''Pending'' THEN',
'        OPEN c1;',
'        LOOP',
'           FETCH c1 INTO l_item_id;',
'           EXIT WHEN c1%NOTFOUND;',
'',
'           UPDATE order_items',
'           SET is_new = ''No''',
'           WHERE line_item_id = l_item_id;',
'        END LOOP;',
'        CLOSE c1;',
'    END IF;',
'END;',
'',
''))
,p_attribute_02=>'USER_ID,P73_FILTER_ORDERS'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp.component_end;
end;
/
