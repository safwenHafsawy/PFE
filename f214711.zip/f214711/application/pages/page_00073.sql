prompt --application/pages/page_00073
begin
--   Manifest
--     PAGE: 00073
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>6662355588643785590
,p_default_application_id=>214711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_RSWSP'
);
wwv_flow_imp_page.create_page(
 p_id=>73
,p_name=>'Seller Dashboard Orders'
,p_alias=>'SELLER-DASHBOARD-ORDERS'
,p_step_title=>'Seller Dashboard Orders'
,p_autocomplete_on_off=>'OFF'
,p_css_file_urls=>'#APP_FILES#Styling/main_style#MIN#.css'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.overall-summary-region-container {',
'    padding: 20px;',
'}',
'',
'.overall-summary-region-row{',
'    padding: 0 0 50px;',
'}',
'',
'.overall-summary-region {',
'    margin: 0 10px 10px 10px;',
'    min-height: 100%;',
'    box-shadow: -1px 33px 35px -13px rgba(207,193,193,0.59);',
'    -webkit-box-shadow: -1px 33px 35px -13px rgba(207,193,193,0.59);',
'    -moz-box-shadow: -1px 33px 35px -13px rgba(207,193,193,0.59);',
'    border-radius: 10px !important;',
'    transition: all 300ms;',
'}',
'',
'.overall-summary-region:hover {',
'    transform: scale(1.05);',
'    box-shadow: -1px 33px 35px -20px rgba(207,193,193,0.99);',
'    -webkit-box-shadow: -1px 33px 35px -20px rgba(207,193,193,0.99);',
'    -moz-box-shadow: -1px 33px 35px -20px rgba(207,193,193,0.99);',
'}',
'',
'.overview {',
'    border-left: 10px solid var(--fouth-color);',
'    border-radius: 10px;',
'    padding-left: 10px;',
'    text-align: center;',
'}',
'',
'.overview-danger {',
'    border-left: 10px solid var(--danger-color);',
'    border-radius: 10px;',
'    padding-left: 10px;',
'    text-align: center;',
'}',
'',
'.overview-success{',
'    border-left: 10px solid var(--success-color);',
'    border-radius: 10px;',
'    padding-left: 10px;',
'    text-align: center;',
'}',
'',
'.overview-warning {',
'    border-left: 10px solid var(--warning-color);',
'    border-radius: 10px;',
'    padding-left: 10px;',
'    text-align: center;',
'}',
'',
'.overview-title {',
'    text-align: center;',
'    color: var(--fouth-color);',
'    font-family: var(--secondary-header-font);',
'    border-bottom: 1px solid rgba(211, 211, 211, 0.5);',
'    padding: 2px;',
'}',
'',
'.overview-title > span {',
'    margin-right: 5px;',
'}',
'',
'.overview-data {',
'    font-family: var(--regular-text-font );',
'}',
'',
'.overview-data-prod > span {',
'    font-size: xx-small;',
'    opacity: 0.6;',
'}',
'',
'',
'.t-Report-colHead{',
'    font-family: var(--secondary-header-font);',
'    text-align: center;',
'}',
'',
'.t-Report-cell{',
'    font-family: var(--regular-text-font);',
'    text-align: center;',
'}',
'',
'',
'.del-order {',
'    color: var(--danger-color);',
'}',
'',
'.confirm-order {',
'    color: var(--fouth-color);',
'}'))
,p_step_template=>wwv_flow_imp.id(19471509145742504218)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'25'
,p_last_updated_by=>'PFE94053@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20230723113103'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(39275505242159429143)
,p_plug_name=>'Seller Dashboard Navigation'
,p_region_sub_css_classes=>'dashboard-side-menu-list'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-LinksList--showArrow:t-LinksList--nowrap:t-LinksList--actions:t-LinksList--showTopIcons'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_02'
,p_list_id=>wwv_flow_imp.id(38784043417088031374)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(19471863408174504294)
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(40242460151292369231)
,p_name=>'List of orders'
,p_region_name=>'list-of-orders'
,p_template=>wwv_flow_imp.id(19471808805460504264)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody:margin-top-md'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--altRowsDefault:t-Report--rowHighlight:t-Report--inline:t-Report--hideNoPagination'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    distinct o.order_id, ',
'    c.firstname || '' '' ||  c.lastname, ',
'    c.phone, c.email, ',
'    o.order_datetime, ',
'    o.order_status, ',
'    o.order_information, ',
'    ''Check Order Products'' ,',
'    ''Confirm Order'',',
'    ''Cancel Order''',
'from    orders o, order_items oi, customer c, product p, stores s',
'where   o.customer_id = c.customer_id',
'    and     o.order_id = oi.order_id',
'    and     oi.product_id = p.product_id',
'    and     p.store_id = s.store_id',
'    and     s.customer_id = to_number(:USER_ID) ',
'order by o.order_datetime;'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(19471847069031504283)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(40358075810028470113)
,p_query_column_id=>1
,p_column_alias=>'ORDER_ID'
,p_column_display_sequence=>10
,p_column_heading=>'Order Number'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(40358075954287470114)
,p_query_column_id=>2
,p_column_alias=>'C.FIRSTNAME||''''||C.LASTNAME'
,p_column_display_sequence=>20
,p_column_heading=>'Customer Name'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(40358076047792470115)
,p_query_column_id=>3
,p_column_alias=>'PHONE'
,p_column_display_sequence=>30
,p_column_heading=>'Customer Phone'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(40358076157934470116)
,p_query_column_id=>4
,p_column_alias=>'EMAIL'
,p_column_display_sequence=>40
,p_column_heading=>'Customer Email'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(40358076214976470117)
,p_query_column_id=>5
,p_column_alias=>'ORDER_DATETIME'
,p_column_display_sequence=>50
,p_column_heading=>'Order Datetime'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(40358076391570470118)
,p_query_column_id=>6
,p_column_alias=>'ORDER_STATUS'
,p_column_display_sequence=>60
,p_column_heading=>'Order Status'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(40358076486657470119)
,p_query_column_id=>7
,p_column_alias=>'ORDER_INFORMATION'
,p_column_display_sequence=>70
,p_column_heading=>'Order Information'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(40358076546161470120)
,p_query_column_id=>8
,p_column_alias=>'''CHECKORDERPRODUCTS'''
,p_column_display_sequence=>80
,p_column_heading=>'Check Order''s Products'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:9:&SESSION.::&DEBUG.:9:P9_ORDER_ID:#ORDER_ID#'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-view.png" class="apex-edit-view" alt="">'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(40358076690585470121)
,p_query_column_id=>9
,p_column_alias=>'''CONFIRMORDER'''
,p_column_display_sequence=>90
,p_column_heading=>'Confirm Order'
,p_use_as_row_header=>'N'
,p_column_link=>'javascript:void(null)'
,p_column_linktext=>'<span aria-hidden="true" class="fa fa-check-square confirm-order"></span>'
,p_column_link_attr=>'data-id=#ORDER_ID# data-status=#ORDER_STATUS#'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(40358076705967470122)
,p_query_column_id=>10
,p_column_alias=>'''CANCELORDER'''
,p_column_display_sequence=>100
,p_column_heading=>'Cancel Order'
,p_use_as_row_header=>'N'
,p_column_link=>'javascript:void(null)'
,p_column_linktext=>'<span aria-hidden="true" class="fa fa-trash del-order"></span>'
,p_column_link_attr=>'data-id=#ORDER_ID# data-status=#ORDER_STATUS#'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(41154318934944227838)
,p_plug_name=>'Orders Calendar'
,p_region_template_options=>'#DEFAULT#:t-Region--stacked:t-Region--scrollBody:t-Form--labelsAbove'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT',
'    o.order_id,',
'    ''order number : '' || o.order_id  || '' '' ||'' Status : '' || o.order_status as order_desc,',
'    c.firstname || '' '' || c.lastname as customer_name,',
'    o.ORDER_DATETIME,',
'    case ORDER_STATUS',
'',
'        when ''Shipped'' then ''apex-cal-green''',
'',
'        when ''Pending'' then ''apex-cal-yellow''',
'',
'        when ''Cancelled'' then ''apex-cal-red''',
'',
'        when ''Confirmed'' then ''apex-cal-black''',
'',
'  end as css_class',
'FROM',
'    orders o, order_items oi, customer c, product p, stores s',
'WHERE',
'    o.customer_id = c.customer_id',
'    AND o.order_id = oi.order_id',
'    AND oi.product_id = p.product_id',
'    AND p.store_id = s.store_id',
'    AND s.customer_id = TO_NUMBER(:USER_ID) ',
''))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CSS_CALENDAR'
,p_attribute_01=>'ORDER_DATETIME'
,p_attribute_03=>'ORDER_DESC'
,p_attribute_04=>'ORDER_ID'
,p_attribute_07=>'N'
,p_attribute_09=>'list:navigation'
,p_attribute_13=>'N'
,p_attribute_14=>'CSS_CLASS'
,p_attribute_16=>'order by &CUSTOMER_NAME.'
,p_attribute_17=>'N'
,p_attribute_19=>'Y'
,p_attribute_21=>'20'
,p_attribute_22=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(79066338432320077623)
,p_plug_name=>'Orders Overview'
,p_region_name=>'order-overview'
,p_region_css_classes=>'overall-summary-region-container'
,p_region_template_options=>'#DEFAULT#:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_08'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(40242459207027369222)
,p_plug_name=>'Cancelled'
,p_parent_plug_id=>wwv_flow_imp.id(79066338432320077623)
,p_region_css_classes=>'overall-summary-region'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>4
,p_plug_display_point=>'SUB_REGIONS'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    orders_cancelled number;',
'begin',
'    select  count(distinct o.order_id)',
'    into    orders_cancelled',
'    from    orders o, order_items oi, product p, stores s',
'    where   o.order_status = ''Cancelled''  ',
'    and     o.order_id = oi.order_id',
'    and     oi.product_id = p.product_id',
'    and     p.store_id = s.store_id',
'    and     s.customer_id = to_number(:USER_ID) ;',
'',
'    return ',
'        '' <div class="overview-danger">',
'        <h3 class="overview-title"> Cancelled</h3>',
'        <h4 class="overview-data">'' || orders_cancelled || '' Order(s)',
'        </h4>',
'        </div> '';',
'end;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(40242459377251369223)
,p_plug_name=>'Shipped'
,p_parent_plug_id=>wwv_flow_imp.id(79066338432320077623)
,p_region_css_classes=>'overall-summary-region'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>4
,p_plug_display_point=>'SUB_REGIONS'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    orders_shipped number;',
'begin',
'    select  count(distinct o.order_id)',
'    into    orders_shipped',
'    from    orders o, order_items oi, product p, stores s',
'    where   o.order_status = ''Shipped''  ',
'    and     o.order_id = oi.order_id',
'    and     oi.product_id = p.product_id',
'    and     p.store_id = s.store_id',
'    and     s.customer_id = to_number(:USER_ID) ;',
'',
'    return ',
'        '' <div class="overview-success">',
'        <h3 class="overview-title"> Shipped Orders</h3>',
'        <h4 class="overview-data">'' || orders_shipped || '' Order(s)',
'        </h4>',
'        </div> '';',
'end;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(79066338607683077625)
,p_plug_name=>'Total Orders'
,p_parent_plug_id=>wwv_flow_imp.id(79066338432320077623)
,p_region_css_classes=>'overall-summary-region'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>10
,p_plug_grid_row_css_classes=>'overall-summary-region-row'
,p_plug_grid_column_span=>5
,p_plug_display_column=>2
,p_plug_display_point=>'SUB_REGIONS'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    l_number_of_orders number;',
'begin',
'     select  count(distinct o.order_id)',
'    into    l_number_of_orders',
'    from    orders o, order_items oi, product p, stores s',
'    where   o.order_id = oi.order_id',
'    and     oi.product_id = p.product_id',
'    and     p.store_id = s.store_id',
'    and     s.customer_id = to_number(:USER_ID) ;',
'',
'    return ',
'        '' <div class="overview">',
'        <h3 class="overview-title"> Total Orders</h3>',
'        <h4 class="overview-data">'' || l_number_of_orders || '' Order(s)',
'        </h4>',
'        </div> '';',
'end;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(79066338740063077626)
,p_plug_name=>'Confirmed'
,p_parent_plug_id=>wwv_flow_imp.id(79066338432320077623)
,p_region_css_classes=>'overall-summary-region'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>5
,p_plug_display_point=>'SUB_REGIONS'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    confirmed_orders number := 0;',
'begin',
'    select  count(distinct o.order_id)',
'    into    confirmed_orders',
'    from    orders o, order_items oi, product p, stores s',
'    where   o.order_status = ''Confirmed''',
'    and     o.order_id = oi.order_id',
'    and     oi.product_id = p.product_id',
'    and     p.store_id = s.store_id',
'    and     s.customer_id = to_number(:USER_ID) ;',
'',
'    return ',
'        ''<div class="overview">',
'            <h3 class="overview-title"> Confirmed Orders </h3>',
'            <h4 class="overview-data">'' || confirmed_orders || '' orders(s)',
'            </h4>',
'            </div> '';',
'end;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(79066338846821077627)
,p_plug_name=>'Pending'
,p_parent_plug_id=>wwv_flow_imp.id(79066338432320077623)
,p_region_css_classes=>'overall-summary-region'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>30
,p_plug_grid_column_span=>4
,p_plug_display_point=>'SUB_REGIONS'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    orders_pending number;',
'begin',
'    select  count(distinct o.order_id)',
'    into    orders_pending',
'    from    orders o, order_items oi, product p, stores s',
'    where   o.order_status = ''Pending''  ',
'    and     o.order_id = oi.order_id',
'    and     oi.product_id = p.product_id',
'    and     p.store_id = s.store_id',
'    and     s.customer_id = to_number(:USER_ID) ;',
'',
'    return ',
'        '' <div class="overview-warning">',
'        <h3 class="overview-title"> Pending Orders</h3>',
'        <h4 class="overview-data">'' || orders_pending || '' Order(s)',
'        </h4>',
'        </div> '';',
'end;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(40294674489649210444)
,p_name=>'P73_ORDER_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(40242460151292369231)
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(40294674556588210445)
,p_name=>'P73_ORDER_STATUS'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(40242460151292369231)
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41154319228211227841)
,p_name=>'P73_FILTER_ORDERS'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(40294673744313210437)
,p_name=>'Change cell color'
,p_event_sequence=>10
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(40294673802423210438)
,p_event_id=>wwv_flow_imp.id(40294673744313210437)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''td[headers="ORDER_STATUS"]'').each(function() {  ',
'',
'  if ( $(this).text() === ''Pending'' ) {',
'',
'    $(this).css({"background-color":"#FFB929"});',
'  }',
'',
'  if ( $(this).text() === ''Confirmed'' ) {',
'',
'    $(this).css({"background-color":"#3A3632"});',
'',
'  }',
'',
'  if ( $(this).text() === ''Confirmed'' ) {',
'',
'    $(this).css({"background-color":"#3A3632", "color" : "#F5F4F2"});',
'',
'  }',
'',
'  if ( $(this).text() === ''Cancelled'' ) {',
'',
'    $(this).css({"background-color":"#C33522", "color" : "#F5F4F2"});',
'',
'  }',
'',
'  if ( $(this).text() === ''Shipped'' ) {',
'',
'    $(this).css({"background-color":"#497620", "color" : "#F5F4F2"});',
'',
'  }',
'',
'',
'',
'',
'});'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(40358076827937470123)
,p_name=>'Change cell color after refresh'
,p_event_sequence=>20
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(40242460151292369231)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterrefresh'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(40358076997077470124)
,p_event_id=>wwv_flow_imp.id(40358076827937470123)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''td[headers="ORDER_STATUS"]'').each(function() {  ',
'',
'  if ( $(this).text() === ''Pending'' ) {',
'',
'    $(this).css({"background-color":"#FFB929"});',
'  }',
'',
'  if ( $(this).text() === ''Confirmed'' ) {',
'',
'    $(this).css({"background-color":"#3A3632"});',
'',
'  }',
'',
'  if ( $(this).text() === ''Confirmed'' ) {',
'',
'    $(this).css({"background-color":"#3A3632", "color" : "#F5F4F2"});',
'',
'  }',
'',
'  if ( $(this).text() === ''Cancelled'' ) {',
'',
'    $(this).css({"background-color":"#C33522"});',
'',
'  }',
'',
'  if ( $(this).text() === ''Shipped'' ) {',
'',
'    $(this).css({"background-color":"#497620"});',
'',
'  }',
'',
'',
'',
'',
'});'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(40294674622737210446)
,p_name=>'Fetching order status'
,p_event_sequence=>30
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.confirm-order'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(40294674752306210447)
,p_event_id=>wwv_flow_imp.id(40294674622737210446)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P73_ORDER_STATUS'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'$(this.triggeringElement).parent().data(''status'');'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(40358078049747470135)
,p_name=>'Fetching order status on cancel'
,p_event_sequence=>40
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.del-order'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(40358078156678470136)
,p_event_id=>wwv_flow_imp.id(40358078049747470135)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P73_ORDER_STATUS'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'$(this.triggeringElement).parent().data(''status'');'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(40294674157311210441)
,p_name=>'Confirm Order'
,p_event_sequence=>50
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.confirm-order'
,p_condition_element=>'P73_ORDER_STATUS'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'Pending'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(40294674220456210442)
,p_event_id=>wwv_flow_imp.id(40294674157311210441)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'Are you sure you want to confirm this order ? this will begin the order shipping process !'
,p_attribute_02=>'Confirm This Order'
,p_attribute_03=>'success'
,p_attribute_04=>'fa-map-marker-check-o'
,p_attribute_06=>'Confirm Order'
,p_attribute_07=>'Canel'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(40313841690737579003)
,p_event_id=>wwv_flow_imp.id(40294674157311210441)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'Cannot Confirm an already confirmed/cancelled order'
,p_attribute_02=>'Confirm/Cancel Order'
,p_attribute_03=>'warning'
,p_attribute_04=>'fa-warning'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(40294674947077210449)
,p_event_id=>wwv_flow_imp.id(40294674157311210441)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P73_ORDER_ID'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'$(this.triggeringElement).parent().data(''id'');'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(40294675079715210450)
,p_event_id=>wwv_flow_imp.id(40294674157311210441)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'update orders set order_status = ''Confirmed'' where order_id = :P73_ORDER_ID;'
,p_attribute_02=>'P73_ORDER_ID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(40313841818540579005)
,p_event_id=>wwv_flow_imp.id(40294674157311210441)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'$(''#list-of-orders'').trigger(''apexrefresh'');'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(40358077074916470125)
,p_event_id=>wwv_flow_imp.id(40294674157311210441)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(79066338740063077626)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(40358077144816470126)
,p_event_id=>wwv_flow_imp.id(40294674157311210441)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(79066338846821077627)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(40358077245351470127)
,p_name=>'Cacel Order'
,p_event_sequence=>60
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.del-order'
,p_condition_element=>'P73_ORDER_STATUS'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'Pending'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(40358077373873470128)
,p_event_id=>wwv_flow_imp.id(40358077245351470127)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'Are you sure you want to cancel this order ? this action is irreversible and the buyer will be notified of the cancel !'
,p_attribute_02=>'Cancel Order'
,p_attribute_03=>'danger'
,p_attribute_04=>'fa-map-marker-check-o'
,p_attribute_06=>'Cancel Order'
,p_attribute_07=>'Canel'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(40358077447948470129)
,p_event_id=>wwv_flow_imp.id(40358077245351470127)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'Cannot Confirm an already confirmed/cancelled order'
,p_attribute_02=>'Confirm/Cancel Order'
,p_attribute_03=>'warning'
,p_attribute_04=>'fa-warning'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(40358077506791470130)
,p_event_id=>wwv_flow_imp.id(40358077245351470127)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P73_ORDER_ID'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'$(this.triggeringElement).parent().data(''id'');'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(40358077652238470131)
,p_event_id=>wwv_flow_imp.id(40358077245351470127)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'update orders set order_status = ''Cancelled'' where order_id = :P73_ORDER_ID;'
,p_attribute_02=>'P73_ORDER_ID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(40358077706612470132)
,p_event_id=>wwv_flow_imp.id(40358077245351470127)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'$(''#list-of-orders'').trigger(''apexrefresh'');'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(40358077830614470133)
,p_event_id=>wwv_flow_imp.id(40358077245351470127)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(79066338846821077627)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(40358077932310470134)
,p_event_id=>wwv_flow_imp.id(40358077245351470127)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(40242459207027369222)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(41154319019134227839)
,p_name=>'Jump To list of orders'
,p_event_sequence=>70
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.overall-summary-region'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(41154319125504227840)
,p_event_id=>wwv_flow_imp.id(41154319019134227839)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'let $region = $("#list-of-orders")[0]; ',
'console.log($region)',
'$region.scrollIntoView({ behavior: "smooth", block: "center", inline: "center" });'))
);
wwv_flow_imp.component_end;
end;
/
