prompt --application/pages/page_00005
begin
--   Manifest
--     PAGE: 00005
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>6662355588643785590
,p_default_application_id=>214711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_RSWSP'
);
wwv_flow_imp_page.create_page(
 p_id=>5
,p_name=>'Store Management'
,p_alias=>'STORE-MANAGEMENT'
,p_step_title=>'&APP_NAME. - Store Management'
,p_autocomplete_on_off=>'OFF'
,p_css_file_urls=>'#APP_FILES#Styling/main_style#MIN#.css'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.store-header-container {',
'    text-align: center;',
'}',
'',
'.store-name{',
'    font-family: var(--main-header-font);',
'    color: var(--fouth-color);',
'}',
'',
'.store-logo {',
'    display: flex;',
'    flex-direction: column;',
'    justify-content: center;',
'    align-items: center;',
'}',
'',
'.store-logo img{',
'    border: 5px solid var(--fouth-color);',
'    border-radius: 50%;',
'}',
'',
'.store-description {',
'    border: 1px solid var(--fouth-color);',
'}',
'',
'',
'.store-description  .t-Region-header {',
'    font-family: ''Courier New'', Courier, monospace;',
'    color: var(--fouth-color);',
'}',
'',
'.products-container {',
'    min-height: 100%;',
'    padding: 50px;',
'    background-color: #FFFFFF;',
'    border: 1px solid #ebeae9;',
'    border-radius: 10px;',
'}',
'',
'',
'.button-container {',
'    width: 100%;',
'    background-color: #F1EFED;',
'    border-radius: 10px;',
'    box-shadow: none;',
'}',
''))
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'22'
,p_last_updated_by=>'PFE94053@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20230724132914'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(21365795184513797113)
,p_plug_name=>'Button Container'
,p_region_css_classes=>'button-container'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(19471545059842504235)
,p_plug_display_sequence=>110
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'',
''))
,p_landmark_type=>'exclude_landmark'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(21365797738482797139)
,p_plug_name=>'Store Logo'
,p_region_name=>'store_logo'
,p_plug_display_sequence=>90
,p_plug_grid_column_span=>12
,p_plug_grid_column_css_classes=>'store-logo'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    STORE_ID, ',
'    LOGO, ',
'    LOGO_MIME_TYPE, ',
'    LOGO_FILENAME, ',
'    LOGO_CHARSET,',
'    LOGO_LAST_UPDATED',
'FROM stores',
'WHERE store_id = TO_NUMBER(:P5_STORE_ID);'))
,p_template_component_type=>'PARTIAL'
,p_lazy_loading=>true
,p_plug_source_type=>'TMPL_THEME_42$AVATAR'
,p_attribute_01=>'IMAGE'
,p_attribute_02=>'{"source":"BLOB_COLUMN","blobColumn":"LOGO","filenameColumn":"LOGO_FILENAME","mimeTypeColumn":"LOGO_MIME_TYPE","lastUpdatedColumn":"LOGO_LAST_UPDATED"}'
,p_attribute_06=>'t-Avatar--circle'
,p_attribute_07=>'t-Avatar--lg'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(22774972378695912407)
,p_name=>'STORE_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'STORE_ID'
,p_data_type=>'NUMBER'
,p_display_sequence=>10
,p_use_as_row_header=>false
,p_is_primary_key=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(22774972528649912409)
,p_name=>'LOGO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LOGO'
,p_data_type=>'BLOB'
,p_display_sequence=>30
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(22774972974110912413)
,p_name=>'LOGO_MIME_TYPE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LOGO_MIME_TYPE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>50
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(22774973080357912414)
,p_name=>'LOGO_FILENAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LOGO_FILENAME'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>60
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(22774973136622912415)
,p_name=>'LOGO_CHARSET'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LOGO_CHARSET'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>70
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(22774973259161912416)
,p_name=>'LOGO_LAST_UPDATED'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LOGO_LAST_UPDATED'
,p_data_type=>'DATE'
,p_display_sequence=>80
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(21951574172152991001)
,p_plug_name=>'Store''s Products'
,p_region_css_classes=>'products-container'
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--styleB'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(19471549395551504237)
,p_plug_display_sequence=>130
,p_plug_new_grid_row=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT p.product_id,',
'        p.product_name,',
'        p.unit_price,',
'        discount,',
'        p.category_id,',
'        NEW_PRICE (P.PRODUCT_ID) new_price,',
'        pi.image',
'FROM    product p',
'        join (SELECT image_id,',
'            product_id,',
'            image',
'            FROM(SELECT image_id,',
'                        product_id,',
'                        image,',
'                        Row_number()',
'                            over (',
'                            PARTITION BY product_id',
'                            ORDER BY image_id) AS rn',
'                FROM   product_images) img',
'                WHERE  rn = 1) pi',
'        ON p.product_id = pi.product_id',
'WHERE  store_id = :P5_STORE_ID;',
''))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_ajax_items_to_submit=>'P5_STORE_ID'
,p_plug_query_num_rows_type=>'SCROLL'
,p_plug_query_no_data_found=>'Looks Like This Store is empty'
,p_no_data_found_icon_classes=>'fa-database-x'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(21951574218242991002)
,p_region_id=>wwv_flow_imp.id(21951574172152991001)
,p_layout_type=>'GRID'
,p_grid_column_count=>4
,p_component_css_classes=>'store-products'
,p_card_css_classes=>'card'
,p_title_adv_formatting=>false
,p_title_column_name=>'PRODUCT_NAME'
,p_title_css_classes=>'card-header'
,p_sub_title_adv_formatting=>true
,p_sub_title_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{case DISCOUNT/}',
'{when 0/}',
'<b>&NEW_PRICE. TND</b>',
'{otherwise/}',
'&DISCOUNT.% &emsp;',
'<b>&NEW_PRICE. TN </b>&emsp;',
'<s> &UNIT_PRICE. TN</s>',
'',
'',
'{endcase/}'))
,p_body_adv_formatting=>false
,p_body_css_classes=>'card-details'
,p_second_body_adv_formatting=>false
,p_media_adv_formatting=>false
,p_media_source_type=>'BLOB'
,p_media_blob_column_name=>'IMAGE'
,p_media_display_position=>'FIRST'
,p_media_appearance=>'SQUARE'
,p_media_sizing=>'COVER'
,p_pk1_column_name=>'PRODUCT_ID'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(21951575113325991011)
,p_card_id=>wwv_flow_imp.id(21951574218242991002)
,p_action_type=>'FULL_CARD'
,p_display_sequence=>20
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:60:&SESSION.::&DEBUG.:29:P60_PRODUCT_ID,P60_PRODUCT_NAME,P60_UNIT_PRICE,P60_STORE_ID,P60_CATEGORY_ID,P60_DISCOUNT,P60_PRODUCT_DESCRIPTION:&PRODUCT_ID.,&PRODUCT_NAME.,&UNIT_PRICE.,&STORE_ID.,&CATEGORY_ID.,&DISCOUNT.,&PRODUCT_DESCRIPTION.'
,p_condition_type=>'FUNCTION_BODY'
,p_condition_expr1=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_owner_id number;',
'BEGIN',
'    SELECT customer_id',
'    INTO l_owner_id',
'    FROM stores',
'    WHERE store_id = :P5_STORE_ID;',
'',
'    RETURN to_number(:USER_ID) = l_owner_id;',
'END;'))
,p_condition_expr2=>'PLSQL'
,p_exec_cond_for_each_row=>true
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(35681588475377205040)
,p_card_id=>wwv_flow_imp.id(21951574218242991002)
,p_action_type=>'FULL_CARD'
,p_display_sequence=>30
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:18:&SESSION.::&DEBUG.:18:P18_PRODUCT_ID:&PRODUCT_ID.'
,p_condition_type=>'FUNCTION_BODY'
,p_condition_expr1=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_owner_id number;',
'BEGIN',
'    SELECT customer_id',
'    INTO l_owner_id',
'    FROM stores',
'    WHERE store_id = :P5_STORE_ID;',
'',
'    RETURN NOT to_number(:USER_ID) = l_owner_id;',
'END;'))
,p_condition_expr2=>'PLSQL'
,p_exec_cond_for_each_row=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(22774973481472912418)
,p_plug_name=>'Page Header'
,p_region_css_classes=>'page-header-container'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>100
,p_plug_grid_column_css_classes=>'store-header-container'
,p_plug_source=>'<h3 class=''store-name''>&P5_STORE_NAME.</h3>'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(33975088922486940905)
,p_plug_name=>'Store Details'
,p_parent_plug_id=>wwv_flow_imp.id(22774973481472912418)
,p_region_css_classes=>'store-description'
,p_region_template_options=>'#DEFAULT#:t-Region--hiddenOverflow'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>6
,p_plug_display_column=>4
,p_plug_display_point=>'SUB_REGIONS'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_store_description varchar2(250);',
'    l_email varchar2(100);',
'    l_phone varchar2(100);',
'begin',
'',
'    if :P5_STORE_ID is not null then',
'        select ',
'            store_description,',
'            email,',
'            phone',
'        into ',
'            l_store_description,',
'            l_email,',
'            l_phone',
'        from ',
'            stores s, customer c',
'        where ',
'            s.store_id = :P5_STORE_ID',
'        and',
'            s.customer_id = c.customer_id;',
'        ',
'        return ',
'            ''<b> Description : </b> '' || l_store_description || ''<br>'' ||',
'            ''<b> Phone Number : </b>'' || l_phone || '' <br>'' ||',
'            ''<b> Email : </b>'' || l_email ||'' <br>'';',
'    end if;',
'end;',
''))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
,p_ajax_items_to_submit=>'P5_STORE_ID'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(22774975268139912436)
,p_plug_name=>'Filter Products'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>120
,p_plug_grid_column_span=>3
,p_plug_source_type=>'NATIVE_FACETED_SEARCH'
,p_filtered_region_id=>wwv_flow_imp.id(21951574172152991001)
,p_attribute_01=>'N'
,p_attribute_06=>'N'
,p_attribute_09=>'N'
,p_attribute_12=>'10000'
,p_attribute_13=>'N'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(42153515729179704825)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(21365795184513797113)
,p_button_name=>'Message_Owner'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--success:t-Button--iconRight:t-Button--hoverIconPush'
,p_button_template_id=>wwv_flow_imp.id(19471882117602504304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Message Store Owner'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:80:&SESSION.::&DEBUG.:80:P80_PARTICIPANT_1_ID,P80_PARTICIPANT_2_ID:&USER_ID.,&P5_STORE_OWNER_ID.'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_owner_id number;',
'BEGIN',
'    SELECT customer_id',
'    INTO l_owner_id',
'    FROM stores',
'    WHERE store_id = :P5_STORE_ID;',
'',
'    RETURN NOT to_number(:USER_ID) = l_owner_id;',
'END;'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'FUNCTION_BODY'
,p_icon_css_classes=>'fa-send'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(21951579030477991050)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(21365795184513797113)
,p_button_name=>'ADD_PRODUCT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(19471882117602504304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add Product'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:40:&SESSION.::&DEBUG.:40:P40_STORE_ID:&P5_STORE_ID.'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_owner_id number;',
'BEGIN',
'    SELECT customer_id',
'    INTO l_owner_id',
'    FROM stores',
'    WHERE store_id = :P5_STORE_ID;',
'',
'    RETURN to_number(:USER_ID) = l_owner_id;',
'END;'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'FUNCTION_BODY'
,p_icon_css_classes=>'fa-plus-square'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(21951578956363991049)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(21365795184513797113)
,p_button_name=>'EDIT_STORE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--success:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(19471882117602504304)
,p_button_image_alt=>'Edit Store'
,p_button_position=>'PREVIOUS'
,p_button_redirect_url=>'f?p=&APP_ID.:30:&SESSION.::&DEBUG.:30:P30_STORE_NAME,P30_STORE_ID,P30_LOGO:&P5_STORE_NAME.,&P5_STORE_ID.,&P5_STORE_LOGO.'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_owner_id number;',
'BEGIN',
'    SELECT customer_id',
'    INTO l_owner_id',
'    FROM stores',
'    WHERE store_id = :P5_STORE_ID;',
'',
'    RETURN to_number(:USER_ID) = l_owner_id;',
'END;'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'FUNCTION_BODY'
,p_icon_css_classes=>'fa-pencil'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(21365795058701797112)
,p_name=>'P5_STORE_ID'
,p_item_sequence=>10
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(21365795245197797114)
,p_name=>'P5_STORE_NAME'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(21951576115934991021)
,p_name=>'P5_STORE_LOGO'
,p_item_sequence=>40
,p_use_cache_before_default=>'NO'
,p_source=>'P5_STORE_LOGO'
,p_source_type=>'ITEM'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(22774975724019912441)
,p_name=>'P5_SEARCH_PROD'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(22774975268139912436)
,p_prompt=>'search'
,p_source=>'PRODUCT_NAME,PRODUCT_DESCRIPTION,PRODUCT_DETAILS,,IMAGE_FILENAME'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'ROW'
,p_attribute_02=>'FACET'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(35681588104105205037)
,p_name=>'P5_FILTER_WITH_PRICE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(22774975268139912436)
,p_prompt=>'Filter With Price'
,p_source=>'UNIT_PRICE'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_RANGE'
,p_lov=>'STATIC:Less Than 10 TDN;|10,From 10 to 50 TDN;20|50,From 50 To 100 TDN;50|100,From 100 To 200 TDN;100|200,From 200 To 300 TDN;200|300,More Than 100 TDN;300|'
,p_item_icon_css_classes=>'fa-dollar'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'D'
,p_fc_show_more_count=>7
,p_fc_filter_values=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>false
,p_fc_actions_filter=>true
,p_fc_toggleable=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(35681588244610205038)
,p_name=>'P5_HAS_DISCOUNT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(22774975268139912436)
,p_prompt=>'Filter With Discount'
,p_source=>'DISCOUNT'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_RANGE'
,p_lov=>'STATIC:More Than 5%;5|,More Than 10%;10|,More Than 25%;25|,More Than 50%;50|,More Than 75%;75|'
,p_item_icon_css_classes=>'fa-fire'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'D'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_show_selected_first=>false
,p_fc_show_chart=>false
,p_fc_actions_filter=>true
,p_fc_toggleable=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37036232203554922402)
,p_name=>'P5_CATEGORIES'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(22774975268139912436)
,p_prompt=>'Available Categories'
,p_source=>'CATEGORY_ID'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT ',
'    c.category_name, c.category_id',
'FROM ',
'    categories c, product p',
'WHERE',
'    c.category_id = p.category_id',
'    AND p.store_id = :P5_STORE_ID;'))
,p_item_icon_css_classes=>'fa-spinner'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_05=>'N'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'D'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_toggleable=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(42153515856346704826)
,p_name=>'P5_STORE_OWNER_ID'
,p_item_sequence=>80
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(21951575314174991013)
,p_name=>'Refresh Products After Update/ Deletion'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(21951574172152991001)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(21951575459005991014)
,p_event_id=>wwv_flow_imp.id(21951575314174991013)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(21951574172152991001)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(22774973656729912420)
,p_name=>'Refresh Avatar'
,p_event_sequence=>20
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(21365795184513797113)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(22774973718013912421)
,p_event_id=>wwv_flow_imp.id(22774973656729912420)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(21365797738482797139)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(22774973990295912423)
,p_name=>'Refresh Products After Creation'
,p_event_sequence=>30
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(21365795184513797113)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(22774974052477912424)
,p_event_id=>wwv_flow_imp.id(22774973990295912423)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(21951574172152991001)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(22774974156208912425)
,p_name=>'Refresh Product Header'
,p_event_sequence=>40
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(21365795184513797113)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(22774974255925912426)
,p_event_id=>wwv_flow_imp.id(22774974156208912425)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT store_name',
'INTO :P5_STORE_NAME ',
'FROM stores',
'WHERE store_id = :P5_STORE_ID;'))
,p_attribute_02=>'P5_STORE_ID'
,p_attribute_03=>'P5_STORE_NAME'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(22774974339226912427)
,p_event_id=>wwv_flow_imp.id(22774974156208912425)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(22774973481472912418)
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'document.getElementsByClassName("store-name")[0].innerHTML = `<h3 class="store-name">${$v(''P5_STORE_NAME'')}</h3>`;',
'',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(33975088637960940902)
,p_name=>'Getting Store Details'
,p_event_sequence=>50
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(33975088745147940903)
,p_event_id=>wwv_flow_imp.id(33975088637960940902)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    s.store_name',
'INTO',
'    :P5_STORE_NAME',
'FROM',
'    stores s',
'WHERE',
'    s.store_id = :P5_STORE_ID;',
''))
,p_attribute_03=>'P5_STORE_NAME'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp.component_end;
end;
/
