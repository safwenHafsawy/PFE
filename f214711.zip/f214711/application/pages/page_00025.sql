prompt --application/pages/page_00025
begin
--   Manifest
--     PAGE: 00025
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>6662355588643785590
,p_default_application_id=>214711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_RSWSP'
);
wwv_flow_imp_page.create_page(
 p_id=>25
,p_name=>'Checkout Information'
,p_alias=>'CHECKOUT-INFORMATION'
,p_step_title=>'Checkout Information'
,p_autocomplete_on_off=>'OFF'
,p_css_file_urls=>'#APP_FILES#Styling/main_style#MIN#.css'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Region-title {',
'    font-family: var(--secondary-header-font);',
'    text-align: center;',
'}',
'',
'.customer-information {',
'    background-color: var(--second-color );',
'    border-radius: 5px;',
'    padding: 15px;',
'}',
'',
'.order-information {',
'',
'}',
'',
'.product-names {',
'    font-family: ''Courier New'', Courier, monospace;',
'}',
'',
'.subtotal {',
'    text-align: center;',
'    font-family: ''Courier New'', Courier, monospace;',
'}',
'',
'/*apex-item-radio {',
'    display: flex;',
'    justify-content: center;',
'    align-items: center;',
'}',
'.t-Form-fieldContainer--radioButtonGroup .apex-item-grid .apex-item-grid-row:only-child .apex-item-option{',
'      width: 50%; ',
' }',
'',
'.t-Form-fieldContainer--radioButtonGroup .apex-item-grid .apex-item-grid-row:only-child .apex-item-option:first-of-type label{',
'    border: 2px solid #3A3632;',
'    border-right-style: none;',
'    text-align: center;',
'    font-family: ''Courier New'', Courier, monospace;',
'    border-radius: 10px 0 0 10px;',
'}',
'',
'.t-Form-fieldContainer--radioButtonGroup .apex-item-grid .apex-item-grid-row:only-child .apex-item-option:last-of-type label {',
'    width: 100%;',
'    border: 2px solid #3A3632;',
'    border-left-style: none;',
'    text-align: center;',
'    font-family: ''Courier New'', Courier, monospace;',
'    border-radius: 0 10px 10px 0;',
'}*/',
'',
'',
'/*#payement{',
'   ',
'   ',
'    ',
'}',
'#P25_PAYMENT_CONTAINER{',
'    background-color: aqua;',
'    border:none;',
'}*/',
'',
'#P25_PAYMENT_DISPLAY{',
'    ',
'    border:none;',
'',
'}',
'#P25_TOTAL_PRICE_DISPLAY{',
'   /* background-color: #F5F4F2;#FBF9F8;',
'    color: black;',
'    border:none;',
'    border-top:1px solid  #D3D3D3;',
'    padding-top: 10px;*/',
'}',
'',
'#R25231223624811482238_heading{',
'    border-bottom:1px solid  #D3D3D3;',
'    font-weight: bolder;',
'    padding-bottom: 10px;',
'    margin: 0;',
'}',
'',
'#R25231223761086482239_heading{',
'     border-bottom:1px solid  #D3D3D3 ;',
'     text-align: center;',
'     padding-bottom: 10px;',
'     margin: 0;',
'}',
'',
'.box{',
'    border:1px solid #D3D3D3;',
'    border-radius: 0px;',
'    padding: 10px;',
'}',
'#R25231223953271482241_heading{',
'    border-bottom: 1px solid  #D3D3D3;',
'    padding-bottom: 10px;',
'     margin: 0;',
'}',
'',
'#P25_TOTAL_PRICE_DISPLAY{',
'    ',
'}',
'',
'.payement-method {',
'    border: 1px solid  #D3D3D3;',
'    ',
'}',
'#P25_PAYMENT{',
'    padding: 10px;',
'}',
'',
'#P25_NEW_DISPLAY{',
'    border: none;',
'    padding-left: 20px;',
'    color: #757171;',
'    font-family: ''Courier New'', Courier, monospace;',
'    font-size:medium;',
'    padding-top: 0%;',
'    ',
'}',
'',
'.subtotal {',
'    font-weight: bold;',
'}',
'',
'',
'',
'',
''))
,p_page_css_classes=>'checkout-page'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'16'
,p_last_updated_by=>'PFE94053@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20230817142907'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(25231221796754482219)
,p_plug_name=>'Checkout Information'
,p_region_template_options=>'#DEFAULT#:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>6
,p_plug_grid_column_css_classes=>'customer-information'
,p_plug_display_column=>1
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(25231222812611482230)
,p_plug_name=>'My Order'
,p_region_css_classes=>'orders'
,p_region_template_options=>'#DEFAULT#:t-Region--noUI:t-Region--scrollBody:margin-left-sm:margin-right-md'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_grid_column_css_classes=>'order-information'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(26416295060769440226)
,p_plug_name=>'Payment Method'
,p_region_name=>'payement'
,p_parent_plug_id=>wwv_flow_imp.id(25231222812611482230)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>60
,p_plug_grid_column_css_classes=>'payement-method'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(27304123013623190634)
,p_plug_name=>'box'
,p_parent_plug_id=>wwv_flow_imp.id(25231222812611482230)
,p_region_css_classes=>'box'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>10
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(25231223624811482238)
,p_plug_name=>'Product'
,p_parent_plug_id=>wwv_flow_imp.id(27304123013623190634)
,p_region_css_classes=>'product-names'
,p_region_template_options=>'#DEFAULT#:t-Region--noUI:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>6
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'  seq_id item, ',
'  p.product_id, ',
'  p.product_name name, ',
'  c002 quantity, ',
'  new_price(p.product_id) * c002 subtotal ',
'FROM ',
'  apex_collections a, ',
'  product p ',
'WHERE ',
'  collection_name = ''PRODUCTS'' ',
'  AND p.product_id = a.c001',
''))
,p_plug_source_type=>'NATIVE_JQM_LIST_VIEW'
,p_plug_query_num_rows=>15
,p_attribute_01=>'ADVANCED_FORMATTING'
,p_attribute_05=>'&QUANTITY. - <b>&NAME.</b>'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(25231223761086482239)
,p_plug_name=>'Subtotal'
,p_parent_plug_id=>wwv_flow_imp.id(27304123013623190634)
,p_region_css_classes=>'subtotal-list'
,p_region_template_options=>'#DEFAULT#:t-Region--noUI:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'  seq_id item, ',
'  p.product_id, ',
'  p.unit_price, ',
'  c002 quantity, ',
'  NEW_PRICE(p.product_id) * c002 subtotal ',
'FROM ',
'  apex_collections a, ',
'  product p ',
'WHERE ',
'  collection_name = ''PRODUCTS'' ',
'  AND p.product_id = a.c001',
''))
,p_plug_source_type=>'NATIVE_JQM_LIST_VIEW'
,p_plug_query_num_rows=>20
,p_attribute_01=>'ADVANCED_FORMATTING'
,p_attribute_05=>'<span class="subtotal"> &SUBTOTAL. TND </span>'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(25231223953271482241)
,p_plug_name=>'Delivery Method'
,p_parent_plug_id=>wwv_flow_imp.id(27304123013623190634)
,p_region_template_options=>'#DEFAULT#:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>30
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(26416295332434440229)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_imp.id(25231222812611482230)
,p_button_name=>'Proceed'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(19471882000429504304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Confirm My Order'
,p_button_condition=>'SHOPPING_CART_ITEMS'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_grid_new_row=>'Y'
,p_grid_column_span=>12
,p_grid_column=>1
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(26416295527752440231)
,p_branch_name=>'Go to Orders'
,p_branch_action=>'f?p=&APP_ID.:26:&SESSION.::&DEBUG.:26:P26_ORDER_ID:&P25_ORDER_ID.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(26416295332434440229)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(25231221806787482220)
,p_name=>'P25_ORDER_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(25231221796754482219)
,p_item_default=>'ORDER_ID_SEQ'
,p_item_default_type=>'SEQUENCE'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(25231221932643482221)
,p_name=>'P25_CUSTOMER_ID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(25231221796754482219)
,p_item_default=>'to_number(:USER_ID)'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(25231222076439482222)
,p_name=>'P25_CUSTOMER_EMAIL'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(25231221796754482219)
,p_prompt=>'<p style="color:#FFFFFF;">Email</p>'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_tag_attributes=>'style="background-color:#3A3632 ;color:#FFFFFF;font-weight: bold;"'
,p_field_template=>wwv_flow_imp.id(19471879586967504303)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(25231222129864482223)
,p_name=>'P25_CUSTOMER_FIRSTNAME'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(25231221796754482219)
,p_prompt=>'<p style="color:#FFFFFF;">Full name</p>'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_tag_attributes=>'   style="background-color:#3A3632 ;color:#FFFFFF;font-weight: bold;"'
,p_field_template=>wwv_flow_imp.id(19471879586967504303)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(25231222333255482225)
,p_name=>'P25_CUSTOMER_PHONE'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(25231221796754482219)
,p_prompt=>'Phone'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(19471879586967504303)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(25231222412965482226)
,p_name=>'P25_CITY'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(25231221796754482219)
,p_use_cache_before_default=>'NO'
,p_item_default=>'P25_DEFAULT_CITY'
,p_item_default_type=>'ITEM'
,p_prompt=>'City'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT CITY_NAME, CITY_ID',
'FROM CITIES',
'where STATE_ID = :P25_STATE'))
,p_lov_cascade_parent_items=>'P25_STATE'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(19471879586967504303)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(25231222577166482227)
,p_name=>'P25_CUSTOMER_ADDRESS'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(25231221796754482219)
,p_prompt=>'Address'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(19471879586967504303)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(25245578419736199945)
,p_name=>'P25_DELIVERY_PRICE'
,p_item_sequence=>60
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(25245578543731199946)
,p_name=>'P25_DELIVERY_METHOD'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(25231223953271482241)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    delivery_method || '' - '' || delivery_price || '' TND'',',
'    DELIVERY_TYPE_ID ',
'from delivery_type'))
,p_field_template=>wwv_flow_imp.id(19471879586967504303)
,p_item_css_classes=>'radio-btn'
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:margin-top-none'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'2'
,p_attribute_02=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(26319122759269552708)
,p_name=>'P25_TOTAL_SUBTOTAL'
,p_item_sequence=>50
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(26416293922011440215)
,p_name=>'P25_TOTAL_PRICE'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(27304123013623190634)
,p_prompt=>'Total Price'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(19471879586967504303)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(26416295298270440228)
,p_name=>'P25_ADDITIONAL_INFORMATION'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(25231221796754482219)
,p_item_default=>'No Additional Inforamtion'
,p_prompt=>'Additional information about your order (Optional)'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(19471879586967504303)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(27304120225193190606)
,p_name=>'P25_STATE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(25231221796754482219)
,p_use_cache_before_default=>'NO'
,p_item_default=>'to_number(:P25_DEFAULT_STATE)'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'state'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select state_name, state_id from states'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_colspan=>6
,p_field_template=>wwv_flow_imp.id(19471879586967504303)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(27304122747575190631)
,p_name=>'P25_DEFAULT_STATE'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(25231221796754482219)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(27304122843213190632)
,p_name=>'P25_DEFAULT_CITY'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(25231221796754482219)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(27304123181071190635)
,p_name=>'P25_PAYMENT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(26416295060769440226)
,p_use_cache_before_default=>'NO'
,p_item_default=>'1'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC:Cash on Delivery;1'
,p_field_template=>wwv_flow_imp.id(19471879586967504303)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'1'
,p_attribute_02=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(27304123700349190641)
,p_name=>'P25_PAYEMENT_DESC'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(26416295060769440226)
,p_item_default=>'You can pay in cash when the delivery is made.'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(19471879586967504303)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(42879122760194839706)
,p_name=>'P25_LINK'
,p_item_sequence=>70
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(27304120057268190604)
,p_validation_name=>'validate phone'
,p_validation_sequence=>10
,p_validation=>'return validations.validate_phone(:P25_CUSTOMER_PHONE);'
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_validation_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_current_phone customer.phone%TYPE;',
'BEGIN',
'    SELECT phone',
'    INTO l_current_phone',
'    FROM customer',
'    WHERE customer_id = :P25_CUSTOMER_ID;',
'',
'    RETURN NOT l_current_phone = :P25_CUSTOMER_PHONE;',
'END;'))
,p_validation_condition2=>'PLSQL'
,p_validation_condition_type=>'FUNCTION_BODY'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(27304120148363190605)
,p_validation_name=>'validate address'
,p_validation_sequence=>20
,p_validation=>'P25_CUSTOMER_ADDRESS'
,p_validation_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_error_message=>'enter your address'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(37171146032847069216)
,p_validation_name=>'check if the customer is the seller'
,p_validation_sequence=>30
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE ',
'    c_id apex_collections.c001%type; ',
'    v_product product.product_id%type;',
'    v_customer stores.customer_id%type;',
'    CURSOR c_customers is ',
'      SELECT c001 FROM apex_collections WHERE collection_name = ''PRODUCTS'' ; ',
'BEGIN ',
'   OPEN c_customers; ',
'   LOOP ',
'   FETCH c_customers into c_id;',
'   EXIT WHEN c_customers%notfound; ',
'    select p.product_id, s.customer_id ',
'        into v_product, v_customer',
'        from product p, stores s ',
'        where p.product_id = c_id',
'        and p.store_id =s.store_id;',
'',
'        if v_customer = to_number(:USER_ID) then ',
'            return false;',
'        ELSE',
'            return true;',
'        end if;  ',
'   END LOOP; ',
'   CLOSE c_customers;',
'END;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_BOOLEAN'
,p_error_message=>'You cannot order your own product :( Please remove your own product from the shopping cart page first. Do not be late! See you soon! <3'
,p_always_execute=>'Y'
,p_when_button_pressed=>wwv_flow_imp.id(26416295332434440229)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(25245578839897199949)
,p_name=>'Set Delivery Method'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P25_DELIVERY_METHOD'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(25245578929151199950)
,p_event_id=>wwv_flow_imp.id(25245578839897199949)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P25_DELIVERY_PRICE'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    DELIVERY_PRICE',
'FROM',
'    DELIVERY_TYPE',
'WHERE',
'    DELIVERY_TYPE_ID = :P25_DELIVERY_METHOD'))
,p_attribute_07=>'P25_DELIVERY_METHOD'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(26319122802343552709)
,p_name=>'GET CUSTOMER DATA'
,p_event_sequence=>20
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(26319122953374552710)
,p_event_id=>wwv_flow_imp.id(26319122802343552709)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'  firstname || '' '' || lastname, ',
'  st.state_id,',
'  ct.city_id, ',
'  email,',
'  phone, ',
'  address ',
'INTO ',
'  :P25_CUSTOMER_FIRSTNAME, ',
'  :P25_DEFAULT_STATE,',
'  :P25_DEFAULT_CITY, ',
'  :P25_CUSTOMER_EMAIL,',
'  :P25_CUSTOMER_PHONE, ',
'  :P25_CUSTOMER_ADDRESS ',
'FROM ',
'  customer cus, ',
'  cities ct, ',
'  states st ',
'WHERE ',
'  cus.customer_id = to_number(:USER_ID) ',
'  AND cus.city_id = ct.city_id ',
'  AND ct.state_id = st.state_id;'))
,p_attribute_02=>'P25_CUSTOMER_ID'
,p_attribute_03=>'P25_CUSTOMER_FIRSTNAME,P25_DEFAULT_STATE,P25_DEFAULT_CITY,P25_CUSTOMER_EMAIL,P25_CUSTOMER_PHONE,P25_CUSTOMER_ADDRESS'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(37730489086383642735)
,p_event_id=>wwv_flow_imp.id(26319122802343552709)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$s("P25_STATE", $v("P25_DEFAULT_STATE"))',
'$s("P25_CITY", $v("P25_DEFAULT_CITY"));'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(26416293300940440209)
,p_name=>'calculate subtotal'
,p_event_sequence=>30
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(26416293450143440210)
,p_event_id=>wwv_flow_imp.id(26416293300940440209)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'  sum(NEW_PRICE(c001) * c002) into :P25_TOTAL_SUBTOTAL',
'FROM ',
'  apex_collections a, ',
'  product p',
'WHERE ',
'  collection_name = ''PRODUCTS''',
'AND p.product_id = a.c001;'))
,p_attribute_03=>'P25_TOTAL_SUBTOTAL'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(26416294523084440221)
,p_name=>'calculate total price'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P25_DELIVERY_PRICE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(26416294721653440223)
,p_event_id=>wwv_flow_imp.id(26416294523084440221)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$s("P25_TOTAL_PRICE", parseFloat($v("P25_TOTAL_SUBTOTAL")) + parseFloat($v("P25_DELIVERY_PRICE")) + " TND");',
''))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(42879122656576839705)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'generate link'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  DECLARE',
'    LV_LINK VARCHAR2(4000);',
'  BEGIN',
'    LV_LINK := APEX_PAGE.GET_URL(',
'                                P_APPLICATION => :APP_ID,',
'                                P_PAGE        => 13,',
'                                P_SESSION     => NULL',
'                                /*P_ITEMS       => ''P8002_USER_EMAIL'',',
'                                P_VALUES      => :P8001_EMAIL*/',
'                                );',
'      :P25_LINK := '' https://apex.oracle.com'' || LV_LINK; ',
'      ',
'                              ',
'',
'  EXCEPTION',
'    WHEN OTHERS THEN NULL;',
'  END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>42879122656576839705
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(26416295488051440230)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Create Order'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'MANAGE_ORDERS.create_order(',
'    :P25_CUSTOMER_ID,',
'    :P25_CUSTOMER_ADDRESS,',
'    :P25_CUSTOMER_PHONE,',
'    :P25_CITY,',
'    :P25_PAYMENT,',
'    :P25_DELIVERY_METHOD,',
'    :P25_ADDITIONAL_INFORMATION,',
'    :P25_ORDER_ID',
');'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(26416295332434440229)
,p_process_success_message=>'Order successfully created: &P25_ORDER_ID.'
,p_internal_uid=>26416295488051440230
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(42879122410710839703)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SEND_EMAIL'
,p_process_name=>'send email'
,p_attribute_01=>'&APP_EMAIL.'
,p_attribute_02=>':P25_CUSTOMER_EMAIL'
,p_attribute_06=>'command number &P25_ORDER_ID.'
,p_attribute_07=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Thank you for your order !',
'',
'<button onclick = &P25_LINK.> Check my Order </button>'))
,p_attribute_10=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(26416295332434440229)
,p_process_success_message=>'mail sent'
,p_internal_uid=>42879122410710839703
);
wwv_flow_imp.component_end;
end;
/
