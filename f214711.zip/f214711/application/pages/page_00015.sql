prompt --application/pages/page_00015
begin
--   Manifest
--     PAGE: 00015
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>6662355588643785590
,p_default_application_id=>214711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_RSWSP'
);
wwv_flow_imp_page.create_page(
 p_id=>15
,p_name=>'My Stores'
,p_alias=>'MY-STORES'
,p_step_title=>'&APP_NAME. - My Stores'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.page-header {',
'    padding-left: 50px;',
'    background-color: #FBF9F8;',
'    font-family: ''Courier New'', Courier, monospace;',
'}',
'',
'.page-header-col {',
'    text-align: center;',
'}',
'',
'.ui-btn {',
'    margin-top: 10px;',
'    border: 1px solid #F1EFED;',
'    border-radius: 20px;',
'}',
'',
'#R21951575534664991015_filter_input {',
'    border-radius: 10px;',
'    border: 1px solid #373634;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(19994436662008524033)
,p_protection_level=>'C'
,p_page_component_map=>'11'
,p_last_updated_by=>'PFE94053@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20230619190021'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(21951575534664991015)
,p_plug_name=>'List Of Stores'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    s.STORE_ID,',
'    s.STORE_NAME,',
'    s.STORE_DESCRIPTION',
'FROM',
'    STORES s',
'WHERE',
'    s.CUSTOMER_ID = TO_NUMBER(:USER_ID)',
'',
''))
,p_plug_source_type=>'NATIVE_JQM_LIST_VIEW'
,p_plug_query_num_rows=>15
,p_plug_query_no_data_found=>'No Stores Yet ! Go Ahead And Create Your First Store'
,p_attribute_01=>'ADVANCED_FORMATTING:SEARCH'
,p_attribute_05=>'<h4>Store Name : <b>&STORE_NAME.</b></h4>'
,p_attribute_07=>'&STORE_DESCRIPTION.'
,p_attribute_16=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:5:P5_STORE_ID:&STORE_ID.'
,p_attribute_18=>'SERVER_LIKE_IGNORE'
,p_attribute_20=>'search store..'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(21951575655597991016)
,p_plug_name=>'Page Header'
,p_region_css_classes=>'page-header'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--accent10:t-Region--noUI:t-Region--hiddenOverflow:margin-right-md'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>10
,p_plug_grid_column_css_classes=>'page-header-col'
,p_plug_display_point=>'REGION_POSITION_08'
,p_plug_source=>'<h2>&USERNAME.''s Stores </h2>'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp.component_end;
end;
/
