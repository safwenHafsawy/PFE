prompt --application/pages/page_00061
begin
--   Manifest
--     PAGE: 00061
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>6662355588643785590
,p_default_application_id=>214711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_RSWSP'
);
wwv_flow_imp_page.create_page(
 p_id=>61
,p_name=>'Edit Product Variants'
,p_alias=>'EDIT-PRODUCT-VARIANTS1'
,p_page_mode=>'MODAL'
,p_step_title=>'Edit Product Variants'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'#APP_FILES#scripts/main#MIN#.js'
,p_css_file_urls=>'#APP_FILES#Styling/main_style#MIN#.css'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'[data-action="selection-add-row"] {',
'  /* Your styles for elements with data-action="selection-add-row" here */',
'    background-color: var(--fouth-color) !important;',
'    color: var(--second-color);',
'}',
'',
'.a-GV-hdr  {',
'    font-family: var(--secondary-header-font);',
'    text-align: center;',
'}',
'',
'.a-GV-cell {',
'    font-family: var(--regular-text-font);',
'    text-align: center;',
'}',
'',
'.del {',
'    color: var(--danger-color);',
'}',
'',
'.update {',
'    color: var(--fouth-color);',
'}'))
,p_step_template=>wwv_flow_imp.id(19471535469231504230)
,p_page_template_options=>'#DEFAULT#'
,p_dialog_width=>'1200'
,p_protection_level=>'C'
,p_page_component_map=>'03'
,p_last_updated_by=>'PFE94053@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20230820121041'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(33838196258324159659)
,p_plug_name=>'Wizard Progress'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(19471542261328504234)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_list_id=>wwv_flow_imp.id(33838191074647159655)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(19471877875421504302)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(33838196400795159659)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(19471545059842504235)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(53018741534941035617)
,p_plug_name=>'Action Region'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--stacked:t-Region--scrollBody:margin-top-lg'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>60
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(53018741703648035619)
,p_plug_name=>'Add Variant Popup'
,p_region_template_options=>'#DEFAULT#:js-dialog-autoheight:js-popup-noOverlay:js-dialog-size600x400:js-popup-pos-before'
,p_plug_template=>wwv_flow_imp.id(19471593662015504257)
,p_plug_display_sequence=>80
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(111696873787203873553)
,p_plug_name=>'Create New Variant'
,p_parent_plug_id=>wwv_flow_imp.id(53018741703648035619)
,p_region_css_classes=>'create-variant-form'
,p_region_template_options=>'#DEFAULT#:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>90
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(95173617164715882828)
,p_plug_name=>'variant_2'
,p_parent_plug_id=>wwv_flow_imp.id(111696873787203873553)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--textContent:t-Region--hiddenOverflow:margin-top-none'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>60
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>4
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(95173617330573882829)
,p_plug_name=>'variant_3'
,p_parent_plug_id=>wwv_flow_imp.id(111696873787203873553)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--textContent:t-Region--scrollBody:margin-top-none'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>70
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>4
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(137545043623639177651)
,p_plug_name=>'variant_1'
,p_parent_plug_id=>wwv_flow_imp.id(111696873787203873553)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--textContent:t-Region--hiddenOverflow:margin-top-none'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>50
,p_plug_grid_column_span=>4
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(65941917896310107616)
,p_name=>'Product Variant List'
,p_template=>wwv_flow_imp.id(19471599035745504259)
,p_display_sequence=>70
,p_region_template_options=>'#DEFAULT#:t-IRR-region--noBorders:t-Form--xlarge:margin-top-lg'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--altRowsDefault:t-Report--rowHighlight:t-Report--inline:t-Report--hideNoPagination'
,p_grid_column_css_classes=>'variant-grid'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'        stock_id,',
'        product_id,',
'        variant_1,',
'        variant_2,',
'        variant_3,',
'        stock_quantity,',
'        ''Update'',',
'        ''Delete''',
'    FROM',
'        variant_stock',
'    WHERE',
'        product_id = :P61_PRODUCT_ID;'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P61_PRODUCT_ID,P61_VARIANT_1_NAME,P61_VARIANT_2_NAME,P61_VARIANT_3_NAME'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(19471847069031504283)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(53026785499099675906)
,p_query_column_id=>1
,p_column_alias=>'STOCK_ID'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(53026785585244675907)
,p_query_column_id=>2
,p_column_alias=>'PRODUCT_ID'
,p_column_display_sequence=>20
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(53026785657217675908)
,p_query_column_id=>3
,p_column_alias=>'VARIANT_1'
,p_column_display_sequence=>30
,p_column_heading=>'&P61_VARIANT_1_NAME.'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(53026785792738675909)
,p_query_column_id=>4
,p_column_alias=>'VARIANT_2'
,p_column_display_sequence=>40
,p_column_heading=>'&P61_VARIANT_2_NAME.'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(53026785826978675910)
,p_query_column_id=>5
,p_column_alias=>'VARIANT_3'
,p_column_display_sequence=>50
,p_column_heading=>'&P61_VARIANT_3_NAME.'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(53026785932950675911)
,p_query_column_id=>6
,p_column_alias=>'STOCK_QUANTITY'
,p_column_display_sequence=>60
,p_column_heading=>'Stock Quantity'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(53026786022476675912)
,p_query_column_id=>7
,p_column_alias=>'''UPDATE'''
,p_column_display_sequence=>70
,p_column_heading=>'Update Variant'
,p_use_as_row_header=>'N'
,p_column_link=>'javascript:void(null)'
,p_column_linktext=>'<span class="fa fa-pencil-square update" aria-hidden="true"></span>'
,p_column_link_attr=>'data-id=#STOCK_ID# data-var1=#VARIANT_1# data-var2=#VARIANT_2# data-var3=#VARIANT_3# data-qty=#STOCK_QUANTITY#'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(53026786183966675913)
,p_query_column_id=>8
,p_column_alias=>'''DELETE'''
,p_column_display_sequence=>80
,p_column_heading=>'Delete Variant'
,p_use_as_row_header=>'N'
,p_column_link=>'javascript:void(null)'
,p_column_linktext=>'<span aria-hidden="true" class="fa fa-trash del"></span>'
,p_column_link_attr=>'data-id=#STOCK_ID#'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(53018741666907035618)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(53018741534941035617)
,p_button_name=>'Add_New_Variants'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--iconRight:t-Button--hoverIconPush:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(19471882117602504304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add New Variants'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-table-plus'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(53020099366673177983)
,p_button_sequence=>90
,p_button_plug_id=>wwv_flow_imp.id(111696873787203873553)
,p_button_name=>'Add_Variant'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--gapTop'
,p_button_template_id=>wwv_flow_imp.id(19471882000429504304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add Variant'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(53026787985660675931)
,p_button_sequence=>100
,p_button_plug_id=>wwv_flow_imp.id(111696873787203873553)
,p_button_name=>'Update_Variant'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--gapTop'
,p_button_template_id=>wwv_flow_imp.id(19471882000429504304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Update Variant'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(33838197907193159660)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(33838196400795159659)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(19471882000429504304)
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(33838198265526159660)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(33838196400795159659)
,p_button_name=>'NEXT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(19471882117602504304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add New Images'
,p_button_position=>'NEXT'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(33838198104572159660)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(33838196400795159659)
,p_button_name=>'PREVIOUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(19471881378436504304)
,p_button_image_alt=>'Previous'
,p_button_position=>'PREVIOUS'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(33838600506442159662)
,p_branch_name=>'Go To Page 62'
,p_branch_action=>'f?p=&APP_ID.:62:&SESSION.::&DEBUG.:62:P62_PRODUCT_ID,P62_VARIANT_1_NAME,P62_VARIANT_2_NAME,P62_VARIANT_3_NAME:&P61_PRODUCT_ID.,&P61_VARIANT_1_NAME.,&P61_VARIANT_2_NAME.,&P61_VARIANT_3_NAME.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(33838198265526159660)
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(33838199834570159661)
,p_branch_name=>'Go To Page 60'
,p_branch_action=>'f?p=&APP_ID.:60:&SESSION.::&DEBUG.:60:P60_PRODUCT_ID:&P61_PRODUCT_ID.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_VALIDATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(33838198104572159660)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(33825344975533128820)
,p_name=>'P61_PRODUCT_ID'
,p_item_sequence=>10
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(33825345033696128821)
,p_name=>'P61_VARIANT_1_NAME'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(33825345170161128822)
,p_name=>'P61_VARIANT_2_NAME'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(33825345227776128823)
,p_name=>'P61_VARIANT_3_NAME'
,p_item_sequence=>40
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(53026789252068675944)
,p_name=>'P61_STOCK_QUANTITY'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(111696873787203873553)
,p_prompt=>'Stock Quantity'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(19471880312432504303)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(65941924173735107646)
,p_name=>'P61_VARIANT_TO_MODIFY'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(65941917896310107616)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(95394108056136367289)
,p_name=>'P61_VARIANT_2'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(95173617164715882828)
,p_prompt=>'&P61_VARIANT_2_NAME.'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(19471880312432504303)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(95394109544639367294)
,p_name=>'P61_VARIANT_3'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(95173617330573882829)
,p_prompt=>'&P61_VARIANT_3_NAME.'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(19471880312432504303)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(137545050265760177666)
,p_name=>'P61_VARIANT_1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(137545043623639177651)
,p_prompt=>'&P61_VARIANT_1_NAME.'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(19471880312432504303)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(33838198340871159660)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(33838197907193159660)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(33838199111622159661)
,p_event_id=>wwv_flow_imp.id(33838198340871159660)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(33840085060149232192)
,p_name=>'Delete Variant'
,p_event_sequence=>20
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.delete-variant'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(33840085961143232193)
,p_event_id=>wwv_flow_imp.id(33840085060149232192)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'Do You Want To Delete This Variant ?'
,p_attribute_02=>'Delete Variant '
,p_attribute_03=>'danger'
,p_attribute_04=>'fa-trash'
,p_attribute_06=>'Delete'
,p_attribute_07=>'Cancel'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(33840085421535232192)
,p_event_id=>wwv_flow_imp.id(33840085060149232192)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P61_VARIANT_TO_MODIFY'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'$(this.triggeringElement).parent().data(''id'');'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(33840086951387232193)
,p_event_id=>wwv_flow_imp.id(33840085060149232192)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'delete from ',
'    variant_stock ',
'where ',
'    stock_id = to_number(:P61_VARIANT_TO_DELETE);',
''))
,p_attribute_02=>'P61_VARIANT_TO_MODIFY'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(33975088533299940901)
,p_event_id=>wwv_flow_imp.id(33840085060149232192)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'console.log($v("P61_VARIANT_TO_DELETE"))'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(33840086471852232193)
,p_event_id=>wwv_flow_imp.id(33840085060149232192)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(65941917896310107616)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(53018741826392035620)
,p_name=>'Open New Variant Popup'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(53018741666907035618)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(53026788927645675941)
,p_event_id=>wwv_flow_imp.id(53018741826392035620)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLEAR'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P61_VARIANT_1,P61_VARIANT_2,P61_VARIANT_3,P61_STOCK_QUANTITY'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(53026788509028675937)
,p_event_id=>wwv_flow_imp.id(53018741826392035620)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(53026787985660675931)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(53026788840261675940)
,p_event_id=>wwv_flow_imp.id(53018741826392035620)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(53020099366673177983)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(53018741910673035621)
,p_event_id=>wwv_flow_imp.id(53018741826392035620)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_OPEN_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(53018741703648035619)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(53018742486425035626)
,p_name=>'Add New Variant'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(53020099366673177983)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(53018742571174035627)
,p_event_id=>wwv_flow_imp.id(53018742486425035626)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_count number := 0;',
'BEGIN',
'    SELECT count(*)',
'    INTO l_count',
'    FROM variant_stock',
'    WHERE product_id = :P61_PRODUCT_ID',
'          AND variant_1 = :P61_VARIANT_1',
'          AND variant_2 = :P61_VARIANT_2',
'          AND variant_3 = :P61_VARIANT_3;',
'',
'    IF l_count > 0 THEN',
'        UPDATE ',
'            variant_stock ',
'        SET  ',
'            stock_quantity = stock_quantity + :P41_STOCK_QUANTITY ',
'        WHERE product_id = :P61_PRODUCT_ID',
'            AND variant_1 = :P61_VARIANT_1',
'            AND variant_2 = :P61_VARIANT_2',
'            AND variant_3 = :P61_VARIANT_3;    ',
'            ',
'    ELSE',
'        INSERT INTO variant_stock (product_id, variant_1, variant_2, variant_3, stock_quantity)',
'        VALUES(',
'            :P61_PRODUCT_ID,',
'            :P61_VARIANT_1,',
'            :P61_VARIANT_2,',
'            :P61_VARIANT_3,',
'            :P61_STOCK_QUANTITY',
'        );',
'    END IF;',
'END;'))
,p_attribute_02=>'P61_PRODUCT_ID,P61_VARIANT_1,P61_VARIANT_2,P61_VARIANT_3'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(53018742642652035628)
,p_event_id=>wwv_flow_imp.id(53018742486425035626)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(65941917896310107616)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(53018742794896035629)
,p_event_id=>wwv_flow_imp.id(53018742486425035626)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLOSE_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(53018741703648035619)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(53026786429363675916)
,p_name=>'Remove Variant'
,p_event_sequence=>50
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.del'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(53026786568641675917)
,p_event_id=>wwv_flow_imp.id(53026786429363675916)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'Are you sure you want to delete this variant ? this action is irreversible !'
,p_attribute_02=>'Delete Product Variant '
,p_attribute_03=>'warning'
,p_attribute_06=>'Delete '
,p_attribute_07=>'Cancel'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(53026786774950675919)
,p_event_id=>wwv_flow_imp.id(53026786429363675916)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P61_VARIANT_TO_MODIFY'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'$(this.triggeringElement).parent().data(''id'');'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(53026786878185675920)
,p_event_id=>wwv_flow_imp.id(53026786429363675916)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DELETE FROM variant_stock',
'WHERE stock_id = :P61_VARIANT_TO_DELETE;'))
,p_attribute_02=>'P61_VARIANT_TO_MODIFY'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(53026786905085675921)
,p_event_id=>wwv_flow_imp.id(53026786429363675916)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(65941917896310107616)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(53026787427459675926)
,p_name=>'Update Variant'
,p_event_sequence=>60
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.update'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(53026788633598675938)
,p_event_id=>wwv_flow_imp.id(53026787427459675926)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(53020099366673177983)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(53026788779424675939)
,p_event_id=>wwv_flow_imp.id(53026787427459675926)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(53026787985660675931)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(53026787658235675928)
,p_event_id=>wwv_flow_imp.id(53026787427459675926)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$s("P61_VARIANT_TO_MODIFY", $(this.triggeringElement).parent().data(''id''));',
'$s("P61_VARIANT_1", $(this.triggeringElement).parent().data(''var1''));',
'$s("P61_VARIANT_2", $(this.triggeringElement).parent().data(''var2''));',
'$s("P61_VARIANT_3", $(this.triggeringElement).parent().data(''var3''));',
'$s("P61_STOCK_QUANTITY", $(this.triggeringElement).parent().data(''qty''));'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(53026787533824675927)
,p_event_id=>wwv_flow_imp.id(53026787427459675926)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_OPEN_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(53018741703648035619)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(53026789095237675942)
,p_name=>'Upadte Existing Variant'
,p_event_sequence=>70
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(53026787985660675931)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(53026789156368675943)
,p_event_id=>wwv_flow_imp.id(53026789095237675942)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'UPDATE variant_stock ',
'SET variant_1 = :P61_VARIANT_1, variant_2 = :P61_VARIANT_2, variant_3 = :P61_VARIANT_3, stock_quantity = :P61_STOCK_QUANTITY',
'WHERE stock_id = :P61_VARIANT_TO_MODIFY;'))
,p_attribute_02=>'P61_VARIANT_1,P61_VARIANT_2,P61_VARIANT_3,P61_STOCK_QUANTITY,P61_VARIANT_TO_MODIFY'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(53026789305262675945)
,p_event_id=>wwv_flow_imp.id(53026789095237675942)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(65941917896310107616)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(53026789485201675946)
,p_event_id=>wwv_flow_imp.id(53026789095237675942)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLOSE_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(53018741703648035619)
);
wwv_flow_imp.component_end;
end;
/
