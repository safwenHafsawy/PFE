prompt --application/pages/page_00027
begin
--   Manifest
--     PAGE: 00027
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>6662355588643785590
,p_default_application_id=>214711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_RSWSP'
);
wwv_flow_imp_page.create_page(
 p_id=>27
,p_name=>'Shopping  Cart'
,p_alias=>'SHOPPING-CART'
,p_step_title=>'Shopping  Cart'
,p_autocomplete_on_off=>'OFF'
,p_css_file_urls=>'#APP_FILES#Styling/main_style#MIN#.css'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.cart_header {',
'    margin-top: 10px;',
'    text-align: center;',
'    color: var(--fouth-color);',
'    font-family: var(--main-header-font);',
'}',
'',
'.card-container {',
'    width: 100%;',
'    min-height: 100%; ',
'}',
'',
'.no-item-in-cart {',
'    font-family: var(--secondary-header-font);',
'}',
'',
'.a-CardView-item  {',
'    padding: 15px;',
'}',
'',
'.side-card {',
'    width: fit-content !important;',
'    border: 2px solid var(--first-color);',
'    box-shadow: 0 1px 1px var(--third-color);',
'    border-radius: 10px;',
'    transition: all 0.3s ease;',
'}',
'.side-card:hover {',
'    transform: translateY(-5px);',
'}',
'',
'.side-card-title {',
'    padding: 10px;',
'    font-family: var(--secondary-header-font);',
'}',
'',
'.side-card-subtitle {',
'    font-family: var(--regular-text-font);',
'}',
'.side-card-subtitle > span {',
'    font-weight: bold;',
'}',
'',
'.side-card-body {',
'    font-family: var(--regular-text-font);',
'}',
'',
'.side-card-img {',
'    background-color: var(--second-color);',
'}',
'',
'.side-card-body > span {',
'    font-weight: bold;',
'}',
'',
'.edit-btn {',
'    position: absolute;',
'    top: 10px;',
'    right: 70px;',
'    border-radius: 10px;',
'}',
'',
'.delete-btn {',
'    background-color: #C33522;',
'    color: whitesmoke;',
'    position: absolute;',
'    top: 10px;',
'    right: 10px;',
'    border-radius: 10px;',
'}',
'',
'.shopping-cart-summary {',
'    padding: 15px;',
'}',
'',
'.summary-container {',
'    padding: 30px;',
'    box-shadow: 0 1px 1px var(--third-color);',
'}',
'',
'#R37730488048240642725_heading {',
'    font-family: var(--secondary-header-font);',
'}',
'',
'.promo-code-label {',
'    text-align: center;',
'    font-family: var(--regular-text-font);',
'}',
'',
'.apply-promo{',
'    display: flex;',
'    justify-content: center;',
'    align-items: center;',
'}',
'',
'.apply-promo > button {',
'    font-family: var(--secondary-header-font);',
'    font-weight: bolder;',
'}',
'',
'.actions {',
'    width: 100%;',
'    padding: 20px;',
'    position: relative;',
'    bottom: 10px;',
'}',
'',
'.to-check-out {',
'    font-family: var(--secondary-header-font);',
'    font-weight: bolder;',
'}',
'',
'.clear-shopping-cart {',
'    background-color: #C33522;',
'    color: whitesmoke;',
'    font-family: var(--secondary-header-font);',
'',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'23'
,p_last_updated_by=>'PFE94053@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20230711180010'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15433328021456828811)
,p_plug_name=>'Shopping Cart items'
,p_region_css_classes=>'card-container'
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--styleC'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(19471549395551504237)
,p_plug_display_sequence=>60
,p_plug_grid_column_span=>7
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT  seq_id item,',
'        p.product_id,',
'        p.product_name name,',
'        p.product_description,',
'        p.category_id,',
'        pi.image,',
'        c003               stock_id,',
'        c004               variant_1_name, ',
'        c005               variant_2_name, ',
'        c006               variant_3_name, ',
'        c002               quantity,',
'        NEW_PRICE(p.product_id) * c002 subTotal,',
'        vs.variant_1,',
'        vs.variant_2,',
'        vs.variant_3,',
'        s.store_name',
'FROM    product p',
'        join (SELECT image_id,',
'            product_id,',
'            image',
'            FROM(SELECT image_id,',
'                        product_id,',
'                        image,',
'                        Row_number()',
'                            over (',
'                            PARTITION BY product_id',
'                            ORDER BY image_id) AS rn',
'                FROM   product_images) img',
'                WHERE  rn = 1) pi',
'        ON p.product_id = pi.product_id,',
'        stores s, ',
'        variant_stock vs,',
'        apex_collections a',
'WHERE  collection_name = ''PRODUCTS''',
'AND    p.product_id = a.c001',
'AND    s.store_id = p.store_id',
'AND    vs.stock_id = c003;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_plug_query_no_data_found=>'<h1 class="no-item-in-cart">Your shopping cart is empty!</h1>'
,p_no_data_found_icon_classes=>'fa-cart-empty'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(15433328171604828812)
,p_region_id=>wwv_flow_imp.id(15433328021456828811)
,p_layout_type=>'ROW'
,p_card_css_classes=>'side-card'
,p_title_adv_formatting=>true
,p_title_html_expr=>'<h4 class="side-card-title">&QUANTITY. &NAME.</h4>'
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>true
,p_body_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p class="side-card-subtitle">From : <span> &STORE_NAME. </span></p>',
'',
'<p class="side-card-body">',
'    &VARIANT_1_NAME. : <span>&VARIANT_1. </span> &VARIANT_2_NAME. : <span>&VARIANT_2. </span> &VARIANT_3_NAME. : <span>&VARIANT_3. </span> </p>'))
,p_second_body_adv_formatting=>true
,p_second_body_html_expr=>'<b>Subtotal: &SUBTOTAL. TDN </b>'
,p_media_adv_formatting=>false
,p_media_source_type=>'BLOB'
,p_media_blob_column_name=>'IMAGE'
,p_media_display_position=>'BODY'
,p_media_appearance=>'SQUARE'
,p_media_sizing=>'FIT'
,p_media_css_classes=>'side-card-img'
,p_pk1_column_name=>'ITEM'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(34869895276672248639)
,p_card_id=>wwv_flow_imp.id(15433328171604828812)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>10
,p_label=>'Edit Item'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:4:P4_STOCK_ID,P4_NEW_QUNTITY,P4_CATEGORY_ID,P4_PRODUCT_ID:&STOCK_ID.,&QUANTITY.,&CATEGORY_ID.,&PRODUCT_ID.'
,p_button_display_type=>'ICON'
,p_icon_css_classes=>'fa-pencil'
,p_action_css_classes=>'edit-btn'
,p_is_hot=>true
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(35681586493614205020)
,p_card_id=>wwv_flow_imp.id(15433328171604828812)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>20
,p_label=>'Delete item'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'javascript:void(null)'
,p_link_attributes=>'data-id=&PRODUCT_ID.'
,p_button_display_type=>'ICON'
,p_icon_css_classes=>'fa-remove'
,p_action_css_classes=>'delete-btn'
,p_is_hot=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(37730487256261642717)
,p_plug_name=>'Cart page header'
,p_region_css_classes=>'cart_header'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>50
,p_plug_display_point=>'REGION_POSITION_08'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_how_many NUMBER DEFAULT 0;',
'BEGIN',
'    l_how_many := manage_orders.get_quantity;',
'',
'',
'    IF l_how_many > 0 THEN',
'        RETURN',
'            ''<h2> Your Cart ('' || l_how_many || '' items) </h2>'';',
'    ELSE',
'        RETURN',
'            ''<h2> Your Cart (Empty) </h2>'';',
'    END IF;',
'END;',
'',
''))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(37730488860652642733)
,p_plug_name=>'Shopping cart summary'
,p_region_css_classes=>'shopping-cart-summary'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>70
,p_plug_new_grid_row=>false
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(34869894615963248633)
,p_plug_name=>'Actions'
,p_parent_plug_id=>wwv_flow_imp.id(37730488860652642733)
,p_region_css_classes=>'actions'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(19471545059842504235)
,p_plug_display_sequence=>90
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(37730488048240642725)
,p_plug_name=>'Summary'
,p_parent_plug_id=>wwv_flow_imp.id(37730488860652642733)
,p_region_css_classes=>'summary-container'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>80
,p_plug_new_grid_row=>false
,p_plug_grid_column_css_classes=>'summary-container-col'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(37730488266636642727)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(37730488048240642725)
,p_button_name=>'Apply'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(19471882000429504304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply'
,p_warn_on_unsaved_changes=>null
,p_grid_column_css_classes=>'apply-promo'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(15433329533036828826)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(34869894615963248633)
,p_button_name=>'Proceed'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(19471882117602504304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Proceed to checkout'
,p_button_position=>'CREATE'
,p_icon_css_classes=>'fa-arrow-right'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(15433329604903828827)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(34869894615963248633)
,p_button_name=>'Clear'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(19471882117602504304)
,p_button_image_alt=>'Clear Shoping Cart'
,p_button_position=>'DELETE'
,p_button_execute_validations=>'N'
,p_confirm_message=>'Are You sure You want to clear your cart ? '
,p_confirm_style=>'danger'
,p_button_css_classes=>'clear-shopping-cart'
,p_icon_css_classes=>'fa-cart-empty'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(22821460345291138506)
,p_branch_name=>'Go to products'
,p_branch_action=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.:2::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(15433329604903828827)
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(35681587358541205029)
,p_branch_name=>'To Checkout'
,p_branch_action=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(15433329533036828826)
,p_branch_sequence=>30
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(27304120819109190612)
,p_name=>'P27_PAGE_ID'
,p_item_sequence=>10
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(35681587006518205026)
,p_name=>'P27_ITEM_TO_REMOVE'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(35681589201323205048)
,p_name=>'P27_SHOPPING_CART_ITEMS'
,p_item_sequence=>40
,p_use_cache_before_default=>'NO'
,p_item_default=>':SHOPPING_CART_ITEMS'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37730488134624642726)
,p_name=>'P27_PROMO_CODE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(37730488048240642725)
,p_prompt=>'<span class="promo-code-label">Promo Code</span>'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_colspan=>9
,p_field_template=>wwv_flow_imp.id(19471879586967504303)
,p_item_css_classes=>'promo-code'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37730488730648642732)
,p_name=>'P27_TOTAL_ORDER_PRICE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(37730488048240642725)
,p_prompt=>'Order Total'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    order_total number;',
'BEGIN',
'    SELECT ',
'      sum(NEW_PRICE(p.product_id) * c002)',
'    INTO',
'        order_total',
'    FROM ',
'      apex_collections a, ',
'      product p',
'    WHERE ',
'      collection_name = ''PRODUCTS''',
'    AND p.product_id = a.c001;',
'    IF order_total IS NOT NULL THEN',
'        RETURN order_total || '' TND'';',
'    ELSE',
'        RETURN '''';',
'    END IF;',
'END;'))
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(19471879586967504303)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(37730489374579642738)
,p_validation_name=>'Must Have Products Before Checkout'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_quantity number;',
'BEGIN',
'    l_quantity := MANAGE_ORDERS.get_quantity;',
'',
'    IF l_quantity > 0 THEN',
'        RETURN TRUE;',
'    END IF;',
'    RETURN FALSE;',
'END;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_BOOLEAN'
,p_error_message=>'Must Have Products In Your Shoppping Cart Before checking out'
,p_when_button_pressed=>wwv_flow_imp.id(15433329533036828826)
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(22821460622795138509)
,p_name=>'Update Shopping Cart Header'
,p_event_sequence=>10
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'parseInt($v("P27_SHOPPING_CART_ITEMS")) > 0'
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(22821460744650138510)
,p_event_id=>wwv_flow_imp.id(22821460622795138509)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// Update Badge Text',
'$(".js-shopping-cart-item .t-Button-badge").text($v("P27_SHOPPING_CART_ITEMS"));',
'',
'// Update Icon',
'$(".js-shopping-cart-item .t-Icon").removeClass(''fa-cart-empty'').addClass(''fa-cart-full'');'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(22821460953411138512)
,p_event_id=>wwv_flow_imp.id(22821460622795138509)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// Update Badge Text',
'apex.jQuery(".js-shopping-cart-item .t-Button-badge").text('''');',
'',
'// Update Icon',
'apex.jQuery(".js-shopping-cart-item .t-Icon").removeClass(''fa-cart-full'').addClass(''fa-cart-empty'');'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(22821460827814138511)
,p_event_id=>wwv_flow_imp.id(22821460622795138509)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(15433328021456828811)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(22821461081358138513)
,p_event_id=>wwv_flow_imp.id(22821460622795138509)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(15433328021456828811)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(27304120969378190613)
,p_name=>'get page id'
,p_event_sequence=>30
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(27304121046145190614)
,p_event_id=>wwv_flow_imp.id(27304120969378190613)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT :APP_PAGE_ID',
'INTO :P27_PAGE_ID',
'FROM DUAL;'))
,p_attribute_03=>'P27_PAGE_ID'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(35681586048595205016)
,p_name=>'Refresh Shopping Cart Items'
,p_event_sequence=>50
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(15433328021456828811)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(37036232138160922401)
,p_event_id=>wwv_flow_imp.id(35681586048595205016)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// Update Badge Text',
'$(".js-shopping-cart-item .t-Button-badge").text($v("P27_SHOPPING_CART_ITEMS"));',
'',
'// Update Icon',
'$(".js-shopping-cart-item .t-Icon").removeClass(''fa-cart-empty'').addClass(''fa-cart-full'');'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(35681586151295205017)
,p_event_id=>wwv_flow_imp.id(35681586048595205016)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(15433328021456828811)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(35681586757909205023)
,p_name=>'Delete From Shopping Cart'
,p_event_sequence=>60
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.delete-btn'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(35681586884824205024)
,p_event_id=>wwv_flow_imp.id(35681586757909205023)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'Are you sure you want to remove this item completely from you shopping cart ? '
,p_attribute_02=>'Remove Item Completely'
,p_attribute_03=>'danger'
,p_attribute_04=>'fa-remove'
,p_attribute_06=>'Delete'
,p_attribute_07=>'Cancel'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(35681587195485205027)
,p_event_id=>wwv_flow_imp.id(35681586757909205023)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P27_ITEM_TO_REMOVE'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'$(this.triggeringElement).data(''id'')'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(35681586916510205025)
,p_event_id=>wwv_flow_imp.id(35681586757909205023)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'MANAGE_ORDERS.remove_product(:P27_ITEM_TO_REMOVE);'
,p_attribute_02=>'P27_ITEM_TO_REMOVE'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(35681589431186205050)
,p_event_id=>wwv_flow_imp.id(35681586757909205023)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':P27_SHOPPING_CART_ITEMS := MANAGE_ORDERS.get_quantity;'
,p_attribute_03=>'P27_SHOPPING_CART_ITEMS'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(35681589346741205049)
,p_event_id=>wwv_flow_imp.id(35681586757909205023)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// Update Badge Text',
'$(".js-shopping-cart-item .t-Button-badge").text($v("P27_SHOPPING_CART_ITEMS"));',
'',
'// Update Icon',
'$(".js-shopping-cart-item .t-Icon").removeClass(''fa-cart-empty'').addClass(''fa-cart-full'');'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(35681587268055205028)
,p_event_id=>wwv_flow_imp.id(35681586757909205023)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(15433328021456828811)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(22821460149671138504)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Clear Shopping Cart'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    MANAGE_ORDERS.CLEAR_CART;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(15433329604903828827)
,p_internal_uid=>22821460149671138504
);
wwv_flow_imp.component_end;
end;
/
