prompt --application/pages/page_00071
begin
--   Manifest
--     PAGE: 00071
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>6662355588643785590
,p_default_application_id=>214711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_RSWSP'
);
wwv_flow_imp_page.create_page(
 p_id=>71
,p_name=>'Seller Dashboard Stores'
,p_alias=>'SELLER-DASHBOARD-STORES'
,p_step_title=>'Seller Dashboard Stores'
,p_autocomplete_on_off=>'OFF'
,p_css_file_urls=>'#APP_FILES#Styling/main_style#MIN#.css'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.overview {',
'    border-left: 10px solid var(--fouth-color);',
'    border-radius: 10px;',
'    padding-left: 10px;',
'    text-align: center;',
'}',
'',
'.overview-title {',
'    display: flex;',
'    align-items: center;',
'    color: var(--fouth-color);',
'    font-family: var(--secondary-header-font);',
'    border-bottom: 1px solid rgba(211, 211, 211, 0.5);',
'    padding: 2px;',
'}',
'',
'.overview-title > span {',
'    margin-right: 5px;',
'}',
'',
'.overview-data {',
'    font-family: var(--regular-text-font );',
'}',
'',
'.overview-data-prod > span {',
'    font-size: xx-small;',
'    opacity: 0.6;',
'}',
'',
'.overview-data-prod {',
'    font-family: var(--regular-text-font );',
'    display: flex;',
'    flex-direction: column;',
'}',
'',
'.a-AlertMessage-title {',
'    font-family: var(--main-header-font);',
'    text-align: center;',
'}',
'',
'.a-AlertMessage-details {',
'     font-family: var(--regular-text-font);',
'}',
'',
'',
'.del-store {',
'    color: var(--danger-color);',
'}'))
,p_step_template=>wwv_flow_imp.id(19471509145742504218)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'25'
,p_last_updated_by=>'PFE94053@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20230803191547'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(40752775422970578943)
,p_plug_name=>'Seller Dashboard Navigation'
,p_region_css_classes=>'dashboard-side-menu'
,p_region_sub_css_classes=>'dashboard-side-menu-list'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-LinksList--showBadge:t-LinksList--showArrow:t-LinksList--actions:t-LinksList--showIcons'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_02'
,p_list_id=>wwv_flow_imp.id(38784043417088031374)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(19471863408174504294)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(40752775514989578944)
,p_plug_name=>'Stores Overview'
,p_region_template_options=>'#DEFAULT#:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>10
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(40752775693203578945)
,p_plug_name=>'Stores count'
,p_parent_plug_id=>wwv_flow_imp.id(40752775514989578944)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>3
,p_plug_display_point=>'SUB_REGIONS'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    l_count number;',
'begin',
'    select  count(DISTINCT store_id)',
'    into    l_count',
'    from    stores s',
'    where   s.customer_id = to_number(:USER_ID) ;',
'',
'    return ',
'        ''<div class="overview">',
'            <h3 class="overview-title">  Number Of Stores </h3>',
'            <h4 class="overview-data">'' || l_count || '' Stores(s)',
'            </h4>',
'            </div> '';',
'end;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(40752775770177578946)
,p_plug_name=>'Sales By Store'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>20
,p_plug_grid_column_span=>6
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(40752775829289578947)
,p_region_id=>wwv_flow_imp.id(40752775770177578946)
,p_chart_type=>'pie'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_value_format_type=>'decimal'
,p_value_decimal_places=>0
,p_value_format_scaling=>'none'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_pie_other_threshold=>0
,p_pie_selection_effect=>'highlight'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function modifyOptions(options) {',
'    const colors = ["#FFB929", "#3A3632", "#497620", "#F0E68C", "#BC4E98" , "#FFB929", "#497620", "#C33522"];',
'    options.dataFilter = function (data) {',
'        for (var i = 0; i < data.series.length; i++) {',
'        data.series[i].color = colors[i]',
'        }',
'',
'        return data;',
'    };',
'',
'    return options;',
'}',
''))
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(40752775987252578948)
,p_chart_id=>wwv_flow_imp.id(40752775829289578947)
,p_seq=>10
,p_name=>'Series 1'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    SUM(NEW_PRICE(oi.product_id) * oi.quantity) order_total,',
'    s.store_name',
'FROM orders o',
'LEFT JOIN order_items oi ON o.order_id = oi.order_id',
'LEFT JOIN product p ON oi.product_id = p.product_id',
'LEFT JOIN stores s ON p.store_id = s.store_id',
'WHERE s.customer_id = TO_NUMBER(:USER_ID)',
'GROUP BY s.store_name',
''))
,p_items_value_column_name=>'ORDER_TOTAL'
,p_items_label_column_name=>'STORE_NAME'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_items_label_display_as=>'LABEL'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(41092567727477059401)
,p_plug_name=>'Product Distribution by Store'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(41092567838102059402)
,p_region_id=>wwv_flow_imp.id(41092567727477059401)
,p_chart_type=>'area'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>false
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'off'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(41092567966026059403)
,p_chart_id=>wwv_flow_imp.id(41092567838102059402)
,p_seq=>10
,p_name=>'Series 1'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    COALESCE(count(p.product_id),0),',
'    s.store_name',
'FROM stores s',
'LEFT JOIN product p ON p.store_id = s.store_id',
'WHERE s.customer_id = TO_NUMBER(:USER_ID)',
'GROUP BY s.store_name',
''))
,p_items_value_column_name=>'COALESCE(COUNT(P.PRODUCT_ID),0)'
,p_items_label_column_name=>'STORE_NAME'
,p_color=>'#3a3632'
,p_line_type=>'auto'
,p_marker_rendered=>'on'
,p_marker_shape=>'star'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(41092568075271059404)
,p_chart_id=>wwv_flow_imp.id(41092567838102059402)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(41092568136282059405)
,p_chart_id=>wwv_flow_imp.id(41092567838102059402)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_step=>1
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(41092569238010059416)
,p_name=>'List Of Stores'
,p_template=>wwv_flow_imp.id(19471808805460504264)
,p_display_sequence=>40
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--altRowsDefault:t-Report--rowHighlight:t-Report--inline:t-Report--hideNoPagination'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    STORE_ID,',
'    CUSTOMER_ID,',
'    STORE_NAME,',
'    STORE_DESCRIPTION,',
'    ''Edit Store'', ',
'    ''Delete Store''',
'FROM',
'    STORES',
'WHERE',
'    CUSTOMER_ID = TO_NUMBER(:USER_ID);',
''))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(19471847069031504283)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(41092571958557059443)
,p_query_column_id=>1
,p_column_alias=>'STORE_ID'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(41092572078381059444)
,p_query_column_id=>2
,p_column_alias=>'CUSTOMER_ID'
,p_column_display_sequence=>20
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(41092572116114059445)
,p_query_column_id=>3
,p_column_alias=>'STORE_NAME'
,p_column_display_sequence=>30
,p_column_heading=>'Store Name'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(41092572202461059446)
,p_query_column_id=>4
,p_column_alias=>'STORE_DESCRIPTION'
,p_column_display_sequence=>40
,p_column_heading=>'Store Description'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(41154315320870227802)
,p_query_column_id=>5
,p_column_alias=>'''EDITSTORE'''
,p_column_display_sequence=>50
,p_column_heading=>'Edit Store'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:30:&SESSION.::&DEBUG.:30:P30_STORE_ID:#STORE_ID#'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil-alt.png" class="apex-edit-pencil-alt" alt="">'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(41154315484715227803)
,p_query_column_id=>6
,p_column_alias=>'''DELETESTORE'''
,p_column_display_sequence=>60
,p_column_heading=>'Delete Store'
,p_use_as_row_header=>'N'
,p_column_link=>'javascript:void(null)'
,p_column_linktext=>'<span class="fa fa-trash del-store" aria-hidden="true"></span>'
,p_column_link_attr=>'data-id=#STORE_ID#'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41154315845288227807)
,p_name=>'P71_STORE_TO_DELETE'
,p_item_sequence=>50
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(41154315560751227804)
,p_name=>'Remove Store'
,p_event_sequence=>10
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.del-store'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(41154315624955227805)
,p_event_id=>wwv_flow_imp.id(41154315560751227804)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Are you sure you want to delete this store ?',
'This action is irreversible and all the products in the store will be deleted !'))
,p_attribute_02=>'Delete Store'
,p_attribute_03=>'danger'
,p_attribute_04=>'fa-radiation'
,p_attribute_05=>'delete-confirm'
,p_attribute_06=>'Delete Store'
,p_attribute_07=>'Cancel'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(41154315729176227806)
,p_event_id=>wwv_flow_imp.id(41154315560751227804)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P71_STORE_TO_DELETE'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'$(this.triggeringElement).parent().data(''id'');'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(41154315935453227808)
,p_event_id=>wwv_flow_imp.id(41154315560751227804)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'delete from stores where store_id = :P71_STORE_TO_DELETE;'
,p_attribute_02=>'P71_STORE_TO_DELETE'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(41154316068327227809)
,p_event_id=>wwv_flow_imp.id(41154315560751227804)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(41092569238010059416)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(42879126019493839739)
,p_name=>'Edit Is_new Status CUSTOMER_STORE_VISITES'
,p_event_sequence=>20
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(42879126194353839740)
,p_event_id=>wwv_flow_imp.id(42879126019493839739)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'UPDATE customer_store_visites ',
'SET is_new = ''No''',
'WHERE customer_id != to_number(:USER_ID)',
'and is_new =''Yes''',
'and store_id in (select store_id from stores where customer_id = to_number(:USER_ID));'))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp.component_end;
end;
/
