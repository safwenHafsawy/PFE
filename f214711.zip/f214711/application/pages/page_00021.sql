prompt --application/pages/page_00021
begin
--   Manifest
--     PAGE: 00021
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>6662355588643785590
,p_default_application_id=>214711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_RSWSP'
);
wwv_flow_imp_page.create_page(
 p_id=>21
,p_name=>'SignUp'
,p_alias=>'SIGNUP'
,p_page_mode=>'MODAL'
,p_step_title=>'Create New Account'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(19471506229778504216)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_dialog_width=>'1200'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'16'
,p_last_updated_by=>'PFE94053@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20230727220144'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(21287184640240434537)
,p_plug_name=>'Create New Account'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'CUSTOMER'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(21287193649254434544)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(21287184640240434537)
,p_button_name=>'Create_Account'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--mobileHideLabel:t-Button--success:t-Button--iconLeft:t-Button--hoverIconPush'
,p_button_template_id=>wwv_flow_imp.id(19471882117602504304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create Account'
,p_button_position=>'CREATE'
,p_button_condition=>'P21_CUSTOMER_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-plus-square'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(21287194383200434544)
,p_branch_name=>'Go To Login'
,p_branch_action=>'f?p=&APP_ID.:9999:&SESSION.::&DEBUG.:9999::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>1
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(21287184972276434538)
,p_name=>'P21_CUSTOMER_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(21287184640240434537)
,p_item_source_plug_id=>wwv_flow_imp.id(21287184640240434537)
,p_item_default=>'customer_id_seq.nextVAL'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_source=>'CUSTOMER_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(21287185338340434538)
,p_name=>'P21_CUS_TYPE_ID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(21287184640240434537)
,p_item_source_plug_id=>wwv_flow_imp.id(21287184640240434537)
,p_item_default=>'2'
,p_source=>'CUS_TYPE_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(21287185768900434539)
,p_name=>'P21_FIRSTNAME'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(21287184640240434537)
,p_item_source_plug_id=>wwv_flow_imp.id(21287184640240434537)
,p_prompt=>'<p style="color:grey;opacity:0.8;">First Name</p>'
,p_source=>'FIRSTNAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>50
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(19471880312432504303)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(21287186170111434539)
,p_name=>'P21_LASTNAME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(21287184640240434537)
,p_item_source_plug_id=>wwv_flow_imp.id(21287184640240434537)
,p_prompt=>'<p style="color:grey;opacity:0.8;">Last Name</p>'
,p_source=>'LASTNAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>50
,p_field_template=>wwv_flow_imp.id(19471880312432504303)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(21287186571993434539)
,p_name=>'P21_PHONE'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(21287184640240434537)
,p_item_source_plug_id=>wwv_flow_imp.id(21287184640240434537)
,p_prompt=>'<p style="color:grey;opacity:0.5;"> Phone </p>'
,p_source=>'PHONE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>50
,p_field_template=>wwv_flow_imp.id(19471880312432504303)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(21287186930280434539)
,p_name=>'P21_EMAIL'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(21287184640240434537)
,p_item_source_plug_id=>wwv_flow_imp.id(21287184640240434537)
,p_prompt=>'<p style="color:grey;opacity:0.5;"> Email </p>'
,p_source=>'EMAIL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>50
,p_field_template=>wwv_flow_imp.id(19471880312432504303)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(21287187398516434540)
,p_name=>'P21_ADDRESS'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(21287184640240434537)
,p_item_source_plug_id=>wwv_flow_imp.id(21287184640240434537)
,p_prompt=>'<p style="color:grey;opacity:0.5;">Address</p>'
,p_source=>'ADDRESS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>50
,p_field_template=>wwv_flow_imp.id(19471880312432504303)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(21287187733510434540)
,p_name=>'P21_CITY'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(21287184640240434537)
,p_item_source_plug_id=>wwv_flow_imp.id(21287184640240434537)
,p_prompt=>'<p style="color:grey;opacity:0.5;">City</p>'
,p_source=>'CITY_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select city_name,',
'       city_id',
'from cities',
'order by 1 '))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(19471880312432504303)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(21287188954969434541)
,p_name=>'P21_PASSWORD'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(21287184640240434537)
,p_item_source_plug_id=>wwv_flow_imp.id(21287184640240434537)
,p_prompt=>'<p style="color:grey;opacity:0.5;">Password</p>'
,p_source=>'PASSWORD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>32
,p_cMaxlength=>50
,p_colspan=>6
,p_field_template=>wwv_flow_imp.id(19471880312432504303)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(21365794351486797105)
,p_name=>'CONFIRM_PASSWORD'
,p_is_required=>true
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(21287184640240434537)
,p_prompt=>'<p style="color:grey;opacity:0.5;">Confirm Password</p>'
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(19471880312432504303)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(18879229948856497248)
,p_validation_name=>'FIRST_NAME_VALIDATION'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'  IF (REGEXP_LIKE(:P21_FIRSTNAME, ''^[[:alpha:]]+$'')) THEN',
'    RETURN true;',
'  ELSE',
'    RETURN false;',
'  END IF;',
'END;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_BOOLEAN'
,p_error_message=>'First name can contain only characters !'
,p_associated_item=>wwv_flow_imp.id(21287185768900434539)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(18879230050872497249)
,p_validation_name=>'LASTNAME_VALIDATION'
,p_validation_sequence=>20
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'  IF (REGEXP_LIKE(:P21_FIRSTNAME, ''^[[:alpha:]]+$'')) THEN',
'    RETURN true;',
'  ELSE',
'    RETURN false;',
'  END IF;',
'END;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_BOOLEAN'
,p_error_message=>'Last Name can only contain chars !'
,p_associated_item=>wwv_flow_imp.id(21287186170111434539)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(21365794277589797104)
,p_validation_name=>'EAMIL_VALIDATION'
,p_validation_sequence=>30
,p_validation=>'VALIDATIONS.validate_email(:P21_EMAIL)'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'This Shit is not an email son'
,p_associated_item=>wwv_flow_imp.id(21287186930280434539)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(21365794408702797106)
,p_validation_name=>'CONFRIM PASSWORD MATCHING'
,p_validation_sequence=>40
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    RETURN :P21_PASSWORD = :CONFIRM_PASSWORD;',
'END;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_BOOLEAN'
,p_error_message=>'Passwords Don''t match !'
,p_associated_item=>wwv_flow_imp.id(21287188954969434541)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(21365794553406797107)
,p_validation_name=>'PHONE_VALIDATION'
,p_validation_sequence=>50
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN ',
'    RETURN REGEXP_LIKE(:P21_PHONE, ''^[0-9+\s]+$'');',
'END;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_BOOLEAN'
,p_error_message=>'Invalid Phone Number !'
,p_associated_item=>wwv_flow_imp.id(21287186571993434539)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(18879230163957497250)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Process form Create New Account'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'MANAGE_CUSTOMERS.create_new_account(',
'    :P21_FIRSTNAME, ',
'    :P21_LASTNAME,',
'    :P21_PHONE,',
'    :P21_EMAIL,',
'    :P21_ADDRESS,',
'    :P21_CITY,',
'    :P21_PASSWORD',
');'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Could Not Create Your Account ! Please Try Again'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Account Created successfully ! you may now login'
,p_internal_uid=>18879230163957497250
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(21287194830942434545)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(21287184640240434537)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form SignUp'
,p_internal_uid=>21287194830942434545
);
wwv_flow_imp.component_end;
end;
/
