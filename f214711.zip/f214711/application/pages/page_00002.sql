prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>6662355588643785590
,p_default_application_id=>214711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_RSWSP'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>'Products'
,p_alias=>'PRODUCTS'
,p_step_title=>'Products'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(".heart").hover(function(){',
'  $(this).css("color", "#B43757");',
'  }, function(){',
'  $(this).css("color", "black");',
'});'))
,p_css_file_urls=>'#APP_FILES#Styling/main_style#MIN#.css'
,p_step_template=>wwv_flow_imp.id(19471509145742504218)
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'22'
,p_last_updated_by=>'PFE94053@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20230802101537'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(21887101690316527726)
,p_plug_name=>'products if main category'
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--styleB:margin-top-md'
,p_plug_template=>wwv_flow_imp.id(19471549395551504237)
,p_plug_display_sequence=>20
,p_plug_item_display_point=>'BELOW'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT p.product_id,',
'            p.product_name,',
'            p.unit_price,',
'            p.store_id,',
'            s.store_name,',
'            discount,',
'            NEW_PRICE (P.PRODUCT_ID) new_price,',
'            pi.image,',
'            s.customer_id as store_owner',
'    FROM    product p',
'            join (SELECT image_id,',
'                product_id,',
'                image',
'                FROM(SELECT image_id,',
'                            product_id,',
'                            image,',
'                            Row_number()',
'                                over (',
'                                PARTITION BY product_id',
'                                ORDER BY image_id) AS rn',
'                    FROM   product_images) img',
'                    WHERE  rn = 1) pi',
'            ON p.product_id = pi.product_id, ',
'            STORES s,',
'            categories c',
'    WHERE  c.category_id = p.category_id ',
'    AND    c.category_parent = :P2_CATEG_ID ',
'    AND    p.store_id = s.store_id;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_ajax_items_to_submit=>'P2_CATEG_ID'
,p_plug_query_num_rows_type=>'SCROLL'
,p_plug_query_no_data_found=>'No Products in this category !'
,p_show_total_row_count=>false
,p_plug_display_condition_type=>'FUNCTION_BODY'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_parent_category number;',
'BEGIN',
'    select category_parent',
'    into l_parent_category',
'    from categories ',
'    where category_id = :P2_CATEG_ID;',
'',
'    if l_parent_category is not null then',
'        return false;',
'    else ',
'        return true;',
'    ',
'    end if;',
'end;'))
,p_plug_display_when_cond2=>'PLSQL'
,p_pagination_display_position=>'BOTTOM_RIGHT'
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(21887103722080527728)
,p_region_id=>wwv_flow_imp.id(21887101690316527726)
,p_layout_type=>'GRID'
,p_grid_column_count=>5
,p_card_css_classes=>'card'
,p_title_adv_formatting=>false
,p_title_column_name=>'PRODUCT_NAME'
,p_sub_title_adv_formatting=>true
,p_sub_title_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{case DISCOUNT/}',
'{when 0/}',
'<b>&NEW_PRICE. TN</b>',
'{otherwise/}',
'&DISCOUNT.% &emsp;',
'<b>&NEW_PRICE. TN </b>&emsp;',
'<s> &UNIT_PRICE. TN</s>',
'',
'',
'{endcase/}'))
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_media_adv_formatting=>false
,p_media_source_type=>'BLOB'
,p_media_blob_column_name=>'IMAGE'
,p_media_display_position=>'FIRST'
,p_media_appearance=>'SQUARE'
,p_media_sizing=>'FIT'
,p_media_css_classes=>'card-img'
,p_pk1_column_name=>'PRODUCT_ID'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(22821463235440138535)
,p_card_id=>wwv_flow_imp.id(21887103722080527728)
,p_action_type=>'FULL_CARD'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:18:&SESSION.::&DEBUG.:18:P18_PRODUCT_ID:&PRODUCT_ID.'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(34869893709517248624)
,p_card_id=>wwv_flow_imp.id(21887103722080527728)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>20
,p_label=>'Store : &STORE_NAME.'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:5:P5_STORE_ID,P5_STORE_NAME,P5_STORE_OWNER_ID:&STORE_ID.,&STORE_NAME.,&STORE_OWNER.'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'to_store'
,p_is_hot=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(37171145420084069210)
,p_card_id=>wwv_flow_imp.id(21887103722080527728)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>30
,p_label=>'wishlist'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'javascript:void(null);'
,p_link_attributes=>'data-id=&PRODUCT_ID.'
,p_button_display_type=>'ICON'
,p_icon_css_classes=>'fa-heart'
,p_action_css_classes=>'heart'
,p_is_hot=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(34869893805508248625)
,p_card_id=>wwv_flow_imp.id(21887103722080527728)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>50
,p_label=>'Add To Cart'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:::'
,p_button_display_type=>'TEXT_WITH_ICON'
,p_icon_css_classes=>'fa-plus-square'
,p_action_css_classes=>'to_cart'
,p_is_hot=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(37036232806642922408)
,p_plug_name=>'products if sub category'
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--styleB:margin-top-md'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(19471549395551504237)
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT p.product_id,',
'            p.product_name,',
'            p.unit_price,',
'            p.store_id,',
'            s.store_name,',
'            discount,',
'            NEW_PRICE (P.PRODUCT_ID) new_price,',
'            pi.image,',
'            s.customer_id as store_owner',
'    FROM    product p',
'            join (SELECT image_id,',
'                product_id,',
'                image',
'                FROM(SELECT image_id,',
'                            product_id,',
'                            image,',
'                            Row_number()',
'                                over (',
'                                PARTITION BY product_id',
'                                ORDER BY image_id) AS rn',
'                    FROM   product_images) img',
'                    WHERE  rn = 1) pi',
'            ON p.product_id = pi.product_id, ',
'            STORES s',
'    WHERE  category_id =:P2_CATEG_ID ',
'    AND    p.store_id = s.store_id;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_ajax_items_to_submit=>'P2_CATEG_ID'
,p_plug_query_num_rows_type=>'SCROLL'
,p_plug_query_no_data_found=>'No Products in this category !'
,p_show_total_row_count=>false
,p_plug_display_condition_type=>'FUNCTION_BODY'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_parent_category number;',
'BEGIN',
'    select category_parent',
'    into l_parent_category',
'    from categories ',
'    where category_id = :P2_CATEG_ID;',
'',
'    if l_parent_category is not null then',
'        return true;',
'    else ',
'        return false;',
'    ',
'    end if;',
'end;'))
,p_plug_display_when_cond2=>'PLSQL'
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(37036232934796922409)
,p_region_id=>wwv_flow_imp.id(37036232806642922408)
,p_layout_type=>'GRID'
,p_grid_column_count=>5
,p_card_css_classes=>'card'
,p_title_adv_formatting=>false
,p_title_column_name=>'PRODUCT_NAME'
,p_sub_title_adv_formatting=>true
,p_sub_title_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{case DISCOUNT/}',
'{when 0/}',
'<b>&NEW_PRICE. TN</b>',
'{otherwise/}',
'&DISCOUNT.% &emsp;',
'<b>&NEW_PRICE. TN </b>&emsp;',
'<s> &UNIT_PRICE. TN</s>',
'',
'',
'{endcase/}'))
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_media_adv_formatting=>false
,p_media_source_type=>'BLOB'
,p_media_blob_column_name=>'IMAGE'
,p_media_display_position=>'FIRST'
,p_media_appearance=>'SQUARE'
,p_media_sizing=>'FIT'
,p_media_css_classes=>'card-img'
,p_pk1_column_name=>'PRODUCT_ID'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(37036233023893922410)
,p_card_id=>wwv_flow_imp.id(37036232934796922409)
,p_action_type=>'FULL_CARD'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:18:&SESSION.::&DEBUG.:18:P18_PRODUCT_ID:&PRODUCT_ID.'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(37036233154622922411)
,p_card_id=>wwv_flow_imp.id(37036232934796922409)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>20
,p_label=>'Store : &STORE_NAME.'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:5:P5_STORE_ID,P5_STORE_OWNER_ID,P5_STORE_NAME:&STORE_ID.,&STORE_OWNER.,&STORE_NAME.'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'to_store'
,p_is_hot=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(37171145789289069213)
,p_card_id=>wwv_flow_imp.id(37036232934796922409)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>30
,p_label=>'wishlist'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'javascript:void(null);'
,p_link_attributes=>'data-id=&PRODUCT_ID.'
,p_button_display_type=>'ICON'
,p_icon_css_classes=>'fa-heart'
,p_action_css_classes=>'heart'
,p_is_hot=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(37036233271826922412)
,p_card_id=>wwv_flow_imp.id(37036232934796922409)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>40
,p_label=>'Add To Cart'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.::P6_PRODUCT_ID:&PRODUCT_ID.'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'to_cart'
,p_is_hot=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(42887193873379190818)
,p_plug_name=>'Filter Products If sub category'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>60
,p_plug_display_point=>'REGION_POSITION_02'
,p_plug_source_type=>'NATIVE_FACETED_SEARCH'
,p_filtered_region_id=>wwv_flow_imp.id(37036232806642922408)
,p_plug_display_condition_type=>'FUNCTION_BODY'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_parent_category number;',
'BEGIN',
'    select category_parent',
'    into l_parent_category',
'    from categories ',
'    where category_id = :P2_CATEG_ID;',
'',
'    if l_parent_category is not null then',
'        return true;',
'    else ',
'        return false;',
'    ',
'    end if;',
'end;'))
,p_plug_display_when_cond2=>'PLSQL'
,p_attribute_01=>'N'
,p_attribute_06=>'N'
,p_attribute_09=>'N'
,p_attribute_12=>'10000'
,p_attribute_13=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(65695537456337070607)
,p_plug_name=>'Filter Products'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>50
,p_plug_display_point=>'REGION_POSITION_02'
,p_plug_source_type=>'NATIVE_FACETED_SEARCH'
,p_filtered_region_id=>wwv_flow_imp.id(21887101690316527726)
,p_plug_display_condition_type=>'FUNCTION_BODY'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_parent_category number;',
'BEGIN',
'    select category_parent',
'    into l_parent_category',
'    from categories ',
'    where category_id = :P2_CATEG_ID;',
'',
'    if l_parent_category is not null then',
'        return false;',
'    else ',
'        return true;',
'    ',
'    end if;',
'end;'))
,p_plug_display_when_cond2=>'PLSQL'
,p_attribute_01=>'N'
,p_attribute_06=>'N'
,p_attribute_09=>'N'
,p_attribute_12=>'10000'
,p_attribute_13=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(21951574961343991009)
,p_name=>'P2_CATEG_ID'
,p_item_sequence=>10
,p_item_default=>'1'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(42887193924405190819)
,p_name=>'P2_SEARCH_PROD_1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(42887193873379190818)
,p_prompt=>'search'
,p_source=>'PRODUCT_NAME,PRODUCT_DESCRIPTION,PRODUCT_DETAILS,IMAGE_FILENAME'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'ROW'
,p_attribute_02=>'FACET'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(42887194098746190820)
,p_name=>'P2_FILTER_WITH_PRICE_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(42887193873379190818)
,p_prompt=>'Filter With Price'
,p_source=>'UNIT_PRICE'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_RANGE'
,p_lov=>'STATIC:Less Than 10 TDN;|10,From 10 to 50 TDN;20|50,From 50 To 100 TDN;50|100,From 100 To 200 TDN;100|200,From 200 To 300 TDN;200|300,More Than 100 TDN;300|'
,p_item_icon_css_classes=>'fa-money'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'D'
,p_fc_show_more_count=>7
,p_fc_filter_values=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>false
,p_fc_actions_filter=>true
,p_fc_toggleable=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(42887194119318190821)
,p_name=>'P2_HAS_DISCOUNT_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(42887193873379190818)
,p_prompt=>'Filter With Discount'
,p_source=>'DISCOUNT'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_RANGE'
,p_lov=>'STATIC:More Than 5%;5|,More Than 10%;10|,More Than 25%;25|,More Than 50%;50|,More Than 75%;75|'
,p_item_icon_css_classes=>'fa-fire'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'D'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_show_selected_first=>false
,p_fc_show_chart=>false
,p_fc_actions_filter=>true
,p_fc_toggleable=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(65695540222335070615)
,p_name=>'P2_SEARCH_PROD'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(65695537456337070607)
,p_prompt=>'search'
,p_source=>'PRODUCT_NAME,PRODUCT_DESCRIPTION,PRODUCT_DETAILS,IMAGE_FILENAME'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'ROW'
,p_attribute_02=>'FACET'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(78602152602420363211)
,p_name=>'P2_FILTER_WITH_PRICE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(65695537456337070607)
,p_prompt=>'Filter With Price'
,p_source=>'UNIT_PRICE'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_RANGE'
,p_lov=>'STATIC:Less Than 10 TDN;|10,From 10 to 50 TDN;20|50,From 50 To 100 TDN;50|100,From 100 To 200 TDN;100|200,From 200 To 300 TDN;200|300,More Than 100 TDN;300|'
,p_item_icon_css_classes=>'fa-money'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'D'
,p_fc_show_more_count=>7
,p_fc_filter_values=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>false
,p_fc_actions_filter=>true
,p_fc_toggleable=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(78602152742925363212)
,p_name=>'P2_HAS_DISCOUNT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(65695537456337070607)
,p_prompt=>'Filter With Discount'
,p_source=>'DISCOUNT'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_RANGE'
,p_lov=>'STATIC:More Than 5%;5|,More Than 10%;10|,More Than 25%;25|,More Than 50%;50|,More Than 75%;75|'
,p_item_icon_css_classes=>'fa-fire'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'D'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_show_selected_first=>false
,p_fc_show_chart=>false
,p_fc_actions_filter=>true
,p_fc_toggleable=>false
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(22821463395971138536)
,p_name=>'Show success Message'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(21887101690316527726)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(22821463411584138537)
,p_event_id=>wwv_flow_imp.id(22821463395971138536)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var productAction   = this.data.P18_ACTION,',
'    productQuantity = this.data.P18_QUANTITY,',
'    productCard$  = apex.jQuery("#message_" + this.data.P18_PRODUCT_ID);',
'',
'if (productAction === ''ADD'') {',
'    productCard$.text("Added " + productQuantity + " to cart!");',
'} else if (productAction === ''EDIT'') {',
'    productCard$.text("Updated quantity to " + productQuantity + "!");',
'} else if (productAction === ''DELETE'') {',
'    productCard$.text("Removed from cart!");',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(22821463565596138538)
,p_name=>'Update Shopping Cart Header'
,p_event_sequence=>20
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(21887101690316527726)
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'parseInt(this.data.SHOPPING_CART_ITEMS) > 0'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(22821463681979138539)
,p_event_id=>wwv_flow_imp.id(22821463565596138538)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// Update Badge Text',
'apex.jQuery(".js-shopping-cart-item .t-Button-badge").text(this.data.SHOPPING_CART_ITEMS);',
'',
'// Update Icon',
'apex.jQuery(".js-shopping-cart-item .t-Icon").removeClass(''fa-cart-empty'').addClass(''fa-cart-full'');'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(22821463787428138540)
,p_event_id=>wwv_flow_imp.id(22821463565596138538)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// Update Badge Text',
'apex.jQuery(".js-shopping-cart-item .t-Button-badge").text('''');',
'',
'// Update Icon',
'apex.jQuery(".js-shopping-cart-item .t-Icon").removeClass(''fa-cart-full'').addClass(''fa-cart-empty'');'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(37781261115186828702)
,p_name=>'wishlist'
,p_event_sequence=>30
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.heart'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_display_when_type=>'EXPRESSION'
,p_display_when_cond=>'APEX_AUTHENTICATION.IS_AUTHENTICATED'
,p_display_when_cond2=>'PLSQL'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(37781262052496828704)
,p_event_id=>wwv_flow_imp.id(37781261115186828702)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_name=>'set value'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P2_PRODUCT_ID'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'$(this.triggeringElement).data(''id'')'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(37781261589954828704)
,p_event_id=>wwv_flow_imp.id(37781261115186828702)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'console.log($v(''P2_PRODUCT_ID''))'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(37781262522795828704)
,p_event_id=>wwv_flow_imp.id(37781261115186828702)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_name=>'add_wishlist'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'  IF APEX_AUTHENTICATION.IS_AUTHENTICATED THEN',
'    ADD_TO_WISHLIST.ADD_PRODUCT(:P18_PRODUCT_ID, to_number(:USER_ID));',
'  ELSE',
'    apex_error.add_error (',
'      p_message => ''Login first to unlock this action.'',',
'      p_display_location => apex_error.c_inline_in_notification',
'    );',
'  END IF;',
'END;',
''))
,p_attribute_02=>'P2_PRODUCT_ID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(37781263055189828704)
,p_event_id=>wwv_flow_imp.id(37781261115186828702)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.message.showPageSuccess( ''Product added to wishlist'' );'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(37781272935001831157)
,p_name=>'wishlist_error'
,p_event_sequence=>40
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.heart'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_display_when_type=>'EXPRESSION'
,p_display_when_cond=>'not APEX_AUTHENTICATION.IS_AUTHENTICATED'
,p_display_when_cond2=>'PLSQL'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(37781273319830831157)
,p_event_id=>wwv_flow_imp.id(37781272935001831157)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.message.showErrors([',
'    {',
'        type:       "error",',
'        location:   [ "page" ],',
'        message:    "You Must Be Authenticated Before Adding Product To Wishlist !",',
'        unsafe:     false',
'    }',
']);',
''))
);
wwv_flow_imp.component_end;
end;
/
