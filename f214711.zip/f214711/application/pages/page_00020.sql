prompt --application/pages/page_00020
begin
--   Manifest
--     PAGE: 00020
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>6662355588643785590
,p_default_application_id=>214711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_RSWSP'
);
wwv_flow_imp_page.create_page(
 p_id=>20
,p_name=>'Replace Order Item'
,p_alias=>'REPLACE-ORDER-ITEM'
,p_page_mode=>'MODAL'
,p_step_title=>'Replace Order Item'
,p_autocomplete_on_off=>'OFF'
,p_css_file_urls=>'#APP_FILES#Styling/main_style#MIN#.css'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_width=>'1200'
,p_protection_level=>'C'
,p_page_component_map=>'23'
,p_last_updated_by=>'PFE94053@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20230817192502'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(50516535059781306445)
,p_plug_name=>'Similiar Products To &P20_CANCELLED_PRODUCT_NAME.'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--textContent:t-Region--scrollBody:margin-top-lg:margin-bottom-lg:margin-left-lg:margin-right-lg'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(52184847097494530102)
,p_plug_name=>'Simliar Products'
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--styleB'
,p_plug_template=>wwv_flow_imp.id(19471549395551504237)
,p_plug_display_sequence=>110
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT p.product_id,',
'       p.product_name,',
'       p.unit_price,',
'       p.discount,',
'       p.category_id,',
'       NEW_PRICE(p.product_id) AS new_price,',
'       pi.image',
'FROM product p',
'JOIN (',
'    SELECT image_id,',
'           product_id,',
'           image',
'    FROM (',
'        SELECT image_id,',
'               product_id,',
'               image,',
'               ROW_NUMBER() OVER (PARTITION BY product_id ORDER BY image_id) AS rn',
'        FROM product_images',
'    ) img',
'    WHERE rn = 1',
') pi ON p.product_id = pi.product_id',
'JOIN variant_stock vs ON p.product_id = vs.product_id',
'WHERE NOT p.product_id = :P20_CANCELLED_PRODUCT_ID',
'AND p.category_id = :P20_CANCELLED_PRODUCT_CATEGORY',
'AND UPPER(vs.variant_1) LIKE ''%'' || UPPER(:P20_CANCELLED_PRODUCT_VARIANT_1) || ''%'';',
''))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_ajax_items_to_submit=>'P20_CANCELLED_PRODUCT_CATEGORY,P20_CANCELLED_PRODUCT_ID,P20_CANCELLED_PRODUCT_VARIANT_1'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(52184847167636530103)
,p_region_id=>wwv_flow_imp.id(52184847097494530102)
,p_layout_type=>'GRID'
,p_card_css_classes=>'card'
,p_title_adv_formatting=>false
,p_title_column_name=>'PRODUCT_NAME'
,p_sub_title_adv_formatting=>true
,p_sub_title_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{case DISCOUNT/}',
'{when 0/}',
'<b>&NEW_PRICE. TN</b>',
'{otherwise/}',
'&DISCOUNT.% &emsp;',
'<b>&NEW_PRICE. TN </b>&emsp;',
'<s> &UNIT_PRICE. TN</s>',
'',
'',
'{endcase/}'))
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_media_adv_formatting=>false
,p_media_source_type=>'BLOB'
,p_media_blob_column_name=>'IMAGE'
,p_media_display_position=>'FIRST'
,p_media_appearance=>'SQUARE'
,p_media_sizing=>'FIT'
,p_pk1_column_name=>'PRODUCT_ID'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(52184848528210530117)
,p_card_id=>wwv_flow_imp.id(52184847167636530103)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>10
,p_label=>'Add To Order'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:12:&SESSION.::&DEBUG.:12:P12_PRODUCT_ID,P12_CATEGORY_ID,P12_IS_REPLACEMENT,P12_ORDER_ID,P12_CANCELLED_PROD_ID:&PRODUCT_ID.,&CATEGORY_ID.,1,&P20_ORDER_ID.,&P20_CANCELLED_PRODUCT_ID.'
,p_button_display_type=>'TEXT'
,p_is_hot=>true
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(50516535110139306446)
,p_name=>'P20_CANCELLED_PRODUCT_ID'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(50516535485464306449)
,p_name=>'P20_CANCELLED_PRODUCT_NAME'
,p_item_sequence=>50
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(52184847512901530107)
,p_name=>'P20_CANCELLED_PRODUCT_CATEGORY'
,p_item_sequence=>70
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(52184847684106530108)
,p_name=>'P20_CANCELLED_PRODUCT_VARIANT_1'
,p_item_sequence=>80
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(52184847703049530109)
,p_name=>'P20_CANCELLED_PRODUCT_VARIANT_2'
,p_item_sequence=>90
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(52184847805025530110)
,p_name=>'P20_CANCELLED_PRODUCT_VARIANT_3'
,p_item_sequence=>100
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(52184848038964530112)
,p_name=>'P20_CANCELLED_PRODUCT_STOCK'
,p_item_sequence=>60
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(52184848935744530121)
,p_name=>'P20_ORDER_ID'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(52184847299577530104)
,p_name=>'Getting Product characteristics'
,p_event_sequence=>10
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(52184848369494530115)
,p_event_id=>wwv_flow_imp.id(52184847299577530104)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(52184847097494530102)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(52184847389740530105)
,p_event_id=>wwv_flow_imp.id(52184847299577530104)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    p.category_id,',
'    vs.variant_1,',
'    vs.variant_2,',
'    vs.variant_3',
'INTO',
'    :P20_CANCELLED_PRODUCT_CATEGORY,',
'    :P20_CANCELLED_PRODUCT_VARIANT_1,',
'    :P20_CANCELLED_PRODUCT_VARIANT_2,',
'    :P20_CANCELLED_PRODUCT_VARIANT_3',
'FROM',
'    product p',
'INNER JOIN variant_stock vs ON p.product_id = vs.product_id ',
'WHERE ',
'    stock_id = :P20_CANCELLED_PRODUCT_STOCK;'))
,p_attribute_02=>'P20_CANCELLED_PRODUCT_STOCK'
,p_attribute_03=>'P20_CANCELLED_PRODUCT_VARIANT_1,P20_CANCELLED_PRODUCT_VARIANT_2,P20_CANCELLED_PRODUCT_VARIANT_3,P20_CANCELLED_PRODUCT_CATEGORY'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(52184848124233530113)
,p_event_id=>wwv_flow_imp.id(52184847299577530104)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(52184847097494530102)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(52184848287434530114)
,p_event_id=>wwv_flow_imp.id(52184847299577530104)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(52184847097494530102)
);
wwv_flow_imp.component_end;
end;
/
