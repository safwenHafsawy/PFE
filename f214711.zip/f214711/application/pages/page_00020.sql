prompt --application/pages/page_00020
begin
--   Manifest
--     PAGE: 00020
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>6662355588643785590
,p_default_application_id=>214711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_RSWSP'
);
wwv_flow_imp_page.create_page(
 p_id=>20
,p_name=>'testing'
,p_alias=>'TESTING'
,p_step_title=>'testing'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.lock-item{',
'    position: absolute;',
'    left: 42%;',
'    top: 43% ;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'17'
,p_last_updated_by=>'PFE94053@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20230723132846'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(42153517820949704846)
,p_plug_name=>'variant'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>20
,p_plug_grid_column_span=>4
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(42153518051548704848)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(42153517820949704846)
,p_button_name=>'lock'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--tiny'
,p_button_template_id=>wwv_flow_imp.id(19471881378436504304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Lock'
,p_icon_css_classes=>'fa-padlock-unlock'
,p_grid_column_css_classes=>'lock-item'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(42153517928991704847)
,p_name=>'P20_NEW'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(42153517820949704846)
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(19471880312432504303)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp.component_end;
end;
/
