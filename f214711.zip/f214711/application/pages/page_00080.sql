prompt --application/pages/page_00080
begin
--   Manifest
--     PAGE: 00080
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>6662355588643785590
,p_default_application_id=>214711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_RSWSP'
);
wwv_flow_imp_page.create_page(
 p_id=>80
,p_name=>'display messages'
,p_alias=>'DISPLAY-CONVERSATION'
,p_page_mode=>'MODAL'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>'var current_user = &USER_ID.'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(function(){',
'    ',
'    let closeButton = parent.$(''.ui-dialog-titlebar-close''); ',
'    closeButton.hide(); ',
'',
'    if($("#display-messages_jqm_list_view").children().length > 0){',
'       const listOfMessages =  Array.from($("#display-messages_jqm_list_view").children(".a-ListView-item"));',
'        console.log(listOfMessages);',
'        listOfMessages.forEach(message => {',
'            const sender_id = message.getAttribute(''data-id'');',
'            ',
'            if(sender_id != current_user) message.classList.add("not-own-message");',
'            else message.classList.add("own-message")',
'        })',
'    }',
'',
'',
'    let $lastItem = $("#display-messages_jqm_list_view li:last")[0]; ',
'',
'    $lastItem.scrollIntoView({ behavior: "auto", block: "end", inline: "nearest" });',
'})();'))
,p_css_file_urls=>'#APP_FILES#Styling/main_style#MIN#.css'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.chat-title {',
'    text-align: center;',
'    font-family: var(--main-header-font);',
'}',
'',
'.close-btn {',
'    position: absolute;',
'    top: 1%;',
'    right: 1%;',
'    background-color: var(--danger-color);',
'    color: var(--third-color);',
'    font-family: var(--regular-text-font);',
'}',
'.send_reply{',
'    padding: 10px;',
'    display: flex;',
'    flex-direction: row;',
'    justify-content: center;',
'}',
'',
'.t-ItemContainer-end {',
'    display: flex;',
'    justify-content: center;',
'    align-items: center;',
'}',
'',
'.ui-btn {',
'    border: none;',
'}',
'',
'.messages{',
'    padding:10px;',
'}',
'',
'.own-message{',
'    display: flex;',
'    flex-direction: column;',
'    justify-content: flex-end;',
'    align-items: flex-end;',
'    margin-left: 20%;',
'}',
'',
'.not-own-message {',
'    width: 80%;',
'    display: flex;',
'    flex-direction: column;',
'    justify-content: flex-end;',
'    align-items: flex-start;',
'}',
'',
'.message {',
'    font-family: var(--regular-text-font);',
'    font-size: medium;',
'    background-color: var(--first-color);',
'    padding: 15px;',
'    margin: 5px;',
'    border-radius: 20px;',
'}',
'',
'.ui-li-aside {',
'    font-family: var(--secondary-header-font);',
'}',
'',
'',
'.apex-no-data-found {',
'    display: none;',
'}'))
,p_step_template=>wwv_flow_imp.id(19471506229778504216)
,p_page_css_classes=>'drawer'
,p_page_template_options=>'#DEFAULT#:t-Dialog--noPadding:t-DeferredRendering:js-dialog-class-t-Drawer--pullOutEnd:js-dialog-class-t-Drawer--lg:t-PageBody--noContentPadding'
,p_protection_level=>'C'
,p_page_component_map=>'25'
,p_last_updated_by=>'PFE94053@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20230801191304'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(40424820623949237329)
,p_plug_name=>'Display'
,p_region_name=>'display-messages'
,p_region_css_classes=>'messages'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(19471543615601504235)
,p_plug_display_sequence=>80
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    m.message_id,',
'    m.conversation_id,',
'    m.message_content,',
'    m.sent_at,',
'    m.status,',
'    m.message_sender_id,',
'    CASE ',
'        WHEN c.participant_1_id = m.message_sender_id THEN c1.firstname || '' '' || c1.lastname',
'        WHEN c.participant_2_id = m.message_sender_id THEN c2.firstname || '' '' || c2.lastname',
'    END AS sender_name',
'FROM',
'    MESSAGES m',
'LEFT JOIN',
'    conversations c ON m.conversation_id = c.conversation_id',
'LEFT JOIN',
'    customer c1 ON c.participant_1_id = c1.customer_id',
'LEFT JOIN',
'    customer c2 ON c.participant_2_id = c2.customer_id',
'WHERE',
'    m.conversation_id = :P80_CONVERSATION_ID',
'ORDER BY SENT_AT;',
''))
,p_plug_source_type=>'NATIVE_JQM_LIST_VIEW'
,p_plug_query_num_rows=>100
,p_plug_query_no_data_found=>'No Messages Yet !'
,p_landmark_type=>'region'
,p_attribute_01=>'ADVANCED_FORMATTING'
,p_attribute_04=>'data-id= &MESSAGE_SENDER_ID.'
,p_attribute_05=>'<span class="message">&MESSAGE_CONTENT.</span>'
,p_attribute_07=>'&SENDER_NAME. - &SENT_AT.'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(40424822613365237349)
,p_plug_name=>'Send Reply'
,p_region_css_classes=>'send_reply'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(19471801147464504260)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(40752775147304578940)
,p_plug_name=>'Header Container'
,p_region_css_classes=>'header-container'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_01'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(40752771675633578905)
,p_plug_name=>'Title '
,p_parent_plug_id=>wwv_flow_imp.id(40752775147304578940)
,p_region_css_classes=>'page-title-desc'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>10
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    customer_name varchar2(300);',
'BEGIN',
'    SELECT firstname || '' '' || lastname',
'    INTO customer_name',
'    FROM customer c',
'    WHERE  c.customer_id = :P80_PARTICIPANT_2_ID;',
'',
'    RETURN ',
'        ''<h3 class="chat-title">'' || customer_name || '' messages </h3>'';',
'END;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
,p_ajax_items_to_submit=>'P80_PARTICIPANT_2_ID'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(40752774932430578938)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(40752775147304578940)
,p_button_name=>'Close_converstaion'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(19471882000429504304)
,p_button_image_alt=>'Close'
,p_button_css_classes=>'close-btn'
,p_icon_css_classes=>'fa-remove'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(40752771473755578903)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(40424822613365237349)
,p_button_name=>'Send_message'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(19471881378436504304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Send Message'
,p_button_position=>'BUTTON_END'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-send'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(40424821298643237335)
,p_name=>'P80_CONVERSATION_ID'
,p_item_sequence=>50
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(40424822735275237350)
,p_name=>'P80_MESSAGE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(40424822613365237349)
,p_prompt=>'<span class="message-placeholder"> Type a message</span>'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(19471879586967504303)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(40752771597600578904)
,p_name=>'P80_SENDER_NAME'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(40752773323930578922)
,p_name=>'P80_PARTICIPANT_1_ID'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(40752774720207578936)
,p_name=>'P80_CURRENT_DATE'
,p_item_sequence=>70
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41154317677873227825)
,p_name=>'P80_PARTICIPANT_2_ID'
,p_item_sequence=>40
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(41154317765415227826)
,p_name=>'Checking Conversation existence'
,p_event_sequence=>10
,p_condition_element=>'P80_CONVERSATION_ID'
,p_triggering_condition_type=>'NULL'
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(41154317865175227827)
,p_event_id=>wwv_flow_imp.id(41154317765415227826)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P80_CONVERSATION_ID IS NULL THEN',
'   :P80_CONVERSATION_ID := MANAGE_MESSAGES.get_or_create_conversation(:P80_PARTICIPANT_1_ID, :P80_PARTICIPANT_2_ID);',
'END IF;'))
,p_attribute_02=>'P80_PARTICIPANT_1_ID,P80_PARTICIPANT_2_ID'
,p_attribute_03=>'P80_CONVERSATION_ID'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(41154318228688227831)
,p_event_id=>wwv_flow_imp.id(41154317765415227826)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(40424820623949237329)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(40752773763494578926)
,p_name=>'Send Reply'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(40752771473755578903)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(40752773892064578927)
,p_event_id=>wwv_flow_imp.id(40752773763494578926)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'MANAGE_MESSAGES.send_message(',
'    :P80_PARTICIPANT_1_ID,',
'    :P80_PARTICIPANT_2_ID,',
'    to_number(:USER_ID),',
'    :P80_MESSAGE,',
'    :P80_CURRENT_DATE,',
'    :P80_SENDER_NAME',
');'))
,p_attribute_02=>'P80_PARTICIPANT_1_ID,P80_PARTICIPANT_2_ID,P80_MESSAGE'
,p_attribute_03=>'P80_CURRENT_DATE,P80_SENDER_NAME'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(40752774012700578929)
,p_event_id=>wwv_flow_imp.id(40752773763494578926)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'//apex.region("display-messages").refresh();',
'$("#display-messages_jqm_list_view")',
'    .append(`<li class="a-ListView-item ui-body-inherit own-message">',
'                <span class="message">${$v("P80_MESSAGE")}</span>',
'                <p class="ui-li-aside">${$v("P80_SENDER_NAME")} - ${$v("P80_CURRENT_DATE")}</p>',
'            </li>`);',
'',
'let $lastItem = $("#display-messages_jqm_list_view li:last")[0]; ',
'$lastItem.scrollIntoView({ behavior: "auto", block: "end", inline: "nearest" });',
'',
'apex.message.showPageSuccess( "Message sent successfully ! you will recieve a notification when the client responds" );'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(40752774508139578934)
,p_event_id=>wwv_flow_imp.id(40752773763494578926)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLEAR'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P80_MESSAGE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(40752771783573578906)
,p_name=>'Mark Messages as read'
,p_event_sequence=>30
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(40752771807692578907)
,p_event_id=>wwv_flow_imp.id(40752771783573578906)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P80_CONVERSATION_ID IS NOT NULL THEN',
'    UPDATE ',
'    messages ',
'    SET status = ''Read'' ',
'    WHERE conversation_id = :P80_CONVERSATION_ID ',
'    AND NOT message_sender_id = to_number(:USER_ID);',
'END IF;'))
,p_attribute_02=>'P80_CONVERSATION_ID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(41154318426150227833)
,p_name=>'Set messages style after refresh'
,p_event_sequence=>40
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(40424820623949237329)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterrefresh'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(41154318595474227834)
,p_event_id=>wwv_flow_imp.id(41154318426150227833)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if($("#display-messages_jqm_list_view").children().length > 0){',
'    console.log($("#display-messages_jqm_list_view").children(".a-ListView-item"));',
'       const listOfMessages =  Array.from($("#display-messages_jqm_list_view").children(".a-ListView-item"));',
'        console.log(listOfMessages);',
'        listOfMessages.forEach(message => {',
'            const sender_id = message.getAttribute(''data-id'');   ',
'            if(sender_id != current_user) message.classList.add("not-own-message");',
'            else message.classList.add("own-message")',
'        })',
'    }',
'',
'let $lastItem = $("#display-messages_jqm_list_view li:last")[0]; ',
'$lastItem.scrollIntoView({ behavior: "auto", block: "end", inline: "nearest" });'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(40752775357403578942)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Close'
,p_process_sql_clob=>':P80_MESSAGE := NULL;'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(40752774932430578938)
,p_internal_uid=>40752775357403578942
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(40752772378100578912)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Add Reply Message'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P80_MESSAGE IS NOT NULL THEN',
'    MANAGE_MESSAGES.send_message(',
'        :P80_PARTICIPANT_1_ID,',
'        :P80_PARTICIPANT_2_ID,',
'        to_number(:USER_ID),',
'        :P80_MESSAGE,',
'        :P80_CURRENT_DATE,',
'        :P80_SENDER_NAME',
'    );',
'END IF;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>40752772378100578912
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(40752773623601578925)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close '
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(40752774932430578938)
,p_internal_uid=>40752773623601578925
);
wwv_flow_imp.component_end;
end;
/
