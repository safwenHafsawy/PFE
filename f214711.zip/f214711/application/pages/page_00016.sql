prompt --application/pages/page_00016
begin
--   Manifest
--     PAGE: 00016
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>6662355588643785590
,p_default_application_id=>214711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_RSWSP'
);
wwv_flow_imp_page.create_page(
 p_id=>16
,p_name=>'Messages'
,p_alias=>'MESSAGES'
,p_step_title=>'Messages'
,p_autocomplete_on_off=>'OFF'
,p_css_file_urls=>'#APP_FILES#Styling/main_style#MIN#.css'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.page-title {',
'    text-align: center;',
'}',
'',
'.page-title > h2 {',
'    font-family: var(--secondary-header-font);',
'}',
'',
'.t-Report-colHead {',
'    border-bottom: 1px solid var(--first-color);',
'}',
'',
'.delete-prod {',
'    color: var(--danger-color);',
'}',
'',
'',
'#R40424819568200237318_filter_input {',
'    text-align: center;',
'    border-radius: 20px;',
'    font-family: var(--regular-text-font);',
'    font-size: medium;',
'}',
'',
'',
'#customer_messages-list_jqm_list_view {',
'    border-radius: 20px;',
'}',
'',
'#customer_messages-list_jqm_list_view  > li{',
'    border-radius: 20px;',
'    background-color: white !important;',
'}',
'',
'.conversation_header {',
'    font-family: var(--secondary-header-font);',
'    ',
'}',
'',
'.conversation_header > span {',
'    font-family: var(--regular-text-font);',
'    font-size: small;',
'    color: var(--grey-color);',
'}',
'',
'.conversation_content {',
'    font-family: var(--regular-text-font);',
'}',
'',
'#customer_messages-list_filter_input {',
'  text-align: center;',
'  border-radius: 20px;',
'  font-family: var(--regular-text-font);',
'  font-size: medium;',
'}',
'',
'#customer_messages-list_filter_input:focus {',
'    outline: none;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'11'
,p_last_updated_by=>'PFE94053@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20230801193834'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(82637865050301691861)
,p_plug_name=>'Messages List'
,p_region_name=>'customer_messages-list'
,p_region_css_classes=>'messages-list'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--textContent:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT',
'  c.conversation_id,',
'  CASE ',
'    WHEN c.participant_1_id = TO_NUMBER(:USER_ID) THEN c.participant_2_id',
'    WHEN c.participant_2_id = TO_NUMBER(:USER_ID) THEN c.participant_1_id',
'  END AS other_party,',
'  CASE ',
'    WHEN c.participant_1_id = TO_NUMBER(:USER_ID) THEN u2.firstname || '' '' || u2.lastname',
'    WHEN c.participant_2_id = TO_NUMBER(:USER_ID) THEN u1.firstname || '' '' || u1.lastname',
'  END AS sender_name,',
'  SUM(CASE WHEN m.status = ''Unread'' AND m.message_sender_id != TO_NUMBER(:USER_ID) THEN 1 ELSE 0 END) AS NEW_MESSAGES',
'FROM conversations c',
'LEFT JOIN messages m ON c.conversation_id = m.conversation_id',
'LEFT JOIN customer u1 ON c.participant_1_id = u1.customer_id',
'LEFT JOIN customer u2 ON c.participant_2_id = u2.customer_id',
'WHERE c.participant_1_id = TO_NUMBER(:USER_ID) OR c.participant_2_id = TO_NUMBER(:USER_ID)',
'GROUP BY',
'  c.conversation_id,',
'  c.participant_1_id,',
'  c.participant_2_id,',
'  CASE ',
'    WHEN c.participant_1_id = TO_NUMBER(:USER_ID) THEN u2.firstname || '' '' || u2.lastname',
'    WHEN c.participant_2_id = TO_NUMBER(:USER_ID) THEN u1.firstname || '' '' || u1.lastname',
'  END',
''))
,p_plug_source_type=>'NATIVE_JQM_LIST_VIEW'
,p_plug_query_num_rows=>20
,p_plug_query_no_data_found=>'No messages yet !'
,p_landmark_type=>'region'
,p_attribute_01=>'ADVANCED_FORMATTING:SEARCH:INSET'
,p_attribute_04=>'data-id=&MESSAGE_SENDER_ID.'
,p_attribute_05=>'<h4 class="conversation_header">&SENDER_NAME. - <span> &NEW_MESSAGES. new messages</span></h4>'
,p_attribute_16=>'f?p=&APP_ID.:80:&SESSION.::&DEBUG.:80:P80_CONVERSATION_ID,P80_PARTICIPANT_1_ID,P80_PARTICIPANT_2_ID:&CONVERSATION_ID.,&USER_ID.,&OTHER_PARTY.'
,p_attribute_18=>'SERVER_EXACT_IGNORE'
,p_attribute_20=>'search for sender...'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(92120224875517709700)
,p_plug_name=>'Page Title'
,p_region_template_options=>'#DEFAULT#:margin-top-lg:margin-bottom-lg'
,p_plug_template=>wwv_flow_imp.id(19471542261328504234)
,p_plug_display_sequence=>5
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="page-title">',
'    <span aria-hidden="true" class="fa fa-users-chat fa-3x"></span>',
'    <h2 > My Messages </h2>',
'</div>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(42153516905064704837)
,p_name=>'Refrehs List'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(82637865050301691861)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(42153517004697704838)
,p_event_id=>wwv_flow_imp.id(42153516905064704837)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(82637865050301691861)
);
wwv_flow_imp.component_end;
end;
/
