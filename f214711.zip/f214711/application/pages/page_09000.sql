prompt --application/pages/page_09000
begin
--   Manifest
--     PAGE: 09000
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>6662355588643785590
,p_default_application_id=>214711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_RSWSP'
);
wwv_flow_imp_page.create_page(
 p_id=>9000
,p_name=>'Contact Administration'
,p_alias=>'CONTACT-ADMINISTRATION'
,p_step_title=>'Contact Administration'
,p_autocomplete_on_off=>'OFF'
,p_css_file_urls=>'#APP_FILES#Styling/main_style#MIN#.css'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.left-side {',
'    height: 100%;',
'}',
'',
'',
'.container > h2, h1 {',
'    text-align: center;',
'    font-family: var(--secondary-header-font);',
'    color: var(--fouth-color);',
'}',
'',
'.container > p{',
'    font-family: var(--regular-text-font);',
'    color: var(--fouth-color);',
'}',
'',
'.container > ul {',
'    list-style: circle;',
'}',
'',
'.container > ul > li {',
'    font-family: var(--regular-text-font);',
'}',
'',
'.header-content > h2 {',
'    font-family: var(--secondary-header-font);',
'    text-align: center;',
'    color: var(--fouth-color);',
'}',
'',
'.header-content > p {',
'    font-family: var(--regular-text-font);',
'    color: var(--fouth-color);',
'    text-align: center;',
'}',
'',
'.display_only {',
'    background-color: var(--fouth-color);',
'    color: var(--first-color);',
'}'))
,p_step_template=>wwv_flow_imp.id(19471509145742504218)
,p_page_css_classes=>'contact-admin'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'16'
,p_last_updated_by=>'PFE94053@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20230722174749'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(42000158813329054339)
,p_plug_name=>'Explore'
,p_region_css_classes=>'left-side'
,p_region_template_options=>'#DEFAULT#:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_02'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(42000159061672054341)
,p_plug_name=>'Terms Of service'
,p_region_name=>'term-service-region'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>20
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'     <section id="terms-of-service">',
'            <div class="container">',
'                <h1>Terms of Service</h1>',
'                <p>Welcome to Happy Shopping!</p>',
'                <p>These Terms of Service ("Terms") govern your access to and use of our online marketplace platform, including any subdomains and related services (collectively, the "Platform"). By accessing or using the Platform, you agree to be bo'
||'und by these Terms. If you do not agree to these Terms, please refrain from using the Platform.</p>',
'',
'                <h2>1. Acceptable Use</h2>',
'                <p>1.1. You must be at least 15 years old to use the Platform. If you are accessing or using the Platform on behalf of a company or other legal entity, you represent and warrant that you have the authority to bind that entity to these'
||' Terms.</p>',
'                <p>1.2. You agree not to use the Platform for any illegal, unauthorized, or prohibited purposes. You shall not violate any applicable laws or regulations while using the Platform.</p>',
'                <p>1.3. You shall not engage in any activity that could harm, disable, overburden, or impair the Platform''s proper functioning or interfere with other users'' use of the Platform.</p>',
'',
'                <h2>2. User Accounts</h2>',
'                <p>2.1. To access certain features of the Platform, you may be required to create a user account. You are responsible for maintaining the confidentiality of your account credentials and for all activities that occur under your account'
||'.</p>',
'                <p>2.2. You agree to provide accurate and up-to-date information during the registration process. You must promptly notify us if there are any changes to this information.</p>',
'                <p>2.3. You are solely responsible for safeguarding your account and ensuring that unauthorized access to your account does not occur. You shall immediately notify us of any unauthorized use of your account or any other security breac'
||'hes.</p>',
'',
'                <h2>3. Store Creation and Product Listings</h2>',
'                <p>3.1. Happy Shopping allows users to create stores and list products for sale. By listing products on the Platform, you affirm that you have the right to sell those products, and you grant Happy Shopping a non-exclusive, worldwide, '
||'royalty-free, and transferable license to use, display, and distribute the content associated with your products.</p>',
'                <p>3.2. You are solely responsible for the accuracy and legality of the product listings, including any product descriptions, images, and prices. Happy Shopping reserves the right to remove any listings that violate our policies or ar'
||'e deemed inappropriate.</p>',
'                <p>3.3. You shall not list prohibited or restricted items on the Platform, as outlined in our Prohibited Items Policy.</p>',
'',
'                <h2>4. Prohibited Items</h2>',
'                <p>4.1. The following items are strictly prohibited from being listed or sold on Happy Shopping:</p>',
'                <ul>',
'                    <li>Illegal or illicit substances, drugs, or drug paraphernalia</li>',
'                    <li>Weapons, firearms, or ammunition</li>',
'                    <li>Stolen goods or items that promote illegal activities</li>',
'                    <li>Counterfeit or replica products</li>',
'                    <li>Adult content or explicit material</li>',
'                    <li>Hazardous materials or substances</li>',
'                    <li>Products infringing on intellectual property rights</li>',
'                    <li>Live animals or endangered species</li>',
'                    <li>Tobacco or related paraphernalia</li>',
'                    <li>Prescription drugs or medications</li>',
'                    <li>Alcohol or alcoholic beverages</li>',
'                    <li>Any items promoting hate speech, discrimination, or violence</li>',
'                    <li>Any items that violate applicable laws or regulations</li>',
'                </ul>',
'                <p>4.2. Happy Shopping reserves the right to remove any listings that contain prohibited items or content, and take appropriate actions against users who violate this policy, including termination of their accounts.</p>',
'',
'',
'            </div>',
'        </section>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(42000159960554054350)
,p_plug_name=>'Contact Us'
,p_region_name=>'contact-region'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>30
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(42000158041707054331)
,p_plug_name=>'Issue Form'
,p_parent_plug_id=>wwv_flow_imp.id(42000159960554054350)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ISSUE_RECORD_ID,',
'       ir.CUSTOMER_ID,',
'       c.firstname ,',
'       c.lastname,',
'       c.phone,',
'       c.email,',
'       TOPIC_ID,',
'       CONTENT',
'  from ISSUE_RECORDS ir, customer c',
'  where ir.CUSTOMER_ID = c.CUSTOMER_ID'))
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(42153514961230704817)
,p_plug_name=>'header'
,p_parent_plug_id=>wwv_flow_imp.id(42000159960554054350)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--textContent:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>10
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="header-content">',
'    <h2>We are happy to hear form you</h2>',
'    <p>We''re Here for You 24/7</p>',
'    <p>Got a question or need assistance? Our team is here to help!</p>',
'</div>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(42153514082023704808)
,p_plug_name=>'About Us'
,p_region_name=>'about-region'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>10
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'        <section id="about">',
'            <div class="container">',
'                <h1>About Us</h1>',
'                <p>Welcome to Happy Shopping, where entrepreneurial dreams take flight and creativity knows no bounds. We are more than just an online marketplace; we are a thriving community of passionate individuals who dare to turn their visions i'
||'nto reality.</p>',
'                <p>At the core of our mission is the belief that every business, regardless of size, has the potential to make a significant impact. As avid supporters of small businesses, we have made it our purpose to break down barriers and empowe'
||'r sellers to reach their full potential.</p>',
'                <p>What sets us apart is our commitment to curating a diverse and exceptional marketplace that showcases a wide array of products from artisans, craftsmen, and independent businesses worldwide. We take pride in promoting unique, one-o'
||'f-a-kind items that you won''t find in traditional retail stores.</p>',
'                <p>Our journey began with a vision to create a platform that fosters growth, nurtures innovation, and cultivates meaningful connections between sellers and buyers. We are continually driven by our passion for empowering entrepreneurs '
||'and connecting people through the love of creativity and craftsmanship.</p>',
'                <p>As you explore our marketplace, you''ll find an extensive range of products carefully crafted with love and dedication. From handcrafted jewelry to artistic home decor, from eco-friendly fashion to cutting-edge tech gadgets - there'''
||'s something for everyone at Happy Shopping.</p>',
'                <p>Our dedication to exceptional customer experiences extends beyond the platform itself. We take pride in our personalized support and attentive customer service. Whether you''re a seller navigating your store or a buyer seeking the p'
||'erfect item, our team is always here to assist you.</p>',
'                <p>At Happy Shopping, we envision a world where small businesses flourish, empowering individuals and communities worldwide. We are on a mission to inspire entrepreneurship, support artisans, and revolutionize the way people shop.</p>',
'                <p>Join us on this exciting journey of creativity, entrepreneurship, and community. Together, we can make a difference, one unique creation at a time.</p>',
'            </div>',
'        </section>',
'',
'        <!-- Mission Section -->',
'        <section id="mission">',
'            <div class="container">',
'                <h2>Our Mission</h2>',
'                <p>Our mission at Happy Shopping is to empower and support small business owners in realizing their dreams. We strive to:</p>',
'                <ul>',
'                    <li>Provide a platform that allows sellers to showcase their unique products to a global audience.</li>',
'                    <li>Offer a seamless and user-friendly experience for sellers to set up and manage their stores.</li>',
'                    <li>Promote diversity, sustainability, and social responsibility through our curated selection of products.</li>',
'                    <li>Create an environment that fosters creativity, innovation, and collaboration among sellers.</li>',
'                    <li>Deliver exceptional customer service and support to both sellers and buyers on our platform.</li>',
'                </ul>',
'                <p>At the heart of our mission lies the belief that by supporting small businesses, we contribute to stronger communities and a more sustainable future.</p>',
'            </div>',
'        </section>',
'',
'        <!-- Vision Section -->',
'        <section id="vision">',
'            <div class="container">',
'                <h2>Our Vision</h2>',
'                <p>Our vision at Happy Shopping is to be the global leader in empowering small businesses and artisans to thrive in the digital economy. We aim to:</p>',
'                <ul>',
'                    <li>Connect millions of sellers with buyers from all corners of the world, promoting cross-cultural exchange and appreciation.</li>',
'                    <li>Inspire the next generation of entrepreneurs to pursue their passions and create innovative, socially responsible businesses.</li>',
'                    <li>Curate a marketplace that celebrates craftsmanship, creativity, and the beauty of handmade products.</li>',
'                    <li>Be the go-to destination for customers seeking unique, high-quality items that tell a story.</li>',
'                    <li>Drive positive social impact by supporting local communities, fair trade practices, and eco-friendly initiatives.</li>',
'                </ul>',
'                <p>Our vision extends far beyond transactions; it is a journey of empowerment, discovery, and shared success.</p>',
'            </div>',
'        </section>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(42153513639712704804)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(42000158813329054339)
,p_button_name=>'About_us'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--simple:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(19471882000429504304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'About Us'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(42000158686532054337)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(42000159960554054350)
,p_button_name=>'Send'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--success:t-Button--iconLeft:t-Button--stretch:t-Button--gapTop'
,p_button_template_id=>wwv_flow_imp.id(19471882117602504304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Send'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-send'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(42000159493805054345)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(42000158813329054339)
,p_button_name=>'Term_of_service'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--simple:t-Button--stretch:t-Button--gapTop:t-Button--gapBottom'
,p_button_template_id=>wwv_flow_imp.id(19471882000429504304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Term Of Service'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(42153513551893704803)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(42000158813329054339)
,p_button_name=>'Contact_us'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--simple:t-Button--stretch:t-Button--gapTop:t-Button--gapBottom'
,p_button_template_id=>wwv_flow_imp.id(19471882000429504304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Contact Us'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(42000158236516054333)
,p_name=>'P9000_ISSUE_RECORD_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(42000158041707054331)
,p_item_source_plug_id=>wwv_flow_imp.id(42000158041707054331)
,p_source=>'ISSUE_RECORD_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(42000158362551054334)
,p_name=>'P9000_CUSTOMER_ID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(42000158041707054331)
,p_item_source_plug_id=>wwv_flow_imp.id(42000158041707054331)
,p_source=>'CUSTOMER_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(42000158458524054335)
,p_name=>'P9000_TOPIC_ID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(42000158041707054331)
,p_item_source_plug_id=>wwv_flow_imp.id(42000158041707054331)
,p_prompt=>'Issue Topic'
,p_source=>'TOPIC_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    topic, topic_id',
'FROM ',
'    issue_topics'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'-- Choose Issue Topic --'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(19471879586967504303)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(42000158535344054336)
,p_name=>'P9000_CONTENT'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(42000158041707054331)
,p_item_source_plug_id=>wwv_flow_imp.id(42000158041707054331)
,p_prompt=>'Type You meesage here'
,p_source=>'CONTENT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(19471879586967504303)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(42153514456272704812)
,p_name=>'P9000_FIRSTNAME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(42000158041707054331)
,p_item_source_plug_id=>wwv_flow_imp.id(42000158041707054331)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT firstname',
'FROM   customer',
'WHERE customer_id = to_number(:USER_ID)'))
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'<p style="color:#FBF9F8;opacity:0.5;">First Name</p>'
,p_source=>'FIRSTNAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_colspan=>6
,p_field_template=>wwv_flow_imp.id(19471879586967504303)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(42153514562190704813)
,p_name=>'P9000_LASTNAME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(42000158041707054331)
,p_item_source_plug_id=>wwv_flow_imp.id(42000158041707054331)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT lastname',
'FROM   customer',
'WHERE customer_id = to_number(:USER_ID)'))
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'<p style="color:#FBF9F8;opacity:0.5;">Last Name</p>'
,p_source=>'LASTNAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(19471879586967504303)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(42153514685296704814)
,p_name=>'P9000_PHONE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(42000158041707054331)
,p_item_source_plug_id=>wwv_flow_imp.id(42000158041707054331)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT phone',
'FROM   customer',
'WHERE customer_id = to_number(:USER_ID)'))
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'<p style="color:#FBF9F8;opacity:0.5;">Phone</p>'
,p_source=>'PHONE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(19471879586967504303)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(42153514724796704815)
,p_name=>'P9000_EMAIL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(42000158041707054331)
,p_item_source_plug_id=>wwv_flow_imp.id(42000158041707054331)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT email',
'FROM   customer',
'WHERE customer_id = to_number(:USER_ID)'))
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'<p style="color:#FBF9F8;opacity:0.5;">Email</p>'
,p_source=>'EMAIL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_colspan=>6
,p_field_template=>wwv_flow_imp.id(19471879586967504303)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(42153515133597704819)
,p_name=>'P9000_ISSUE_NUMBER'
,p_item_sequence=>40
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(42153515281833704820)
,p_validation_name=>'topic id validation'
,p_validation_sequence=>10
,p_validation=>'P9000_TOPIC_ID'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Must Choose a topic for you issue'
,p_associated_item=>wwv_flow_imp.id(42000158458524054335)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(42000157452861054325)
,p_name=>'Select Conversation'
,p_event_sequence=>50
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.ui-btn'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(42000157517101054326)
,p_event_id=>wwv_flow_imp.id(42000157452861054325)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P9000_CONV_ID'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'$(this.triggeringElement).parent().data("id")'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(42000159120453054342)
,p_name=>'Hide regions'
,p_event_sequence=>60
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(42000159223667054343)
,p_event_id=>wwv_flow_imp.id(42000159120453054342)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(42000159061672054341)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(42153513499298704802)
,p_event_id=>wwv_flow_imp.id(42000159120453054342)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(42000159960554054350)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(42000159527597054346)
,p_name=>'show term of service'
,p_event_sequence=>70
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(42000159493805054345)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(42000159616703054347)
,p_event_id=>wwv_flow_imp.id(42000159527597054346)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$("#about-region").hide(1000);',
'$("#contact-region").hide(1000);'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(42153513352423704801)
,p_event_id=>wwv_flow_imp.id(42000159527597054346)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$("#term-service-region").show(1000);'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(42153513713687704805)
,p_name=>'Show Contact us'
,p_event_sequence=>80
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(42153513551893704803)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(42153513970112704807)
,p_event_id=>wwv_flow_imp.id(42153513713687704805)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$("#term-service-region").hide(1000);',
'$("#about-region").hide(1000);'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(42153513884004704806)
,p_event_id=>wwv_flow_imp.id(42153513713687704805)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$("#contact-region").show(1000);'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(42153514146880704809)
,p_name=>'show about us'
,p_event_sequence=>90
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(42153513639712704804)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(42153514289265704810)
,p_event_id=>wwv_flow_imp.id(42153514146880704809)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$("#term-service-region").hide(1000);',
'$("#contact-region").hide(1000);'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(42153514352002704811)
,p_event_id=>wwv_flow_imp.id(42153514146880704809)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$("#about-region").show(1000);'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(42153515357550704821)
,p_name=>'Create new issue'
,p_event_sequence=>100
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(42000158686532054337)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(42153515410832704822)
,p_event_id=>wwv_flow_imp.id(42153515357550704821)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'MANAGE_MESSAGES.send_issue_to_admin(',
'    to_number(:USER_ID),',
'    :P9000_TOPIC_ID,',
'    :P9000_CONTENT,',
'    :P9000_ISSUE_NUMBER',
');'))
,p_attribute_02=>'P9000_TOPIC_ID,P9000_CONTENT'
,p_attribute_03=>'P9000_ISSUE_NUMBER'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(42153515695173704824)
,p_event_id=>wwv_flow_imp.id(42153515357550704821)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
' apex.message.showPageSuccess( "your issue has been submitted !" );',
''))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(42153515573191704823)
,p_event_id=>wwv_flow_imp.id(42153515357550704821)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLEAR'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P9000_TOPIC_ID,P9000_CONTENT'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(42153515035519704818)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Create new issue'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'MANAGE_MESSAGES.send_issue_to_admin(',
'    to_number(:USER_ID),',
'    :P9000_TOPIC_ID,',
'    :P9000_CONTENT,',
'    :P9000_ISSUE_NUMBER',
');'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>42153515035519704818
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(42000158144150054332)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(42000158041707054331)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Contact Administration'
,p_internal_uid=>42000158144150054332
);
wwv_flow_imp.component_end;
end;
/
