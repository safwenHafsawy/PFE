prompt --application/pages/page_00070
begin
--   Manifest
--     PAGE: 00070
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>6662355588643785590
,p_default_application_id=>214711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_RSWSP'
);
wwv_flow_imp_page.create_page(
 p_id=>70
,p_name=>'Seller Dashboard'
,p_alias=>'SELLER-DASHBOARD'
,p_step_title=>'Seller Dashboard'
,p_autocomplete_on_off=>'OFF'
,p_css_file_urls=>'#APP_FILES#Styling/main_style#MIN#.css'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.overall-summary-region-container {',
'    padding: 20px;',
'}',
'',
'.overall-summary-region-row{',
'    padding: 0 0 50px;',
'}',
'',
'.overall-summary-region {',
'    margin: 0 10px 10px 10px;',
'    min-height: 100%;',
'    box-shadow: -1px 33px 35px -13px rgba(207,193,193,0.59);',
'    -webkit-box-shadow: -1px 33px 35px -13px rgba(207,193,193,0.59);',
'    -moz-box-shadow: -1px 33px 35px -13px rgba(207,193,193,0.59);',
'    border-radius: 10px !important;',
'    transition: all 300ms;',
'}',
'',
'.overall-summary-region:hover {',
'    transform: scale(1.05);',
'    box-shadow: -1px 33px 35px -20px rgba(207,193,193,0.99);',
'    -webkit-box-shadow: -1px 33px 35px -20px rgba(207,193,193,0.99);',
'    -moz-box-shadow: -1px 33px 35px -20px rgba(207,193,193,0.99);',
'}',
'',
'.overview {',
'    border-left: 10px solid var(--fouth-color);',
'    border-radius: 10px;',
'    padding-left: 10px;',
'    text-align: center;',
'}',
'',
'',
'.overview-title {',
'    display: flex;',
'    align-items: center;',
'    color: var(--fouth-color);',
'    font-family: var(--secondary-header-font);',
'    border-bottom: 1px solid rgba(211, 211, 211, 0.5);',
'    padding: 2px;',
'}',
'',
'.overview-title > span {',
'    margin-right: 5px;',
'}',
'',
'.overview-data {',
'    font-family: var(--regular-text-font );',
'}',
'',
'.overview-data-prod > span {',
'    font-size: xx-small;',
'    opacity: 0.6;',
'}',
'',
'.overview-data-prod {',
'    font-family: var(--regular-text-font );',
'    display: flex;',
'    flex-direction: column;',
'}',
'',
'.recent-orders {',
'    font-family: var(--regular-text-font );',
'}',
'',
'.a-IRR-table tr:hover :not([Headers ~= C39275504417024429135]){',
'    background-color:var(--first-color);',
'    color: var(--fist-color) !important;',
'}',
'',
'[Headers ~= C39275504417024429135]{',
'    background-color: #3A3632;',
'    border-radius: 5px;',
'    text-align: center;',
'}',
'',
'[Headers ~= C39275504417024429135] a {',
'    color:white;',
'}'))
,p_step_template=>wwv_flow_imp.id(19471509145742504218)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'25'
,p_last_updated_by=>'PFE94053@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20230723112655'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38242826924679699946)
,p_plug_name=>'Seller Dashboard Navigation'
,p_region_css_classes=>'dashboard-side-menu'
,p_region_sub_css_classes=>'dashboard-side-menu-list'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-LinksList--showBadge:t-LinksList--showArrow:t-LinksList--nowrap:t-LinksList--actions:t-LinksList--showIcons'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_02'
,p_list_id=>wwv_flow_imp.id(38784043417088031374)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(19471863408174504294)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38793501474644233505)
,p_plug_name=>'Overall Summary'
,p_region_css_classes=>'overall-summary-region-container'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_08'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38793501650007233507)
,p_plug_name=>'Total customers'
,p_parent_plug_id=>wwv_flow_imp.id(38793501474644233505)
,p_region_css_classes=>'overall-summary-region'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>10
,p_plug_grid_row_css_classes=>'overall-summary-region-row'
,p_plug_grid_column_span=>3
,p_plug_display_column=>1
,p_plug_display_point=>'SUB_REGIONS'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    l_customer_count number;',
'begin',
'    select  count(DISTINCT o.customer_id)',
'    into    l_customer_count',
'    from    orders o, order_items oi, product p, stores s',
'    where   o.order_id = oi.order_id',
'    and     oi.product_id = p.product_id',
'    and     p.store_id = s.store_id',
'    and     s.customer_id = to_number(:USER_ID) ;',
'',
'    return ',
'        ''<div class="overview">',
'            <h3 class="overview-title"> <span aria-hidden="true" class="fa fa-users fa-2x"></span> Total Customers </h3>',
'            <h4 class="overview-data">'' || l_customer_count || '' Customer(s)',
'            </h4>',
'            </div> '';',
'end;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38793501782387233508)
,p_plug_name=>'Revenue'
,p_parent_plug_id=>wwv_flow_imp.id(38793501474644233505)
,p_region_css_classes=>'overall-summary-region'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>3
,p_plug_display_point=>'SUB_REGIONS'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    revenue number := 0;',
'begin',
'    select  NVL(sum(new_price(oi.product_id) * oi.quantity), 0)',
'    into    revenue',
'    from    orders o, order_items oi, product p, stores s',
'    where   o.order_status = ''Confirmed''',
'    and     o.order_id = oi.order_id',
'    and     oi.product_id = p.product_id',
'    and     p.store_id = s.store_id',
'    and     s.customer_id = to_number(:USER_ID) ;',
'    ',
'    return ',
'        ''<div class="overview">',
'            <h3 class="overview-title"> <span class="fa fa-money fa-2x" aria-hidden="true"></span> Total Revenue </h3>',
'            <h4 class="overview-data">'' || revenue || '' TND',
'            </h4>',
'            </div> '';',
'end;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38793501889145233509)
,p_plug_name=>'Total Orders'
,p_parent_plug_id=>wwv_flow_imp.id(38793501474644233505)
,p_region_css_classes=>'overall-summary-region'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>3
,p_plug_display_point=>'SUB_REGIONS'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    tot_orders number;',
'begin',
'    select  count(o.order_id)',
'    into    tot_orders',
'    from    orders o, order_items oi, product p, stores s',
'    where   o.order_id = oi.order_id',
'    and     oi.product_id = p.product_id',
'    and     p.store_id = s.store_id',
'    and     s.customer_id = to_number(:USER_ID) ;',
'',
'    return ',
'        '' <div class="overview">',
'        <h3 class="overview-title"><span class="fa fa-shopping-bag fa-2x" aria-hidden="true"></span> Total Orders</h3>',
'        <h4 class="overview-data">'' || tot_orders || '' Order(s)',
'        </h4>',
'        </div> '';',
'end;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(39275505071553429141)
,p_plug_name=>'Blockbuster Product'
,p_parent_plug_id=>wwv_flow_imp.id(38793501474644233505)
,p_region_css_classes=>'overall-summary-region'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>3
,p_plug_display_point=>'SUB_REGIONS'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    best_prod product.product_name%TYPE;',
'    store_org stores.store_name%TYPE;',
'    l_str_ret varchar2(1000);',
'BEGIN',
'    SELECT product_name, store_name',
'    INTO best_prod, store_org',
'    FROM (',
'        SELECT p.product_name,',
'               new_price(p.product_id) * oi.quantity AS price_quantity,',
'               s.store_name',
'        FROM order_items oi',
'        JOIN orders o ON oi.order_id = oi.order_id',
'        JOIN product p ON oi.product_id = p.product_id',
'        JOIN stores s ON p.store_id = s.store_id',
'        WHERE s.customer_id = TO_NUMBER(:USER_ID) AND order_status = ''Confirmed''',
'        ORDER BY price_quantity DESC',
'    )',
'    WHERE ROWNUM = 1;',
'    ',
'    l_str_ret := ''<div class="overview">',
'                    <h3 class="overview-title"><span aria-hidden="true" class="fa fa-package fa-2x"></span>Blockbuster Product</h3>',
'                    <h4 class="overview-data-prod">'' || best_prod || '' <span> from '' || store_org  || ''</span>',
'                    </h4>',
'                  </div>'';',
'',
'    RETURN l_str_ret;',
'EXCEPTION',
'    WHEN NO_DATA_FOUND THEN',
'        l_str_ret := ''<div class="overview">',
'                        <h3 class="overview-title"><span aria-hidden="true" class="fa fa-package fa-2x"></span>Blockbuster Product</h3>',
'                        <h4 class="overview-data-prod"> No product sold yet ! </h4>',
'                      </div>'';',
'',
'        RETURN l_str_ret;',
'END;',
''))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38793501922129233510)
,p_plug_name=>'Stats Summary'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>30
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(39275502402576429115)
,p_plug_name=>'Recent Orders '
,p_parent_plug_id=>wwv_flow_imp.id(38793501922129233510)
,p_region_css_classes=>'recent-orders'
,p_region_template_options=>'#DEFAULT#:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>30
,p_plug_grid_column_css_classes=>'recent-orders-col'
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    DISTINCT o.order_id AS "Order Number",',
'    to_char(o.order_datetime, ''DD-MON-YYYY'') AS "Date",',
'    o.order_status AS "ORDER STATUS",',
'    c.firstname || '' '' || c.lastname AS Customer,',
'    sum(new_price(oi.product_id) * oi.quantity) || '' TND'' AS "ORDER PRICE",',
'    ''Check Order''',
'FROM orders o',
'JOIN order_items oi ON o.order_id = oi.order_id',
'JOIN customer c ON o.customer_id = c.customer_id',
'JOIN product p ON oi.product_id = p.product_id',
'JOIN stores s ON p.store_id = s.store_id',
'WHERE s.customer_id = TO_NUMBER(:USER_ID)',
'GROUP BY o.order_id, to_char(o.order_datetime, ''DD-MON-YYYY''), order_status, c.firstname || '' '' || c.lastname',
'ORDER BY to_char(o.order_datetime, ''DD-MON-YYYY'') DESC'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Recent Orders '
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(39275503810522429129)
,p_max_row_count=>'5'
,p_no_data_found_message=>'No Orders Yet !'
,p_allow_report_saving=>'N'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_control_break=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_download=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'PFE94053@GMAIL.COM'
,p_internal_uid=>39275503810522429129
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39275503918104429130)
,p_db_column_name=>'Order Number'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Order Number'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39275504085878429131)
,p_db_column_name=>'Date'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Order Date'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD-MON-YYYY'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39275504184493429132)
,p_db_column_name=>'ORDER STATUS'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Order Status'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39275504255901429133)
,p_db_column_name=>'CUSTOMER'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Customer'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39275504300295429134)
,p_db_column_name=>'ORDER PRICE'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Order Price'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39275504417024429135)
,p_db_column_name=>'''CHECKORDER'''
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Check Order'
,p_column_link=>'f?p=&APP_ID.:73:&SESSION.::&DEBUG.:73::'
,p_column_linktext=>'<span class="fa fa-arrow-right-alt check-order" aria-hidden="true"></span>'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(39280125752411337354)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'392801258'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'Order Number:Date:ORDER STATUS:CUSTOMER:ORDER PRICE:''CHECKORDER'''
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(40358078263030470137)
,p_plug_name=>'Sales Overview'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(40358078385534470138)
,p_region_id=>wwv_flow_imp.id(40358078263030470137)
,p_chart_type=>'line'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>false
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'off'
,p_no_data_found_message=>'No sales yet !'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  function modifyOptions(options) {',
'    options.dataFilter = function(data) {',
'        for (var i = 0; i < data.series.length; i++) {',
'            for (var j = 0; j < data.series[i].items.length; j++) {',
'                    data.series[i].items[j].color = "#FFB929";',
'                    data.series[i].items[j].markerDisplayed = "on";',
'                    data.series[i].items[j].markerSize = 15;',
'            }',
'        }',
'',
'        return data;',
'    };',
'',
'    return options;',
'}'))
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(40358078498415470139)
,p_chart_id=>wwv_flow_imp.id(40358078385534470138)
,p_seq=>10
,p_name=>'Series 1'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    SUM(NEW_PRICE(oi.product_id) * oi.quantity) order_total,',
'    to_char(o.order_datetime, ''DD-MON-YYYY'') order_date',
'FROM orders o',
'LEFT JOIN order_items oi ON o.order_id = oi.order_id',
'LEFT JOIN product p ON oi.product_id = p.product_id',
'LEFT JOIN stores s ON p.store_id = s.store_id',
'WHERE s.customer_id = TO_NUMBER(:USER_ID)',
'GROUP BY to_char(o.order_datetime, ''DD-MON-YYYY'')',
'ORDER BY to_char(o.order_datetime, ''DD-MON-YYYY'');'))
,p_items_value_column_name=>'ORDER_TOTAL'
,p_items_label_column_name=>'ORDER_DATE'
,p_line_style=>'solid'
,p_line_type=>'auto'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(40358078567255470140)
,p_chart_id=>wwv_flow_imp.id(40358078385534470138)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(40358078635043470141)
,p_chart_id=>wwv_flow_imp.id(40358078385534470138)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(40358078738636470142)
,p_plug_name=>'Orders Overview'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>6
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(40358078860738470143)
,p_region_id=>wwv_flow_imp.id(40358078738636470142)
,p_chart_type=>'pie'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_value_format_type=>'decimal'
,p_value_decimal_places=>0
,p_value_format_scaling=>'none'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_legend_font_family=>'Courier New'
,p_legend_font_style=>'italic'
,p_legend_font_size=>'10'
,p_legend_font_color=>'#3a3632'
,p_pie_other_threshold=>0
,p_pie_selection_effect=>'highlight'
,p_no_data_found_message=>'No orders yet !'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function modifyOptions(options) {',
'	options.dataFilter = function (data) {',
'	  for (var i = 0; i < data.series.length; i++) {',
'		var dataName = data.series[i].name;',
'		if (dataName.startsWith("Pending")) {',
'		  data.series[i].color = "#3A3632";',
'		} else if (dataName.startsWith("Confirmed")) {',
'		  // Choose a different color for "Confirmed" series',
'		  data.series[i].color = "#FFB929";',
'		} else if (dataName.startsWith("Shipped")) {',
'		  data.series[i].color = "#497620";',
'		} else if (dataName.startsWith("Cancelled")) {',
'		  data.series[i].color = "#C33522";',
'		}',
'	  }',
'  ',
'	  return data;',
'	};',
'  ',
'	return options;',
'  }',
''))
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(40358078950370470144)
,p_chart_id=>wwv_flow_imp.id(40358078860738470143)
,p_seq=>10
,p_name=>'Series 1'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT count(DISTINCT o.order_id), o.order_status ',
'FROM orders o',
'LEFT JOIN order_items oi ON o.order_id = oi.order_id',
'LEFT  JOIN product p ON oi.product_id = p.product_id',
'LEFT JOIN stores s ON p.store_id = s.store_id',
'WHERE s.customer_id = TO_NUMBER(:USER_ID)',
'GROUP BY  o.order_status;'))
,p_items_value_column_name=>'COUNT(DISTINCTO.ORDER_ID)'
,p_items_label_column_name=>'ORDER_STATUS'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_items_label_display_as=>'LABEL'
);
wwv_flow_imp.component_end;
end;
/
