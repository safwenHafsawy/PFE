prompt --application/pages/page_00026
begin
--   Manifest
--     PAGE: 00026
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>6662355588643785590
,p_default_application_id=>214711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_RSWSP'
);
wwv_flow_imp_page.create_page(
 p_id=>26
,p_name=>'Order Information'
,p_alias=>'ORDER-INFORMATION'
,p_step_title=>'Order Information'
,p_autocomplete_on_off=>'OFF'
,p_css_file_urls=>'#APP_FILES#Styling/main_style#MIN#.css'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-ContentBlock-headerItems {',
'    display: flex;',
'    justify-content: center;',
'    align-items: center;',
'   ',
'}',
'',
'.t-ContentBlock-title {',
' font-family: var(--secondary-header-font);',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'23'
,p_last_updated_by=>'PFE94053@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20230818202848'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15433327325021828804)
,p_plug_name=>'Thank you for your Order '
,p_region_css_classes=>'block'
,p_icon_css_classes=>'fa-heart'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--showIcon:t-ContentBlock--h1:margin-top-md'
,p_plug_template=>wwv_flow_imp.id(19471570935354504247)
,p_plug_display_sequence=>10
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15433327583219828806)
,p_plug_name=>'Order Number: &P26_ORDER_ID.'
,p_parent_plug_id=>wwv_flow_imp.id(15433327325021828804)
,p_region_template_options=>'#DEFAULT#:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15433327603399828807)
,p_plug_name=>'Order Details'
,p_parent_plug_id=>wwv_flow_imp.id(15433327583219828806)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(19471549395551504237)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT o.order_id,',
'    o.order_datetime,',
'    o.customer_id,',
'    o.order_status,',
'    (SELECT Sum(unit_price * quantity) || '' TND''',
'        FROM   order_items i',
'        WHERE  i.order_id = o.order_id)  as "TOTAL"',
'FROM   orders o',
'WHERE  order_id = :P26_ORDER_ID'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(15433327762699828808)
,p_region_id=>wwv_flow_imp.id(15433327603399828807)
,p_layout_type=>'ROW'
,p_title_adv_formatting=>false
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>true
,p_second_body_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<b> Order Placed:</b> &ORDER_DATETIME. <br>',
'<b> Status: </b>&ORDER_STATUS. <br>',
'<b> Total Price: </b>&TOTAL.'))
,p_media_adv_formatting=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15433327826351828809)
,p_plug_name=>'Items'
,p_parent_plug_id=>wwv_flow_imp.id(15433327583219828806)
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--styleB'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(19471549395551504237)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT  o.line_item_id                Item,',
'        p.product_name                Product,',
'        o.unit_price,',
'        o.quantity,',
'        ( o.unit_price * o.quantity ) Subtotal,',
'        pi.image',
'FROM   order_items o,',
'    product p',
'    join (SELECT image_id,',
'            product_id,',
'            image',
'            FROM(SELECT image_id,',
'                        product_id,',
'                        image,',
'                        Row_number()',
'                            over (',
'                            PARTITION BY product_id',
'                            ORDER BY image_id) AS rn',
'                FROM   product_images) img',
'                WHERE  rn = 1) pi',
'        ON p.product_id = pi.product_id',
'WHERE  p.product_id = o.product_id',
'AND  order_id = :P26_ORDER_ID'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(15433327963973828810)
,p_region_id=>wwv_flow_imp.id(15433327826351828809)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>false
,p_title_column_name=>'PRODUCT'
,p_sub_title_adv_formatting=>true
,p_sub_title_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<b>Quantity: </b> &QUANTITY. <br>',
'<b>Unit Price: </b>&UNIT_PRICE.'))
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_media_adv_formatting=>false
,p_media_source_type=>'BLOB'
,p_media_blob_column_name=>'IMAGE'
,p_media_display_position=>'BODY'
,p_media_appearance=>'WIDESCREEN'
,p_media_sizing=>'FIT'
,p_pk1_column_name=>'ITEM'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(15433327437011828805)
,p_name=>'P26_ORDER_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(15433327325021828804)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp.component_end;
end;
/
