prompt --application/pages/page_08001
begin
--   Manifest
--     PAGE: 08001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>6662355588643785590
,p_default_application_id=>214711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_RSWSP'
);
wwv_flow_imp_page.create_page(
 p_id=>8001
,p_name=>'reset password'
,p_alias=>'RESET-PASSWORD'
,p_step_title=>'reset password'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*.t-Region-title{',
'    border-bottom: 1px solid  #D3D3D3',
'}*/',
'',
''))
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'16'
,p_last_updated_by=>'PFE94053@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20230719223150'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(37171147071769069226)
,p_plug_name=>'Enter your Email to Reset Password'
,p_region_template_options=>'#DEFAULT#:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>10
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(37171146875982069224)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(37171147071769069226)
,p_button_name=>'Submit'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--gapRight'
,p_button_template_id=>wwv_flow_imp.id(19471882000429504304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Submit'
,p_button_position=>'CHANGE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37171146935260069225)
,p_name=>'P8001_EMAIL'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(37171147071769069226)
,p_prompt=>'Email'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_colspan=>7
,p_field_template=>wwv_flow_imp.id(19471879586967504303)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37171147875910069234)
,p_name=>'P8001_LINK'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(37171147071769069226)
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(37171148449448069240)
,p_validation_name=>'validate_email'
,p_validation_sequence=>10
,p_validation=>'VALIDATIONS.validate_email(:P8001_EMAIL)'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'enter a valid email'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(37171148308546069239)
,p_validation_name=>'check_customer_existance'
,p_validation_sequence=>20
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_email NUMBER;',
'BEGIN',
'    SELECT COUNT(*) INTO v_email FROM customer c WHERE c.email = :P8001_EMAIL; ',
'',
'    IF v_email = 0 THEN ',
'        RETURN FALSE;',
'    ELSE',
'        RETURN TRUE;',
'    END IF; ',
'END;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_BOOLEAN'
,p_error_message=>'this customer does not exist check your email '
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(37171147989147069235)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Generate Link'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  DECLARE',
'    LV_LINK VARCHAR2(4000);',
'  BEGIN',
'    LV_LINK := APEX_PAGE.GET_URL(',
'                                P_APPLICATION => :APP_ID,',
'                                P_PAGE        => 8002,',
'                                P_SESSION     => NULL,',
'                                P_ITEMS       => ''P8002_USER_EMAIL'',',
'                                P_VALUES      => :P8001_EMAIL',
'                                );',
'      :P8001_LINK := '' https://apex.oracle.com'' || LV_LINK; ',
'      ',
'                              ',
'',
'  EXCEPTION',
'    WHEN OTHERS THEN NULL;',
'  END;',
'',
'',
''))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'error generating this link'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'P8001_EMAIL'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
,p_process_success_message=>'link generated'
,p_internal_uid=>37171147989147069235
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(37171148085917069236)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SEND_EMAIL'
,p_process_name=>'Send Email'
,p_attribute_01=>'&APP_EMAIL.'
,p_attribute_02=>'&P8001_EMAIL.'
,p_attribute_06=>'Reset Password'
,p_attribute_07=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  Please follow the below link to reset your Password:',
'  &P8001_LINK.',
'',
'',
'',
'',
'  '))
,p_attribute_10=>'Y'
,p_process_error_message=>'error occured sending this email'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(37171146875982069224)
,p_process_when=>'P8001_EMAIL'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
,p_process_success_message=>'email sent '
,p_internal_uid=>37171148085917069236
);
wwv_flow_imp.component_end;
end;
/
