prompt --application/pages/page_00031
begin
--   Manifest
--     PAGE: 00031
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>6662355588643785590
,p_default_application_id=>214711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_RSWSP'
);
wwv_flow_imp_page.create_page(
 p_id=>31
,p_name=>'Wishlist'
,p_alias=>'WHISHLIST'
,p_step_title=>'Whishlist'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Report-cell > img{',
'    width: 100px;',
'    height: auto;',
'    object-fit: contain;',
'}',
'.linketree{',
'    background-color: aqua;',
'}',
'',
''))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'03'
,p_last_updated_by=>'PFE94053@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20230709203344'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(31837227657136129531)
,p_name=>'Wishlist'
,p_template=>wwv_flow_imp.id(19471808805460504264)
,p_display_sequence=>10
,p_region_css_classes=>'report'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hideHeader:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--staticRowColors:t-Report--rowHighlight:t-Report--inline:t-Report--hideNoPagination'
,p_grid_column_css_classes=>'report-col'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT   B.PRODUCT_ID,PRODUCT_NAME, UNIT_PRICE, SYS.DBMS_LOB.GETLENGTH(IMAGE) IMAGE, ',
'        GET_STOCK (C.PRODUCT_ID) STOCK, ''Delete'' Del , ''Add to Cart'' ',
'FROM WISHLIST B, PRODUCT C, PRODUCT_IMAGES D ',
' WHERE  C.PRODUCT_ID = D.PRODUCT_ID',
'    AND  C.PRODUCT_ID = B.PRODUCT_ID',
'    AND B.CUSTOMER_ID = to_number(:USER_ID)',
'',
'',
'',
'',
'',
'',
'',
'',
' ',
'  ',
''))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(19471847069031504283)
,p_query_num_rows=>50
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_prn_output=>'N'
,p_prn_format=>'PDF'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(31837229197887129635)
,p_query_column_id=>1
,p_column_alias=>'PRODUCT_ID'
,p_column_display_sequence=>30
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(31844238522379335608)
,p_query_column_id=>2
,p_column_alias=>'PRODUCT_NAME'
,p_column_display_sequence=>50
,p_column_heading=>'Product Name'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:18:&SESSION.::&DEBUG.:18:P18_PRODUCT_ID:#PRODUCT_ID#'
,p_column_linktext=>'#PRODUCT_NAME#'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(31844238621361335609)
,p_query_column_id=>3
,p_column_alias=>'UNIT_PRICE'
,p_column_display_sequence=>60
,p_column_heading=>'Unit Price'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(31844238434785335607)
,p_query_column_id=>4
,p_column_alias=>'IMAGE'
,p_column_display_sequence=>40
,p_column_heading=>'Image'
,p_use_as_row_header=>'Y'
,p_column_format=>'IMAGE:PRODUCT_IMAGES:IMAGE:PRODUCT_ID::IMAGE_MIME_TYPE:IMAGE_FILENAME:IMAGE_LAST_UPDATED::::'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_report_column_width=>5
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(31844239073099335613)
,p_query_column_id=>5
,p_column_alias=>'STOCK'
,p_column_display_sequence=>70
,p_column_heading=>'Stock'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(31844239410059335617)
,p_query_column_id=>6
,p_column_alias=>'DEL'
,p_column_display_sequence=>10
,p_column_heading=>'Delete'
,p_use_as_row_header=>'N'
,p_column_link=>'javascript:void(null)'
,p_column_linktext=>'<span class="t-Icon fa fa-trash delete-prod" aria-hidden="true"></span>'
,p_column_link_attr=>'data-id=#PRODUCT_ID#'
,p_column_alignment=>'CENTER'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(31844240429989335627)
,p_query_column_id=>7
,p_column_alias=>'''ADDTOCART'''
,p_column_display_sequence=>80
,p_column_heading=>'Add To Cart'
,p_use_as_row_header=>'N'
,p_column_css_class=>'linketree'
,p_column_link=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:6:P6_PRODUCT_ID,P6_QUNATITY:#PRODUCT_ID#,1'
,p_column_linktext=>'Add to Cart'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(31844239912590335622)
,p_name=>'P31_PRODUCT_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(31837227657136129531)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(31844239542182335618)
,p_name=>'DA_DELETEROW'
,p_event_sequence=>10
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.delete-prod'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(31844239649572335619)
,p_event_id=>wwv_flow_imp.id(31844239542182335618)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P31_PRODUCT_ID'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(this.triggeringElement).parent().data(''id'');',
''))
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(31844239755413335620)
,p_event_id=>wwv_flow_imp.id(31844239542182335618)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Delete ',
'from wishlist ',
'where product_id = :P31_PRODUCT_ID ',
'    and customer_id = to_number(:USER_ID);'))
,p_attribute_02=>'P31_PRODUCT_ID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(31844239857692335621)
,p_event_id=>wwv_flow_imp.id(31844239542182335618)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(31837227657136129531)
);
wwv_flow_imp.component_end;
end;
/
