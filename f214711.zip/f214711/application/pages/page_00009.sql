prompt --application/pages/page_00009
begin
--   Manifest
--     PAGE: 00009
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>6662355588643785590
,p_default_application_id=>214711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_RSWSP'
);
wwv_flow_imp_page.create_page(
 p_id=>9
,p_name=>'Order Details'
,p_alias=>'ORDER-DETAILS'
,p_page_mode=>'MODAL'
,p_step_title=>'Order Details'
,p_autocomplete_on_off=>'OFF'
,p_css_file_urls=>'#APP_FILES#Styling/main_style#MIN#.css'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.status-col {',
'    display: flex;',
'    justify-content: center;',
'}',
'',
'.status {',
'    background-color: var(--fouth-color);',
'    border-radius: 10px;',
'    color: var(--first-color);',
'    font-family: var(--regular-text-font);',
'    width: 50%;',
'    text-align: center;',
'}',
'',
'',
'.side-card {',
'    width: fit-content !important;',
'    border: 2px solid var(--first-color);',
'    box-shadow: 0 1px 1px var(--third-color);',
'    border-radius: 10px;',
'    transition: all 0.3s ease;',
'}',
'',
'',
'.side-card:hover {',
'    transform: translateY(-5px);',
'}',
'',
'.side-card-title {',
'    padding: 10px;',
'    font-family: var(--secondary-header-font);',
'}',
'',
'.side-card-subtitle {',
'    font-family: var(--regular-text-font);',
'}',
'.side-card-subtitle > span {',
'    font-weight: bold;',
'}',
'',
'.side-card-body {',
'    font-family: var(--regular-text-font);',
'}',
'',
'.side-card-img {',
'    background-color: var(--second-color);',
'}',
'',
'.side-card-body > span {',
'    font-weight: bold;',
'}',
''))
,p_page_template_options=>'#DEFAULT#'
,p_dialog_width=>'1200'
,p_protection_level=>'C'
,p_page_component_map=>'23'
,p_last_updated_by=>'PFE94053@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20230818112041'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(31844241052466335633)
,p_plug_name=>'Products In Order'
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--styleA'
,p_plug_template=>wwv_flow_imp.id(19471549395551504237)
,p_plug_display_sequence=>30
,p_query_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    IF :P9_ORDER_STATUS = ''Cancelled'' THEN ',
'        return q''~',
'        SELECT',
'            i.ORDER_ID,',
'            i.LINE_ITEM_ID,',
'            i.PRODUCT_ID,',
'            i.UNIT_PRICE,',
'            i.QUANTITY,',
'            i.stock_id,',
'            p.product_name,',
'            i.item_status,',
'            pr.image',
'        FROM',
'            ORDER_ITEMS i',
'        JOIN',
'            product p ON i.product_id = p.product_id',
'        JOIN',
'            (',
'                SELECT',
'                    pi.product_id,',
'                    pi.image',
'                FROM',
'                    (',
'                        SELECT',
'                            product_id,',
'                            image,',
'                            ROW_NUMBER() OVER (PARTITION BY product_id ORDER BY image_id) AS rn',
'                        FROM',
'                            product_images',
'                    ) pi',
'                WHERE',
'                    pi.rn = 1',
'            ) pr ON p.product_id = pr.product_id',
'        WHERE',
'            i.order_id = :P9_ORDER_ID',
'        ~'';',
'    ELSE ',
'        return q''~',
'        SELECT',
'            i.ORDER_ID,',
'            i.LINE_ITEM_ID,',
'            i.PRODUCT_ID,',
'            i.UNIT_PRICE,',
'            i.QUANTITY,',
'            i.stock_id,',
'            p.product_name,',
'            i.item_status,',
'            pr.image',
'        FROM',
'            ORDER_ITEMS i',
'        JOIN',
'            product p ON i.product_id = p.product_id',
'        JOIN',
'            (',
'                SELECT',
'                    pi.product_id,',
'                    pi.image',
'                FROM',
'                    (',
'                        SELECT',
'                            product_id,',
'                            image,',
'                            ROW_NUMBER() OVER (PARTITION BY product_id ORDER BY image_id) AS rn',
'                        FROM',
'                            product_images',
'                    ) pi',
'                WHERE',
'                    pi.rn = 1',
'            ) pr ON p.product_id = pr.product_id',
'        WHERE',
'            i.order_id = :P9_ORDER_ID',
'            AND (UPPER(i.is_replaced) = ''NO'' OR i.is_replaced IS NULL);',
'',
'',
'        ~'';',
'    END IF;',
'END;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_ajax_items_to_submit=>'P9_ORDER_ID,P9_ORDER_STATUS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(50516533085272306425)
,p_region_id=>wwv_flow_imp.id(31844241052466335633)
,p_layout_type=>'ROW'
,p_card_css_classes=>'side-card'
,p_title_adv_formatting=>true
,p_title_html_expr=>'<h4 class="side-card-title">&QUANTITY. &PRODUCT_NAME.</h4>'
,p_sub_title_adv_formatting=>true
,p_sub_title_html_expr=>'<p class="side-card-subtitle">Item Status : <span> &ITEM_STATUS. </span></p>'
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_icon_source_type=>'BLOB'
,p_icon_blob_column_name=>'IMAGE'
,p_icon_position=>'START'
,p_media_adv_formatting=>false
,p_pk1_column_name=>'LINE_ITEM_ID'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(50516535287440306447)
,p_card_id=>wwv_flow_imp.id(50516533085272306425)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>10
,p_label=>'Replace Product'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:20:&SESSION.::&DEBUG.:20:P20_CANCELLED_PRODUCT_ID,P20_CANCELLED_PRODUCT_NAME,P20_CANCELLED_PRODUCT_STOCK,P20_ORDER_ID:&PRODUCT_ID.,&PRODUCT_NAME.,&STOCK_ID.,&ORDER_ID.'
,p_button_display_type=>'TEXT_WITH_ICON'
,p_icon_css_classes=>'fa-exchange'
,p_is_hot=>true
,p_condition_type=>'FUNCTION_BODY'
,p_condition_expr1=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_currnet_decision VARCHAR2(250 CHAR);',
'    l_current_status VARCHAR2(250 CHAR);',
'BEGIN',
'    SELECT order_status, customer_decision',
'    INTO l_current_status, l_currnet_decision',
'    FROM orders',
'    WHERE order_id = :P9_ORDER_ID;',
'',
'    IF l_current_status = ''Partially Declined'' AND l_currnet_decision = ''On Hold''  AND :ITEM_STATUS = ''Cancelled'' THEN ',
'        RETURN TRUE;',
'    ELSE ',
'        RETURN FALSE;',
'    END IF;',
'END;'))
,p_condition_expr2=>'PLSQL'
,p_exec_cond_for_each_row=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(50516533503328306430)
,p_plug_name=>'Buyer Actions'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>40
,p_plug_display_condition_type=>'FUNCTION_BODY'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_currnet_decision VARCHAR2(250 CHAR);',
'    l_current_status VARCHAR2(250 CHAR);',
'BEGIN',
'    SELECT order_status, customer_decision',
'    INTO l_current_status, l_currnet_decision',
'    FROM orders',
'    WHERE order_id = :P9_ORDER_ID;',
'',
'    IF l_current_status = ''Partially Declined'' AND l_currnet_decision = ''On Hold'' THEN ',
'        RETURN TRUE;',
'    ELSE ',
'        RETURN FALSE;',
'    END IF;',
'END;'))
,p_plug_display_when_cond2=>'PLSQL'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(50516533698049306431)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(50516533503328306430)
,p_button_name=>'Continue_With_Order'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--success'
,p_button_template_id=>wwv_flow_imp.id(19471882000429504304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Continue With Order'
,p_button_position=>'CHANGE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(31844241231386335635)
,p_name=>'P9_ORDER_ID'
,p_item_sequence=>10
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(50516532933516306424)
,p_name=>'P9_ORDER_STATUS'
,p_item_sequence=>20
,p_prompt=>'Order Status'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_grid_row_css_classes=>'status-row'
,p_grid_column_css_classes=>'status-col'
,p_field_template=>wwv_flow_imp.id(19471879237081504302)
,p_item_css_classes=>'status'
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:margin-bottom-lg'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(50516533307028306428)
,p_name=>'Set Colors'
,p_event_sequence=>10
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(50516533459233306429)
,p_event_id=>wwv_flow_imp.id(50516533307028306428)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(".status:contains(Pending)").css({',
'                "background-color": "#FFB929",',
'                "color": "#3A3632", ',
'                "border" : "1px solid #3A3632"',
'            });',
'',
'$(".status:contains(Cancelled)").css({',
'                "background-color": "#C33522",',
'                "color": "#FBF9F8", ',
'                "border" : "1px solid #3A3632"',
'            });',
'',
'$(".status:contains(Partially Declined)").css({',
'                "background-color": "#E17726",',
'                "color": "#3A3632", ',
'                "border" : "1px solid #3A3632"',
'            });',
'',
'$(".status:contains(Confirmed)").css({',
'                "background-color": "#497620",',
'                "color": "#FBF9F8", ',
'                "border" : "1px solid #3A3632"',
'            });',
'',
'$(".side-card-subtitle > span").each(function(index, element) {',
'    switch ($(this).text().trim()) {',
'        case ''Cancelled'' : ',
'            $(this).css({',
'                "background-color": "#C33522",',
'                "color": "white", ',
'                "padding" : "7px",',
'                "border-radius" : "25px"',
'            });',
'            break;',
'        case ''Confirmed'' :',
'            $(this).css({',
'                "background-color": "#497620",',
'                "color": "white", ',
'                "padding" : "7px",',
'                "border-radius" : "25px"',
'            });',
'            break;',
'        default :',
'            $(this).css({',
'                "background-color": "#FFB929",',
'                "color": "white", ',
'                "padding" : "7px",',
'                "border-radius" : "25px"',
'            });',
'            break;',
'    }',
'});',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(52184850413343530136)
,p_name=>'Change Order Items and Order mutation status'
,p_event_sequence=>20
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(52184850537548530137)
,p_event_id=>wwv_flow_imp.id(52184850413343530136)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_current_id NUMBER;',
'    l_current_status VARCHAR2(100 CHAR);',
'',
'    CURSOR c1 IS',
'        SELECT line_item_id , item_status',
'        FROM order_items',
'        WHERE order_id = :P9_ORDER_ID;',
'BEGIN',
'    OPEN c1;',
'    LOOP',
'        FETCH c1 INTO l_current_id,l_current_status;',
'        EXIT WHEN c1%NOTFOUND;',
'',
'        UPDATE order_items',
'        SET last_status = l_current_status',
'        WHERE line_item_id = l_current_id;',
'',
'    END LOOP;',
'    CLOSE c1;',
'',
'    UPDATE orders',
'    SET mutated_items = ''No''',
'    WHERE order_id = :P9_ORDER_ID;',
'',
'    :P0_ORDER_CHANGE := :P0_ORDER_CHANGE - 0;',
'END;',
''))
,p_attribute_02=>'P9_ORDER_ID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(50516534266384306437)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Remove Cancelled Products Form Order'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    MANAGE_ORDERS.update_customer_decision (',
'        :P9_ORDER_ID',
'    );',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(50516533698049306431)
,p_internal_uid=>50516534266384306437
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(50516534369453306438)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>50516534369453306438
);
wwv_flow_imp.component_end;
end;
/
