prompt --application/pages/page_00009
begin
--   Manifest
--     PAGE: 00009
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>6662355588643785590
,p_default_application_id=>214711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_RSWSP'
);
wwv_flow_imp_page.create_page(
 p_id=>9
,p_name=>'Order Details'
,p_alias=>'ORDER-DETAILS'
,p_page_mode=>'MODAL'
,p_step_title=>'Order Details'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'23'
,p_last_updated_by=>'PFE94053@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20230629003712'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(31844241052466335633)
,p_plug_name=>'products'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(19471549395551504237)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ORDER_ID,',
'       LINE_ITEM_ID,',
'       i.PRODUCT_ID,',
'       i.UNIT_PRICE,',
'       QUANTITY,',
'       product_name,',
'       image ',
'  from ORDER_ITEMS i , product p , product_images pr',
'  where i.product_id = p.product_id',
' and  I.order_id = :P9_ORDER_ID',
' and p.product_id = pr.product_id'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(31844241147595335634)
,p_region_id=>wwv_flow_imp.id(31844241052466335633)
,p_layout_type=>'ROW'
,p_title_adv_formatting=>false
,p_title_column_name=>'PRODUCT_NAME'
,p_sub_title_adv_formatting=>false
,p_sub_title_column_name=>'UNIT_PRICE'
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>true
,p_second_body_html_expr=>'<p> Quantity: &QUANTITY. </p>'
,p_media_adv_formatting=>false
,p_media_source_type=>'BLOB'
,p_media_blob_column_name=>'IMAGE'
,p_media_display_position=>'FIRST'
,p_media_sizing=>'FIT'
,p_pk1_column_name=>'PRODUCT_ID'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(31844241231386335635)
,p_name=>'P9_ORDER_ID'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp.component_end;
end;
/
