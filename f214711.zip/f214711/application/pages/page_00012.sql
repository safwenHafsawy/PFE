prompt --application/pages/page_00012
begin
--   Manifest
--     PAGE: 00012
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>6662355588643785590
,p_default_application_id=>214711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_RSWSP'
);
wwv_flow_imp_page.create_page(
 p_id=>12
,p_name=>'Add Product Specifications'
,p_alias=>'ADD-PRODUCT-SPECIFICATIONS'
,p_page_mode=>'MODAL'
,p_step_title=>'Add Product Specifications'
,p_autocomplete_on_off=>'OFF'
,p_css_file_urls=>'#APP_FILES#Styling/main_style#MIN#.css'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Region-title {',
'    font-family: var(--secondary-header-font);',
'    text-align: center;',
'    color: var(--fourth-color);',
'}',
'',
'.variant-select {',
'    font-family: var(--regular-text-font);',
'}',
'',
'.available-stock {',
'    font-family: var(--secondary-header-font);',
'}',
'',
'.prod-qunatity {',
'  width: 100%;',
'  height: 50px;',
'  display: flex;',
'  justify-content: center;',
'  align-items: center;',
'  border-style: solid;',
'  border-color: var(--fourth-color);',
'  border-width: 1px;',
'  border-radius: 5px;',
'  font-family: var(--regular-text-font);',
'}',
'',
'.quantity-btn {',
'  height: 50px;',
'  width: 100%;',
'  border-style: solid;',
'  border-color: var(--fourth-color);',
'  border-radius: 0;',
'}',
'',
'#increment_quantity {',
'  border-width: 1px;',
'  border-radius: 5px;',
'  transition: all 200ms;',
'}',
'',
'#increment_quantity:hover {',
'    color: var(--first-color);',
'    background-color: #3A3632;',
'    border: 1px solid var(--first-color); ',
'    transform: translateY(-1px);  ',
'}',
'',
'#decrement_quantity {',
'  border-width: 1px;',
'  border-radius: 5px;',
'}',
'',
'#decrement_quantity:hover {',
'    color: var(--first-color);',
'    background-color: #3A3632;',
'    border: 1px solid var(--first-color); \transform: translateY(-1px);   ',
'}',
'',
'.action-btn {',
'    font-family: var(--secondary-header-font);',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'16'
,p_last_updated_by=>'PFE94053@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20230817224026'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(37730490389950642748)
,p_plug_name=>'Select Product Variants'
,p_region_template_options=>'#DEFAULT#:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>120
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38242824233266699919)
,p_plug_name=>'Actions'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(66311371068282072357)
,p_plug_name=>'Choose Quantity'
,p_region_css_classes=>'qunatity-container'
,p_region_template_options=>'#DEFAULT#:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>130
,p_plug_grid_column_span=>6
,p_plug_display_column=>4
,p_attribute_01=>'Y'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38265237261510076443)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(66311371068282072357)
,p_button_name=>'Decrement_quantity'
,p_button_static_id=>'decrement_quantity'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--hoverIconPush'
,p_button_template_id=>wwv_flow_imp.id(19471881378436504304)
,p_button_image_alt=>'Decrement Quantity'
,p_warn_on_unsaved_changes=>null
,p_button_css_classes=>'quantity-btn'
,p_icon_css_classes=>'fa-minus'
,p_grid_new_row=>'Y'
,p_grid_column_span=>2
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38265237699295076444)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(66311371068282072357)
,p_button_name=>'Increment_quantity'
,p_button_static_id=>'increment_quantity'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(19471881378436504304)
,p_button_image_alt=>'Increment Quantity'
,p_warn_on_unsaved_changes=>null
,p_button_css_classes=>'quantity-btn'
,p_icon_css_classes=>'fa-plus'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
,p_grid_column_span=>2
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38242824406308699921)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(38242824233266699919)
,p_button_name=>'Cancel'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(19471882000429504304)
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
,p_button_execute_validations=>'N'
,p_button_css_classes=>'action-btn'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38242824382397699920)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(38242824233266699919)
,p_button_name=>'Add_To_Shopping_Cart'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(19471882000429504304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add To Shopping Cart'
,p_button_position=>'CREATE'
,p_button_condition=>'P12_IS_REPLACEMENT'
,p_button_condition2=>'0'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_button_css_classes=>'action-btn'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(52184848640028530118)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(38242824233266699919)
,p_button_name=>'Add_To_Order'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(19471882000429504304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add To Order'
,p_button_position=>'CREATE'
,p_button_condition=>'P12_IS_REPLACEMENT'
,p_button_condition2=>'1'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_button_css_classes=>'action-btn'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37730489477202642739)
,p_name=>'P12_VARIANT_1_NAME'
,p_item_sequence=>50
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37730489542779642740)
,p_name=>'P12_VARIANT_2_NAME'
,p_item_sequence=>60
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37730489616457642741)
,p_name=>'P12_VARIANT_3_NAME'
,p_item_sequence=>70
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37730489940774642744)
,p_name=>'P12_CATEGORY_ID'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37730490092793642745)
,p_name=>'P12_PRODUCT_ID'
,p_item_sequence=>40
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37730490521187642750)
,p_name=>'P12_VARIANT_1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(37730490389950642748)
,p_prompt=>'&P12_VARIANT_1_NAME.'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT',
'    variant_1 as display_value, variant_1 as return_value',
'FROM',
'    variant_stock',
'WHERE',
'    product_id = :P12_PRODUCT_ID;'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_colspan=>4
,p_field_template=>wwv_flow_imp.id(19471880312432504303)
,p_item_css_classes=>'variant-select'
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38242822424166699901)
,p_name=>'P12_VARIANT_2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(37730490389950642748)
,p_prompt=>'&P12_VARIANT_2_NAME.'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT',
'    variant_2 as display_value, variant_2 as return_value',
'FROM',
'    variant_stock',
'WHERE',
'    product_id = :P12_PRODUCT_ID',
'AND',
'    variant_1 = :P12_VARIANT_1;'))
,p_lov_display_null=>'YES'
,p_lov_cascade_parent_items=>'P12_VARIANT_1'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(19471880312432504303)
,p_item_css_classes=>'variant-select'
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38242822569693699902)
,p_name=>'P12_VARIANT_3'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(37730490389950642748)
,p_prompt=>'&P12_VARIANT_3_NAME.'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT',
'    variant_3 as display_value, variant_3 as return_value',
'FROM',
'    variant_stock',
'WHERE',
'    product_id = :P12_PRODUCT_ID',
'    AND variant_1 = :P12_VARIANT_1',
'    AND variant_2 = :P12_VARIANT_2'))
,p_lov_display_null=>'YES'
,p_lov_cascade_parent_items=>'P12_VARIANT_2'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(19471880312432504303)
,p_item_css_classes=>'variant-select'
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38242822610825699903)
,p_name=>'P12_AVAILABLE_QUANTITY'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(37730490389950642748)
,p_prompt=>'Stock Availability'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(19471879586967504303)
,p_item_css_classes=>'available-stock'
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large:t-Form-fieldContainer--radioButtonGroup'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38242824608459699923)
,p_name=>'P12_STOCK_ID'
,p_item_sequence=>80
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38242825008727699927)
,p_name=>'P12_SHOPPING_CART_ITEMS'
,p_item_sequence=>90
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(52184848725923530119)
,p_name=>'P12_IS_REPLACEMENT'
,p_item_sequence=>100
,p_item_default=>'0'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(52184849169726530123)
,p_name=>'P12_ORDER_ID'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(52184849748699530129)
,p_name=>'P12_CANCELLED_PROD_ID'
,p_item_sequence=>110
,p_item_default=>'0'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(61086700182270214968)
,p_name=>'P12_QUANTITY'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(66311371068282072357)
,p_placeholder=>'Quantity'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>5
,p_tag_css_classes=>'prod-qunatity'
,p_begin_on_new_line=>'N'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'0'
,p_attribute_03=>'center'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(38242822708186699904)
,p_name=>'Fetch variants names'
,p_event_sequence=>10
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(38242822836152699905)
,p_event_id=>wwv_flow_imp.id(38242822708186699904)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'MANAGE_PRODUCTS.get_variants(',
'    :P12_CATEGORY_ID, ',
'    :P12_VARIANT_1_NAME, ',
'    :P12_VARIANT_2_NAME, ',
'    :P12_VARIANT_3_NAME',
');'))
,p_attribute_02=>'P12_CATEGORY_ID'
,p_attribute_03=>'P12_VARIANT_1_NAME,P12_VARIANT_2_NAME,P12_VARIANT_3_NAME'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(38242823066644699907)
,p_event_id=>wwv_flow_imp.id(38242822708186699904)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$s("P12_VARIANT_1_LABEL", $v("P12_VARIANT_1_NAME"));',
'$s("P12_VARIANT_2_LABEL", $v("P12_VARIANT_2_NAME"));',
'$s("P12_VARIANT_3_LABEL", $v("P12_VARIANT_3_NAME"));'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(38242823194135699908)
,p_name=>'Get Max Stock'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P12_VARIANT_3'
,p_condition_element=>'P12_VARIANT_3'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(38242824785138699924)
,p_event_id=>wwv_flow_imp.id(38242823194135699908)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P12_STOCK_ID'
,p_attribute_01=>'FUNCTION_BODY'
,p_attribute_06=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_stock_id number;',
'BEGIN  ',
'    SELECT ',
'        stock_id',
'    INTO ',
'        l_stock_id',
'    FROM',
'        variant_stock',
'    WHERE',
'        variant_1 = :P12_VARIANT_1',
'        AND variant_2 = :P12_VARIANT_2',
'        AND variant_3 = :P12_VARIANT_3',
'        AND product_id = :P12_PRODUCT_ID;',
'',
'    RETURN l_stock_id;',
'END;'))
,p_attribute_07=>'P12_VARIANT_1,P12_VARIANT_2,P12_VARIANT_3,P12_PRODUCT_ID'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(38242823237862699909)
,p_event_id=>wwv_flow_imp.id(38242823194135699908)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P12_AVAILABLE_QUANTITY'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    STOCK_QUANTITY',
'FROM',
'    VARIANT_STOCK',
'WHERE',
'    product_id = :P12_PRODUCT_ID',
'    AND VARIANT_1 = :P12_VARIANT_1',
'    AND VARIANT_2 = :P12_VARIANT_2',
'    AND VARIANT_3 = :P12_VARIANT_3;'))
,p_attribute_07=>'P12_PRODUCT_ID,P12_VARIANT_1,P12_VARIANT_2,P12_VARIANT_3'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(38242823378333699910)
,p_event_id=>wwv_flow_imp.id(38242823194135699908)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P12_AVAILABLE_QUANTITY'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(38242824088185699917)
,p_event_id=>wwv_flow_imp.id(38242823194135699908)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P12_AVAILABLE_QUANTITY'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(38242823478679699911)
,p_name=>'Hide items'
,p_event_sequence=>30
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(38242823560738699912)
,p_event_id=>wwv_flow_imp.id(38242823478679699911)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P12_AVAILABLE_QUANTITY'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(38285179323850355519)
,p_name=>'Increment Quantity '
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(38265237699295076444)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(38285179788322355520)
,p_event_id=>wwv_flow_imp.id(38285179323850355519)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if($v("P12_QUANTITY") === "" && $v("P12_VARIANT_3") !== "") {',
'    $s("P12_QUANTITY", "1");',
'}else if($v("P12_VARIANT_3") === ""){',
'    apex.message.showErrors([',
'    {',
'        type:       "error",',
'        location:   [ "page" ],',
'        message:    "Variants are required before Choosing quantity",',
'        unsafe:     false',
'    },',
']);',
'setTimeout(apex.message.clearErrors, 3000);',
'}else if(parseInt($v("P12_QUANTITY")) < parseInt($v("P12_AVAILABLE_QUANTITY"))){',
'    $s("P12_QUANTITY", parseInt($v("P12_QUANTITY")) + 1);',
'}',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(38286384538530663607)
,p_name=>'Decrement Quantity'
,p_event_sequence=>50
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(38265237261510076443)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(38286384974202663608)
,p_event_id=>wwv_flow_imp.id(38286384538530663607)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$s("P12_QUANTITY", parseInt($v("P12_QUANTITY")) - 1);',
''))
,p_client_condition_type=>'GREATER_THAN'
,p_client_condition_element=>'P12_QUANTITY'
,p_client_condition_expression=>'1'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(42879123696500839715)
,p_name=>'disable add to cart button '
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P12_AVAILABLE_QUANTITY'
,p_condition_element=>'P12_AVAILABLE_QUANTITY'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'0'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(42879123754598839716)
,p_event_id=>wwv_flow_imp.id(42879123696500839715)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(38242824382397699920)
,p_attribute_01=>'$("#B38242824382397699920").attr("disabled", true);'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(42879124001215839719)
,p_event_id=>wwv_flow_imp.id(42879123696500839715)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(38242824382397699920)
,p_attribute_01=>'$("#B38242824382397699920").attr("disabled", false);'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(38242824585166699922)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Add To Shopping Cart'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'MANAGE_ORDERS.add_product(',
'    :P12_PRODUCT_ID, ',
'    :P12_QUANTITY, ',
'    :P12_STOCK_ID, ',
'    :P12_VARIANT_1_NAME, ',
'    :P12_VARIANT_2_NAME, ',
'    :P12_VARIANT_3_NAME',
');'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(38242824382397699920)
,p_process_success_message=>'Added To Shopping Cart ! '
,p_internal_uid=>38242824585166699922
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(38242824949331699926)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Update shopping  cart header'
,p_process_sql_clob=>':P12_SHOPPING_CART_ITEMS := MANAGE_ORDERS.get_quantity;'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(38242824382397699920)
,p_internal_uid=>38242824949331699926
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(52184849347423530125)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Replace Order Item'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'MANAGE_ORDERS.replace_item_in_order (',
'    :P12_ORDER_ID,',
'    :P12_PRODUCT_ID,',
'    :P12_CANCELLED_PROD_ID, ',
'    :P12_QUANTITY, ',
'    :P12_STOCK_ID',
');'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(52184848640028530118)
,p_internal_uid=>52184849347423530125
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(38242824877360699925)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close'
,p_attribute_01=>'P12_SHOPPING_CART_ITEMS'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>38242824877360699925
);
wwv_flow_imp.component_end;
end;
/
