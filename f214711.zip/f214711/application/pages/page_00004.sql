prompt --application/pages/page_00004
begin
--   Manifest
--     PAGE: 00004
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>6662355588643785590
,p_default_application_id=>214711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_RSWSP'
);
wwv_flow_imp_page.create_page(
 p_id=>4
,p_name=>'Edit Product Quantity'
,p_alias=>'EDIT-PRODUCT-QUANTITY'
,p_page_mode=>'MODAL'
,p_step_title=>'Edit Product Quantity'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'16'
,p_last_updated_by=>'PFE94053@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20230712202551'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(35681584556738205001)
,p_plug_name=>'Action buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(19471545059842504235)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(37036234246460922422)
,p_plug_name=>'Change Variants'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>100
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(63723076680535009440)
,p_plug_name=>'Update Quantity'
,p_region_css_classes=>'qunatity-container'
,p_region_template_options=>'#DEFAULT#:t-ItemContainer--alignCenter'
,p_plug_template=>wwv_flow_imp.id(19471801147464504260)
,p_plug_display_sequence=>110
,p_plug_grid_column_span=>4
,p_plug_display_column=>5
,p_attribute_01=>'Y'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(35676943255509013539)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(63723076680535009440)
,p_button_name=>'Increment_quantity'
,p_button_static_id=>'increment_quantity'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(19471881378436504304)
,p_button_image_alt=>'Increment Quantity'
,p_button_position=>'BUTTON_END'
,p_warn_on_unsaved_changes=>null
,p_button_css_classes=>'quantity-btn'
,p_icon_css_classes=>'fa-plus'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(35676942893055013539)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(63723076680535009440)
,p_button_name=>'Decrement_quantity'
,p_button_static_id=>'decrement_quantity'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--hoverIconPush'
,p_button_template_id=>wwv_flow_imp.id(19471881378436504304)
,p_button_image_alt=>'Decrement Quantity'
,p_button_position=>'BUTTON_START'
,p_warn_on_unsaved_changes=>null
,p_button_css_classes=>'quantity-btn'
,p_icon_css_classes=>'fa-minus'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(35681584958400205005)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(35681584556738205001)
,p_button_name=>'Cancel'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(19471882000429504304)
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(37036236369194922443)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(35681584556738205001)
,p_button_name=>'Add_To_Shopping_Cart'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(19471882000429504304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add To Shopping Cart'
,p_button_position=>'CREATE'
,p_button_condition=>'P4_STOCK_ID'
,p_button_condition_type=>'ITEM_IS_NULL_OR_ZERO'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(35681584717443205003)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(35681584556738205001)
,p_button_name=>'Update_Quantity'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(19471882000429504304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Update Quantity'
,p_button_position=>'NEXT'
,p_button_condition=>'P4_STOCK_ID'
,p_button_condition_type=>'ITEM_NOT_NULL_OR_ZERO'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(34869895550983248642)
,p_name=>'P4_SHOPPING_CART_ITEM'
,p_item_sequence=>40
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(34869896396136248650)
,p_name=>'P4_STOCK_ID'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37036233549240922415)
,p_name=>'P4_MAX_STOCK'
,p_item_sequence=>60
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37036234349473922423)
,p_name=>'P4_VARIANT_1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(37036234246460922422)
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT',
'    variant_1 as display_value, variant_1 as return_value',
'FROM',
'    variant_stock',
'WHERE',
'    product_id = :P4_PRODUCT_ID;'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_colspan=>4
,p_field_template=>wwv_flow_imp.id(19471879586967504303)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37036234462071922424)
,p_name=>'P4_VARIANT_2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(37036234246460922422)
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT',
'    variant_2 as display_value, variant_2 as return_value',
'FROM',
'    variant_stock',
'WHERE',
'    product_id = :P4_PRODUCT_ID',
'AND',
'    variant_1 = :P4_VARIANT_1;'))
,p_lov_cascade_parent_items=>'P4_VARIANT_1'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_colspan=>4
,p_field_template=>wwv_flow_imp.id(19471879586967504303)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37036234565230922425)
,p_name=>'P4_VARIANT_3'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(37036234246460922422)
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT',
'    variant_3 as display_value, variant_3 as return_value',
'FROM',
'    variant_stock',
'WHERE',
'    product_id = :P4_PRODUCT_ID',
'    AND variant_1 = :P4_VARIANT_1',
'    AND variant_2 = :P4_VARIANT_2'))
,p_lov_cascade_parent_items=>'P4_VARIANT_2'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(19471879586967504303)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37036234685476922426)
,p_name=>'P4_VARIANT_1_NAME'
,p_item_sequence=>70
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37036234794283922427)
,p_name=>'P4_VARIANT_2_NAME'
,p_item_sequence=>80
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37036234824070922428)
,p_name=>'P4_VARIANT_3_NAME'
,p_item_sequence=>90
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37036234952545922429)
,p_name=>'P4_CATEGORY_ID'
,p_item_sequence=>50
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37036235301406922433)
,p_name=>'P4_PRODUCT_ID'
,p_item_sequence=>10
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37036235687038922436)
,p_name=>'P4_AVAILABLE_STOCK'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(37036234246460922422)
,p_prompt=>'Available Stock'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(19471879586967504303)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(58498405857103152064)
,p_name=>'P4_NEW_QUNTITY'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(63723076680535009440)
,p_placeholder=>'Quantity'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>5
,p_tag_css_classes=>'prod-qunatity'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'0'
,p_attribute_03=>'center'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(35677601121643048909)
,p_name=>'Decrement Quantity'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(35676942893055013539)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(35677601564217048911)
,p_event_id=>wwv_flow_imp.id(35677601121643048909)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$s("P4_NEW_QUNTITY", parseInt($v("P4_NEW_QUNTITY")) - 1);',
'',
'    ',
''))
,p_client_condition_type=>'GREATER_THAN'
,p_client_condition_element=>'P4_NEW_QUNTITY'
,p_client_condition_expression=>'1'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(35677858652117053643)
,p_name=>'Increment Quantity '
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(35676943255509013539)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(35677859076753053644)
,p_event_id=>wwv_flow_imp.id(35677858652117053643)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if(parseInt($v("P4_NEW_QUNTITY")) < parseInt($v("P4_MAX_STOCK"))){',
'    $s("P4_NEW_QUNTITY", parseInt($v("P4_NEW_QUNTITY")) + 1);',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(37036234000238922420)
,p_name=>'Get Max Stock'
,p_event_sequence=>30
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(37036234189039922421)
,p_event_id=>wwv_flow_imp.id(37036234000238922420)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    STOCK_QUANTITY',
'INTO',
'    :P4_MAX_STOCK',
'FROM ',
'    VARIANT_STOCK',
'WHERE',
'    STOCK_ID = :P4_STOCK_ID;'))
,p_attribute_02=>'P4_STOCK_ID'
,p_attribute_03=>'P4_MAX_STOCK'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(37036235025943922430)
,p_name=>'Get Variants names'
,p_event_sequence=>40
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(37036235157590922431)
,p_event_id=>wwv_flow_imp.id(37036235025943922430)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'MANAGE_PRODUCTS.Get_variants(:P4_CATEGORY_ID, :P4_VARIANT_1_NAME, :P4_VARIANT_2_NAME, :P4_VARIANT_3_NAME);'
,p_attribute_02=>'P4_CATEGORY_ID'
,p_attribute_03=>'P4_VARIANT_1_NAME,P4_VARIANT_2_NAME,P4_VARIANT_3_NAME'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(37036235268505922432)
,p_event_id=>wwv_flow_imp.id(37036235025943922430)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$s("P4_VARIANT_1_LABEL", $v("P4_VARIANT_1_NAME"));',
'$s("P4_VARIANT_2_LABEL", $v("P4_VARIANT_2_NAME"));',
'$s("P4_VARIANT_3_LABEL", $v("P4_VARIANT_3_NAME"));'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(37036235454462922434)
,p_name=>'Set Default Variants & Available Stock'
,p_event_sequence=>50
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(37036235520343922435)
,p_event_id=>wwv_flow_imp.id(37036235454462922434)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    VARIANT_1, VARIANT_2, VARIANT_3, STOCK_QUANTITY',
'INTO ',
'    :P4_VARIANT_1, :P4_VARIANT_2, :P4_VARIANT_3, :P4_AVAILABLE_STOCK',
'FROM ',
'    VARIANT_STOCK',
'WHERE',
'    stock_id = :P4_STOCK_ID;'))
,p_attribute_02=>'P4_CATEGORY_ID'
,p_attribute_03=>'P4_VARIANT_1,P4_VARIANT_2,P4_VARIANT_3,P4_AVAILABLE_STOCK'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(37730486004167642705)
,p_name=>'Change Stock Quantity'
,p_event_sequence=>120
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P4_VARIANT_3'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(37730486174038642706)
,p_event_id=>wwv_flow_imp.id(37730486004167642705)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    STOCK_QUANTITY',
'INTO ',
'    :P4_AVAILABLE_STOCK',
'FROM ',
'    VARIANT_STOCK',
'WHERE',
'    product_id = :P4_PRODUCT_ID',
'    AND variant_1 = :P4_VARIANT_1',
'    AND variant_2 = :P4_VARIANT_2',
'    AND variant_3 = :P4_VARIANT_3;'))
,p_attribute_02=>'P4_VARIANT_1,P4_VARIANT_2,P4_VARIANT_3,P4_PRODUCT_ID'
,p_attribute_03=>'P4_AVAILABLE_STOCK'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_client_condition_type=>'NOT_NULL'
,p_client_condition_element=>'P4_VARIANT_3'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(37730486221117642707)
,p_event_id=>wwv_flow_imp.id(37730486004167642705)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P4_AVAILABLE_STOCK'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(35681585149973205007)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Update Qunantity'
,p_process_sql_clob=>'MANAGE_ORDERS.update_product_qty(:P4_SHOPPING_CART_ITEM,:P4_NEW_QUNTITY);'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(35681584717443205003)
,p_internal_uid=>35681585149973205007
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(35681585229074205008)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>35681585229074205008
);
wwv_flow_imp.component_end;
end;
/
