prompt --application/pages/page_00075
begin
--   Manifest
--     PAGE: 00075
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>6662355588643785590
,p_default_application_id=>214711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_RSWSP'
);
wwv_flow_imp_page.create_page(
 p_id=>75
,p_name=>'Seller Dashboard Customers'
,p_alias=>'SELLER-DASHBOARD-CUSTOMERS'
,p_step_title=>'Seller Dashboard Customers'
,p_autocomplete_on_off=>'OFF'
,p_css_file_urls=>'#APP_FILES#Styling/main_style#MIN#.css'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Report-colHead {',
'    font-family: var(--secondary-header-font);',
'}',
'',
'.t-Report-cell {',
'    font-family: var(--regular-text-font);',
'}',
'',
'.t-Report-cell > img{',
'    width: 100px !important;',
'    height: 100px !important;',
'    object-fit: contain;',
'    border-radius: 12px;',
'}',
'',
'.send-message {',
'    color: var(--fouth-color);',
'}'))
,p_step_template=>wwv_flow_imp.id(19471509145742504218)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'03'
,p_last_updated_by=>'PFE94053@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20230818191750'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(40021826070707182130)
,p_plug_name=>'Seller Dashboard Navigation'
,p_region_css_classes=>'dashboard-side-menu'
,p_region_sub_css_classes=>'dashboard-side-menu-list'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-LinksList--showArrow:t-LinksList--showIcons'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_02'
,p_list_id=>wwv_flow_imp.id(38784043417088031374)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(19471863408174504294)
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(40021826180142182131)
,p_name=>'List Of Customers'
,p_template=>wwv_flow_imp.id(19471808805460504264)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--altRowsDefault:t-Report--rowHighlight:t-Report--inline'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT c.customer_id,',
'    c.firstname || '' '' || c.lastname fullname,',
'    c.phone, ',
'    c.email,',
'    c.address,',
'    ct.city_name, ',
'    st.state_name , ',
'    ''Send Message''',
'FROM customer c',
'LEFT JOIN cities ct ON c.city_id = ct.city_id',
'LEFT JOIN states st ON ct.state_id = st.state_id ',
'LEFT JOIN orders o ON c.customer_id = o.customer_id',
'LEFT JOIN order_items oi ON o.order_id = oi.order_id',
'LEFT JOIN product p ON oi.product_id = p.product_id',
'LEFT JOIN stores s ON p.store_id = s.store_id ',
'WHERE s.customer_id = TO_NUMBER(:USER_ID);'))
,p_query_row_template=>wwv_flow_imp.id(19471847069031504283)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_break_cols=>'1'
,p_query_no_data_found=>'No Customers Yet !'
,p_break_type_flag=>'DEFAULT_BREAK_FORMATTING'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(41154317512325227824)
,p_query_column_id=>1
,p_column_alias=>'CUSTOMER_ID'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(40242457417864369204)
,p_query_column_id=>2
,p_column_alias=>'FULLNAME'
,p_column_display_sequence=>20
,p_column_heading=>'Name'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(40242457510008369205)
,p_query_column_id=>3
,p_column_alias=>'PHONE'
,p_column_display_sequence=>30
,p_column_heading=>'Phone'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(40242457684266369206)
,p_query_column_id=>4
,p_column_alias=>'EMAIL'
,p_column_display_sequence=>40
,p_column_heading=>'Email'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(40242457713951369207)
,p_query_column_id=>5
,p_column_alias=>'ADDRESS'
,p_column_display_sequence=>50
,p_column_heading=>'Address'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(40242457898140369208)
,p_query_column_id=>6
,p_column_alias=>'CITY_NAME'
,p_column_display_sequence=>60
,p_column_heading=>'City Name'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(40242457940063369209)
,p_query_column_id=>7
,p_column_alias=>'STATE_NAME'
,p_column_display_sequence=>70
,p_column_heading=>'State Name'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(40242458071047369210)
,p_query_column_id=>8
,p_column_alias=>'''SENDMESSAGE'''
,p_column_display_sequence=>80
,p_column_heading=>'Send Message'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:80:&SESSION.::&DEBUG.:80:P80_PARTICIPANT_1_ID,P80_PARTICIPANT_2_ID:&USER_ID.,#CUSTOMER_ID#'
,p_column_linktext=>'<span class="fa fa-comments-o send-message" aria-hidden="true "></span>'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(40242458180564369211)
,p_plug_name=>'Customers by Regions'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>10
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(40242458278204369212)
,p_region_id=>wwv_flow_imp.id(40242458180564369211)
,p_chart_type=>'bar'
,p_height=>'400'
,p_animation_on_display=>'alphaFade'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>false
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'off'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(40242458325306369213)
,p_chart_id=>wwv_flow_imp.id(40242458278204369212)
,p_seq=>10
,p_name=>'Series 1'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'    select  st.state_name, count(DISTINCT o.customer_id)',
'    from    orders o, order_items oi, customer c, cities ct, states st',
'    where   o.order_id = oi.order_id',
'    and     o.customer_id = c.customer_id',
'    and     c.city_id = ct.city_id ',
'    and     ct.state_id = st.state_id',
'    group by st.state_name',
'    order by count(DISTINCT o.customer_id);'))
,p_items_value_column_name=>'COUNT(DISTINCTO.CUSTOMER_ID)'
,p_items_label_column_name=>'STATE_NAME'
,p_color=>'#3a3632'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(40242458841235369218)
,p_chart_id=>wwv_flow_imp.id(40242458278204369212)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_title=>'States'
,p_title_font_family=>'Comic Sans MS'
,p_title_font_style=>'italic'
,p_title_font_size=>'10'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(40242458925850369219)
,p_chart_id=>wwv_flow_imp.id(40242458278204369212)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_title=>'Number Of Customers'
,p_title_font_family=>'Comic Sans MS'
,p_title_font_style=>'italic'
,p_title_font_size=>'10'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_step=>1
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
);
wwv_flow_imp.component_end;
end;
/
