prompt --application/pages/page_00006
begin
--   Manifest
--     PAGE: 00006
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>6662355588643785590
,p_default_application_id=>214711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_RSWSP'
);
wwv_flow_imp_page.create_page(
 p_id=>6
,p_name=>'Add To Cart'
,p_alias=>'ADD-TO-CAR'
,p_page_mode=>'MODAL'
,p_step_title=>'&APP_NAME. - Successfully added to your cart'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.buttons {',
'    height: 100%;',
'    display: flex;',
'    flex-direction: rown;',
'    justify-content: space-evenly;',
'    align-content: space-between;',
'}',
'',
'.option-btn {',
'    margin: 10px;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'23'
,p_last_updated_by=>'PFE94053@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20230724222254'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(26571014200551157613)
,p_plug_name=>'Product Added'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(19471549395551504237)
,p_plug_display_sequence=>90
,p_plug_grid_column_span=>6
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT  p.product_id,',
'        p.product_name,',
'        p.product_description,',
'        NEW_PRICE(p.product_id) * :P6_QUNATITY Total,',
'        pi.image',
'FROM    product p',
'        join (SELECT image_id,',
'            product_id,',
'            image',
'            FROM(SELECT image_id,',
'                        product_id,',
'                        image,',
'                        Row_number()',
'                            over (',
'                            PARTITION BY product_id',
'                            ORDER BY image_id) AS rn',
'                FROM   product_images) img',
'                WHERE  rn = 1) pi',
'        ON p.product_id = pi.product_id',
'WHERE p.product_id = :P6_PRODUCT_ID'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_ajax_items_to_submit=>'P6_PRODUCT_ID'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(26571014328401157614)
,p_region_id=>wwv_flow_imp.id(26571014200551157613)
,p_layout_type=>'ROW'
,p_title_adv_formatting=>false
,p_title_column_name=>'PRODUCT_NAME'
,p_sub_title_adv_formatting=>true
,p_sub_title_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Total Price : &TOTAL. TDN <br>',
'Quantity : &P6_QUNATITY.'))
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_icon_source_type=>'BLOB'
,p_icon_blob_column_name=>'IMAGE'
,p_icon_position=>'END'
,p_media_adv_formatting=>false
,p_pk1_column_name=>'PRODUCT_ID'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(26571017047157157641)
,p_plug_name=>'Options'
,p_region_name=>'button-container'
,p_region_css_classes=>'buttons'
,p_region_template_options=>'#DEFAULT#:t-Form--standardPadding:t-Form--labelsAbove:t-Region-orderBy--center:margin-top-none'
,p_plug_template=>wwv_flow_imp.id(19471542261328504234)
,p_plug_display_sequence=>60
,p_plug_display_point=>'REGION_POSITION_03'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(26571017234784157643)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(26571017047157157641)
,p_button_name=>'Keep_Shopping'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(19471882000429504304)
,p_button_image_alt=>'Keep Shopping'
,p_button_css_classes=>'option-btn'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(26571017168165157642)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(26571017047157157641)
,p_button_name=>'Procced_To_Shopping_Cart'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--success:t-Button--iconLeft:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(19471882117602504304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Procced To Shopping Cart'
,p_button_css_classes=>'option-btn'
,p_icon_css_classes=>'fa-long-arrow-right'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(35681588933146205045)
,p_branch_name=>'Return To Products'
,p_branch_action=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:1::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(26571017234784157643)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(35681589082858205046)
,p_branch_name=>'Go To Shopping Cart'
,p_branch_action=>'f?p=&APP_ID.:27:&SESSION.::&DEBUG.:27::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(26571017168165157642)
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(26571013809472157609)
,p_name=>'P6_PRODUCT_ID'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(26571013908713157610)
,p_name=>'P6_QUNATITY'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(34869894773869248634)
,p_name=>'P6_PRICE'
,p_item_sequence=>40
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(34869896285269248649)
,p_name=>'P6_STOCK_ID'
,p_item_sequence=>50
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37730486899558642713)
,p_name=>'P6_VARIANT_1_NAME'
,p_item_sequence=>60
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37730487074888642715)
,p_name=>'P6_VARIANT_2_NAME'
,p_item_sequence=>70
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37730487109980642716)
,p_name=>'P6_VARIANT_3_NAME'
,p_item_sequence=>80
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(26571014084935157611)
,p_name=>'Adding product to shopping cart'
,p_event_sequence=>10
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(26571014176053157612)
,p_event_id=>wwv_flow_imp.id(26571014084935157611)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'MANAGE_ORDERS.add_product(',
'    :P6_PRODUCT_ID, ',
'    :P6_QUNATITY, ',
'    :P6_STOCK_ID, ',
'    :P6_VARIANT_1_NAME, ',
'    :P6_VARIANT_2_NAME, ',
'    :P6_VARIANT_3_NAME',
');'))
,p_attribute_02=>'P6_PRODUCT_ID,P6_QUNATITY,P6_STOCK_ID,P6_VARIANT_1_NAME,P6_VARIANT_2_NAME,P6_VARIANT_3_NAME'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(26571014644990157617)
,p_name=>'Set Shopping Cart Icon'
,p_event_sequence=>20
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(26571014794519157618)
,p_event_id=>wwv_flow_imp.id(26571014644990157617)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':SHOPPING_CART_ITEMS := MANAGE_ORDERS.get_quantity;'
,p_attribute_03=>'SHOPPING_CART_ITEMS'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(26571016907756157640)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(26571017234784157643)
,p_internal_uid=>26571016907756157640
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(35681589122750205047)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Update Shopping Cart Icon'
,p_process_sql_clob=>':SHOPPIGN_CART_ITEMS := MANAGE_ORDERS.get_quantity;'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(26571017234784157643)
,p_internal_uid=>35681589122750205047
);
wwv_flow_imp.component_end;
end;
/
