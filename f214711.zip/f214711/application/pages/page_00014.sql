prompt --application/pages/page_00014
begin
--   Manifest
--     PAGE: 00014
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>6662355588643785590
,p_default_application_id=>214711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_RSWSP'
);
wwv_flow_imp_page.create_page(
 p_id=>14
,p_name=>'Notifications'
,p_alias=>'NOTIFICATIONS'
,p_page_mode=>'MODAL'
,p_step_title=>'Notifications'
,p_autocomplete_on_off=>'OFF'
,p_css_file_urls=>'#APP_FILES#Styling/main_style#MIN#.css'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.clarification {',
'    font-family: var(--regular-text-font);',
'    font-size: small;',
'    color: var(--grey-color);',
'}',
'',
'.clarification > span {',
'    font-weight: bold;',
'    text-decoration: underline;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'11'
,p_last_updated_by=>'PFE94053@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20230819202337'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(42153516341828704831)
,p_plug_name=>'Messages'
,p_region_template_options=>'#DEFAULT#:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>20
,p_plug_display_condition_type=>'ITEM_IS_NOT_ZERO'
,p_plug_display_when_condition=>'P0_NOTIFICATIONS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(42153516815012704836)
,p_plug_name=>'You have &P0_NOTIFICATIONS. new messages'
,p_parent_plug_id=>wwv_flow_imp.id(42153516341828704831)
,p_region_template_options=>'#DEFAULT#:t-Region--textContent:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>8
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(42879124846706839727)
,p_plug_name=>'wishlist Product Updates '
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>30
,p_plug_display_condition_type=>'FUNCTION_BODY'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin ',
'',
'    if :APP_NOTIFICATION_STOCK_STATUS > 0 then ',
'        return true;',
'    else ',
'        return false;  ',
'    end if;',
'end;'))
,p_plug_display_when_cond2=>'PLSQL'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(42879125013538839729)
,p_plug_name=>'You have &APP_NOTIFICATION_STOCK_STATUS. new updated product(s).'
,p_parent_plug_id=>wwv_flow_imp.id(42879124846706839727)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>10
,p_plug_source=>'<p class="clarification"> <span>&APP_STOCK_CHANGE_LIST.</span> have been updated by the seller(s). Please review the changes to stay informed about the latest updates.</p>'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(42879125241914839731)
,p_plug_name=>'New Orders'
,p_region_template_options=>'#DEFAULT#:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>40
,p_plug_display_condition_type=>'FUNCTION_BODY'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Declare',
'    cus_type number;',
'begin ',
'    select cus_type_id into cus_type from customer where customer_id = to_number(:USER_ID);',
'    if cus_type = 1 and :APP_NOTIFICATION_NEW_ORDERS > 0 then ',
'        return true;',
'    else ',
'        return false;  ',
'    end if;',
'end;'))
,p_plug_display_when_cond2=>'PLSQL'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(47390720665508786706)
,p_plug_name=>' You have &APP_NOTIFICATION_NEW_ORDERS. new order(s)'
,p_parent_plug_id=>wwv_flow_imp.id(42879125241914839731)
,p_region_template_options=>'#DEFAULT#:t-Region--textContent:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>8
,p_plug_source=>'<p class="clarification"> Congratulations! You have new order(s). Please review the details and take the necessary steps to fulfill the order. Thank you for using our platform</p>'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(42879125666746839735)
,p_plug_name=>'Store Visites'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>70
,p_plug_display_condition_type=>'FUNCTION_BODY'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Declare',
'cus_type number;',
'begin ',
'    select cus_type_id into cus_type from customer where customer_id = to_number(:USER_ID);',
'    if cus_type = 1 and :APP_NOTIFICATION_STORE_VISITES > 0 then ',
'        return true;',
'    else ',
'        return false;  ',
'    end if;',
'end;'))
,p_plug_display_when_cond2=>'PLSQL'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(42879125833064839737)
,p_plug_name=>'You have &APP_NOTIFICATION_STORE_VISITES. new store visites'
,p_parent_plug_id=>wwv_flow_imp.id(42879125666746839735)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>10
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(42879127016554839749)
,p_plug_name=>'product visites'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>80
,p_plug_display_condition_type=>'FUNCTION_BODY'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Declare',
'cus_type number;',
'begin ',
'    select cus_type_id into cus_type from customer where customer_id = to_number(:USER_ID);',
'    if cus_type = 1 and :APP_NOTIFICATIONS_PROD_VISITES > 0 then ',
'        return true;',
'    else ',
'        return false;  ',
'    end if;',
'end;'))
,p_plug_display_when_cond2=>'PLSQL'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(42879127138530839750)
,p_plug_name=>'You have &APP_NOTIFICATIONS_PROD_VISITES. new product visites'
,p_parent_plug_id=>wwv_flow_imp.id(42879127016554839749)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>10
,p_plug_display_condition_type=>'FUNCTION_BODY'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Declare',
'cus_type number;',
'begin ',
'    select cus_type_id into cus_type from customer where customer_id = to_number(:USER_ID);',
'    if cus_type = 1 and :APP_NOTIFICATIONS_PROD_VISITES > 0 then ',
'        return true;',
'    else ',
'        return false;  ',
'    end if;',
'end;'))
,p_plug_display_when_cond2=>'PLSQL'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(47390720976231786709)
,p_plug_name=>'product added to wishlist'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>90
,p_plug_display_condition_type=>'FUNCTION_BODY'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Declare',
'cus_type number;',
'begin ',
'    select cus_type_id into cus_type from customer where customer_id = to_number(:USER_ID);',
'    if cus_type = 1 and :APP_NOTIFICATION_PROD_ADDED_WISHLIST > 0 then ',
'        return true;',
'    else ',
'        return false;  ',
'    end if;',
'end;'))
,p_plug_display_when_cond2=>'PLSQL'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(47390721070029786710)
,p_plug_name=>'You have &APP_NOTIFICATION_PROD_ADDED_WISHLIST. new product(s) added to wishlist.'
,p_parent_plug_id=>wwv_flow_imp.id(47390720976231786709)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>10
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(52184849975267530131)
,p_plug_name=>'Order Updates Tally'
,p_region_template_options=>'#DEFAULT#:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>50
,p_plug_display_condition_type=>'FUNCTION_BODY'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'begin ',
'',
'    if :P0_ORDER_CHANGE > 0 then ',
'        return true;',
'    else ',
'        return false;  ',
'    end if;',
'end;'))
,p_plug_display_when_cond2=>'PLSQL'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(52184850092202530132)
,p_plug_name=>' You have  &P0_ORDER_CHANGE. newly updated order item(s)'
,p_parent_plug_id=>wwv_flow_imp.id(52184849975267530131)
,p_region_template_options=>'#DEFAULT#:t-Region--textContent:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>8
,p_plug_source=>'<p class="clarification">Order(s) : <span>#&P0_ORDER_CHANGE_LIST.</span> have been updated by the seller(s). Please review the changes to stay informed about the latest updates.</p>'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(42153516569637704833)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(42153516341828704831)
,p_button_name=>'check_messages'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--iconRight:t-Button--hoverIconPush:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(19471882117602504304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Check Messages'
,p_button_redirect_url=>'f?p=&APP_ID.:16:&SESSION.::&DEBUG.:16::'
,p_icon_css_classes=>'fa-users-chat'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(42879125151532839730)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(42879124846706839727)
,p_button_name=>'check_wishlist'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(19471882000429504304)
,p_button_image_alt=>'Check Wishlist Page'
,p_button_redirect_url=>'f?p=&APP_ID.:31:&SESSION.::&DEBUG.:31::'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(42879125905253839738)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(42879125666746839735)
,p_button_name=>'check_store'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(19471882000429504304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Check Store Dashbord'
,p_button_redirect_url=>'f?p=&APP_ID.:71:&SESSION.::&DEBUG.:71::'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(47390720159037786701)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(42879127016554839749)
,p_button_name=>'check_product'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(19471882000429504304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Check Product'
,p_button_redirect_url=>'f?p=&APP_ID.:72:&SESSION.::&DEBUG.:72::'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(47390721139382786711)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(47390720976231786709)
,p_button_name=>'check_product_dashbord'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(19471882000429504304)
,p_button_image_alt=>'Check Product Dashbord'
,p_button_redirect_url=>'f?p=&APP_ID.:72:&SESSION.::&DEBUG.:72::'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(47390720851310786708)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(42879125241914839731)
,p_button_name=>'Check_orders'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--iconRight:t-Button--hoverIconPush:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(19471882117602504304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Check Orders'
,p_button_redirect_url=>'f?p=&APP_ID.:73:&SESSION.::&DEBUG.:73:P73_FILTER_ORDERS:Pending'
,p_icon_css_classes=>'fa-box-arrow-in-ne'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(52184850369518530135)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(52184849975267530131)
,p_button_name=>'Check_My_Orders'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--iconRight:t-Button--hoverIconPush:t-Button--stretch:t-Button--gapTop'
,p_button_template_id=>wwv_flow_imp.id(19471882117602504304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Check Orders'
,p_button_redirect_url=>'f?p=&APP_ID.:13:&SESSION.::&DEBUG.:73:P13_ORDER_STATUS:Updated'
,p_icon_css_classes=>'fa-shopping-bag'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp.component_end;
end;
/
