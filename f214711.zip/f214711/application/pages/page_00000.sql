prompt --application/pages/page_00000
begin
--   Manifest
--     PAGE: 00000
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>6662355588643785590
,p_default_application_id=>214711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_RSWSP'
);
wwv_flow_imp_page.create_page(
 p_id=>0
,p_name=>'Global Page'
,p_step_title=>'Global Page'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'D'
,p_page_component_map=>'14'
,p_last_updated_by=>'PFE94053@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20230818192429'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(37171148900440069245)
,p_plug_name=>'Footer'
,p_region_template_options=>'#DEFAULT#:t-Region--textContent:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_05'
,p_plug_source=>'footer'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(42374006910461189316)
,p_plug_name=>'Search'
,p_region_css_classes=>'search-container'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--textContent:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>20
,p_plug_display_point=>'AFTER_LOGO'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(42153515912322704827)
,p_name=>'P0_NOTIFICATIONS'
,p_item_sequence=>10
,p_item_default=>'0'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(42374007030312189317)
,p_name=>'P0_GLOBAL_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(42374006910461189316)
,p_prompt=>'Global Search'
,p_placeholder=>'Search For Brands, Products, Categories....'
,p_display_as=>'NATIVE_AUTO_COMPLETE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT display_text',
'FROM GLOBAL_SEARCH_VIEW'))
,p_cSize=>40
,p_field_template=>wwv_flow_imp.id(19471879237081504302)
,p_item_css_classes=>'search-item'
,p_item_icon_css_classes=>'fa-search'
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'CONTAINS_IGNORE'
,p_attribute_04=>'Y'
,p_attribute_05=>'15'
,p_attribute_09=>'1'
,p_attribute_10=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(42374007616469189323)
,p_name=>'P0_SEARCH_URL'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(42374006910461189316)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(42879126667300839745)
,p_name=>'P0_USER_NOTIFICATIONS'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(42374006910461189316)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(52184849887477530130)
,p_name=>'P0_ORDER_CHANGE'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(52184850719005530139)
,p_name=>'P0_ORDER_CHANGE_LIST'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(18879228866208497237)
,p_name=>'Build Custom Navigation Bar'
,p_event_sequence=>10
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(18879228929926497238)
,p_event_id=>wwv_flow_imp.id(18879228866208497237)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'$(''#navigation_bar_custom_items'').insertBefore($(''.t-Header-navBar''));',
'',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(42374007430226189321)
,p_name=>'Go'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P0_GLOBAL_SEARCH'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(42374007521378189322)
,p_event_id=>wwv_flow_imp.id(42374007430226189321)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_url VARCHAR2(4000);',
'BEGIN',
'    SELECT entry_target',
'    INTO v_url',
'    FROM GLOBAL_SEARCH_VIEW',
'    WHERE display_text LIKE ''%'' || :P0_GLOBAL_SEARCH || ''%'';',
'',
'    v_url := REPLACE(v_url, ''&''||''SESSION.'', ''&SESSION.'');',
'    v_url := REPLACE(v_url, ''&''||''APP_SESSION.'', ''&APP_SESSION.'');',
'    v_url := REPLACE(v_url, ''&''||''DEBUG.'', ''&DEBUG.'');',
'    v_url := REPLACE(v_url, ''&''||''APP_ID.'', ''&APP_ID.'');',
'',
'    :P0_SEARCH_URL := APEX_UTIL.PREPARE_URL(',
'        p_url => v_url',
'    );',
'',
'    :P0_GLOBAL_SEARCH := NULL;',
'EXCEPTION',
'    WHEN NO_DATA_FOUND THEN',
'        :P0_SEARCH_URL := APEX_PAGE.GET_URL(',
'            p_page => 23,',
'            p_items => ''P23_SEARCH_CRITERIA'',',
'            p_values => :P0_GLOBAL_SEARCH',
'        );',
'    WHEN TOO_MANY_ROWS THEN',
'        :P0_SEARCH_URL := APEX_PAGE.GET_URL(',
'            p_page => 23,',
'            p_items => ''P23_SEARCH_CRITERIA'',',
'            p_values => :P0_GLOBAL_SEARCH',
'        );',
'END;',
''))
,p_attribute_02=>'P0_GLOBAL_SEARCH'
,p_attribute_03=>'P0_SEARCH_URL,P0_GLOBAL_SEARCH'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(42374008047598189327)
,p_event_id=>wwv_flow_imp.id(42374007430226189321)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.page.cancelWarnOnUnsavedChanges();',
'apex.navigation.redirect($v(''P0_SEARCH_URL''));'))
);
wwv_flow_imp.component_end;
end;
/
