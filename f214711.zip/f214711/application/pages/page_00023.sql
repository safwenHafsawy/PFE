prompt --application/pages/page_00023
begin
--   Manifest
--     PAGE: 00023
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>6662355588643785590
,p_default_application_id=>214711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_RSWSP'
);
wwv_flow_imp_page.create_page(
 p_id=>23
,p_name=>'Search Result'
,p_alias=>'SEARCH-RESULT'
,p_step_title=>'Search Result'
,p_autocomplete_on_off=>'OFF'
,p_css_file_urls=>'#APP_FILES#Styling/main_style#MIN#.css'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.page-header {',
'    font-family: var(--secondary-header-font);',
'    color: var(--fouth-color);',
'    margin-left: 10px;',
'}',
'',
'.t-Region-title {',
'    background-color: var(--second-color);',
'    border-radius: 10px;',
'    padding: 10px;',
'}',
'',
''))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'23'
,p_last_updated_by=>'PFE94053@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20230724212116'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(42374008307524189330)
,p_plug_name=>'Available Stores'
,p_region_template_options=>'#DEFAULT#:t-Region--textContent:t-Region--scrollBody:margin-top-md'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>50
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(42374008660287189333)
,p_plug_name=>'Liste of Stores'
,p_parent_plug_id=>wwv_flow_imp.id(42374008307524189330)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(19471549395551504237)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'TABLE'
,p_query_table=>'STORES'
,p_query_where=>'lower(store_name) like ''%'' || lower(:P23_SEARCH_CRITERIA) || ''%'' OR lower(store_description) like ''%'' || lower(:P23_SEARCH_CRITERIA) || ''%'''
,p_include_rowid_column=>false
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_ajax_items_to_submit=>'P23_SEARCH_CRITERIA'
,p_plug_query_num_rows_type=>'SCROLL'
,p_plug_query_no_data_found=>'No Stores Matching Your Search !'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(42374008763253189334)
,p_region_id=>wwv_flow_imp.id(42374008660287189333)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>false
,p_title_column_name=>'STORE_NAME'
,p_sub_title_adv_formatting=>false
,p_sub_title_column_name=>'STORE_DESCRIPTION'
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_media_adv_formatting=>false
,p_media_source_type=>'BLOB'
,p_media_blob_column_name=>'LOGO'
,p_media_display_position=>'BODY'
,p_media_sizing=>'FIT'
,p_pk1_column_name=>'STORE_ID'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(42887192124411190801)
,p_card_id=>wwv_flow_imp.id(42374008763253189334)
,p_action_type=>'FULL_CARD'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:5:P5_STORE_ID,P5_STORE_OWNER_ID:&STORE_ID.,&CUSTOMER_ID.'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(42374008520372189332)
,p_plug_name=>'Available Products'
,p_region_template_options=>'#DEFAULT#:t-Region--textContent:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>40
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(42374008933468189336)
,p_plug_name=>'List Of products'
,p_parent_plug_id=>wwv_flow_imp.id(42374008520372189332)
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--styleB'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(19471549395551504237)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    product_id,',
'    product_name,',
'    unit_price,',
'    category_id,',
'    store_id,',
'    store_name,',
'    store_owner,',
'    discount,',
'    new_price,',
'    created_at,',
'    image',
'FROM (',
'    SELECT',
'        p.product_id,',
'        p.product_name,',
'        p.unit_price,',
'        p.category_id,',
'        p.store_id,',
'        s.store_name,',
'        s.customer_id AS store_owner,',
'        p.discount,',
'        NEW_PRICE(p.product_id) AS new_price,',
'        p.created_at,',
'        pi.image,',
'        ROW_NUMBER() OVER (PARTITION BY p.product_id ORDER BY p.created_at DESC) AS rn',
'    FROM',
'        product p',
'        JOIN (',
'            SELECT',
'                image_id,',
'                product_id,',
'                image,',
'                ROW_NUMBER() OVER (PARTITION BY product_id ORDER BY image_id) AS rn',
'            FROM',
'                product_images',
'        ) pi ON p.product_id = pi.product_id AND pi.rn = 1',
'        JOIN stores s ON p.store_id = s.store_id',
'        LEFT JOIN variant_stock vs ON p.product_id = vs.product_id',
'    WHERE',
'        (lower(product_name) LIKE ''%'' || lower(:P23_SEARCH_CRITERIA) || ''%'' ',
'        OR lower(product_description) LIKE ''%'' || lower(:P23_SEARCH_CRITERIA) || ''%''',
'        OR lower(variant_1) LIKE ''%'' || lower(:P23_SEARCH_CRITERIA) || ''%''',
'        OR lower(variant_2) LIKE ''%'' || lower(:P23_SEARCH_CRITERIA) || ''%''',
'        OR lower(variant_3) LIKE ''%'' || lower(:P23_SEARCH_CRITERIA) || ''%'')',
')',
'WHERE rn = 1',
'ORDER BY created_at DESC;',
''))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_ajax_items_to_submit=>'P23_SEARCH_CRITERIA'
,p_plug_query_num_rows_type=>'SCROLL'
,p_plug_query_no_data_found=>'No Products Matching Your Search !'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(42374009039204189337)
,p_region_id=>wwv_flow_imp.id(42374008933468189336)
,p_layout_type=>'GRID'
,p_grid_column_count=>5
,p_card_css_classes=>'card'
,p_title_adv_formatting=>false
,p_title_column_name=>'PRODUCT_NAME'
,p_sub_title_adv_formatting=>true
,p_sub_title_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{case DISCOUNT/}',
'{when 0/}',
'<b>&NEW_PRICE. TN</b>',
'{otherwise/}',
'&DISCOUNT.% &emsp;',
'<b>&NEW_PRICE. TN </b>&emsp;',
'<s> &UNIT_PRICE. TN</s>',
'',
'',
'{endcase/}'))
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_media_adv_formatting=>false
,p_media_source_type=>'BLOB'
,p_media_blob_column_name=>'IMAGE'
,p_media_display_position=>'FIRST'
,p_media_appearance=>'SQUARE'
,p_media_sizing=>'FIT'
,p_pk1_column_name=>'PRODUCT_ID'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(42374010337060189350)
,p_card_id=>wwv_flow_imp.id(42374009039204189337)
,p_action_type=>'FULL_CARD'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:18:&SESSION.::&DEBUG.:18:P18_PRODUCT_ID:&PRODUCT_ID.'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(42887192222091190802)
,p_card_id=>wwv_flow_imp.id(42374009039204189337)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>20
,p_label=>'Store : &STORE_NAME.'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:5:P5_STORE_ID,P5_STORE_OWNER_ID:&STORE_ID.,&STORE_OWNER.'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'to_store'
,p_is_hot=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(42887192371234190803)
,p_card_id=>wwv_flow_imp.id(42374009039204189337)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>30
,p_label=>'add to wishlist'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'javascript:void(null)'
,p_button_display_type=>'ICON'
,p_icon_css_classes=>'fa-heart'
,p_action_css_classes=>'heart'
,p_is_hot=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(42887192485893190804)
,p_card_id=>wwv_flow_imp.id(42374009039204189337)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>40
,p_label=>'Add To Cart'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'javascript:void(null)'
,p_button_display_type=>'TEXT'
,p_is_hot=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(42374009782621189344)
,p_plug_name=>'Page Header'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_plug_template=>wwv_flow_imp.id(19471821290996504270)
,p_plug_display_sequence=>30
,p_plug_source=>'<h3 class="page-header"> Search Results For :  <span>&P23_SEARCH_CRITERIA. </span> </h3>'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(42374009929241189346)
,p_plug_name=>'Available Categories'
,p_region_template_options=>'#DEFAULT#:t-Region--textContent:t-Region--scrollBody:margin-top-md'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>60
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(42374010045134189347)
,p_plug_name=>'Categories List'
,p_parent_plug_id=>wwv_flow_imp.id(42374009929241189346)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(19471549395551504237)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'TABLE'
,p_query_table=>'CATEGORIES'
,p_query_where=>'lower(category_name) like ''%'' || lower(:P23_SEARCH_CRITERIA) || ''%'''
,p_include_rowid_column=>false
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_plug_query_no_data_found=>'No Categories Matching Your Search !'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(42374010153915189348)
,p_region_id=>wwv_flow_imp.id(42374010045134189347)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>false
,p_title_column_name=>'CATEGORY_NAME'
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_media_adv_formatting=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(42374010211880189349)
,p_card_id=>wwv_flow_imp.id(42374010153915189348)
,p_action_type=>'FULL_CARD'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.:2:P2_CATEG_ID:&CATEGORY_ID.'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(42374007816071189325)
,p_name=>'P23_SEARCH_CRITERIA'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp.component_end;
end;
/
