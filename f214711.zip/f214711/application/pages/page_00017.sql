prompt --application/pages/page_00017
begin
--   Manifest
--     PAGE: 00017
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>6662355588643785590
,p_default_application_id=>214711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_RSWSP'
);
wwv_flow_imp_page.create_page(
 p_id=>17
,p_name=>'Account Settings'
,p_alias=>'ACCOUNT-SETTINGS'
,p_page_mode=>'MODAL'
,p_step_title=>'Account Settings'
,p_autocomplete_on_off=>'OFF'
,p_css_file_urls=>'#APP_FILES#Styling/main_style#MIN#.css'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#P17_CUS_TYPE_NAME_CONTAINER {',
'    background-color: var(--fouth-color);',
'    color: var(--first-color);',
'    border-radius: 10px;',
'}',
'',
'#P17_CUS_TYPE_NAME_LABEL {',
'    color: var(--first-color)',
'}',
'',
'.delete-account-confirm {',
'    min-width: 1000px !important;',
'    min-height: 80%;',
'    box-shadow: 4px 42px  79px -24px var(--danger-color);',
'    -webkit-box-shadow: 4px 42px  79px -24px var(--danger-color);',
'    -moz-box-shadow: 4px 42px  79px -24px var(--danger-color);',
'    border: 1px solid var(--danger-color);',
'}',
'',
'.password-popup {',
'    max-height: 200px !important;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_dialog_width=>'1200'
,p_protection_level=>'C'
,p_page_component_map=>'02'
,p_last_updated_by=>'PFE94053@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20230731153126'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(45470959919251498216)
,p_plug_name=>'Pages Sections'
,p_region_template_options=>'#DEFAULT#:t-TabsRegion-mod--fillLabels:t-TabsRegion-mod--simple:t-TabsRegion-mod--large'
,p_plug_template=>wwv_flow_imp.id(19471818692017504268)
,p_plug_display_sequence=>20
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(23090399668997298237)
,p_plug_name=>'Account Settings'
,p_parent_plug_id=>wwv_flow_imp.id(45470959919251498216)
,p_region_template_options=>'#DEFAULT#:margin-top-md'
,p_plug_template=>wwv_flow_imp.id(19471542261328504234)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT  customer_id,',
'        firstname,',
'        lastname,',
'        phone,',
'        email,',
'        address,',
'        c.city_id,',
'        ct.state_id,',
'        cust.cus_type_name',
'FROM customer c',
'LEFT JOIN cities ct ON c.city_id = ct.city_id',
'LEFT JOIN customer_type cust ON c.cus_type_id = cust.cus_type_id',
'WHERE customer_id = TO_NUMBER(:USER_ID);',
'',
''))
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(45470960830200498225)
,p_plug_name=>'Change Password'
,p_parent_plug_id=>wwv_flow_imp.id(45470959919251498216)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody:margin-top-md'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(45470961407164498231)
,p_plug_name=>'Delete Account'
,p_parent_plug_id=>wwv_flow_imp.id(45470959919251498216)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--textContent:t-Region--scrollBody:margin-top-md'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>50
,p_plug_display_point=>'SUB_REGIONS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(45470961701218498234)
,p_plug_name=>'Once you delete your account, there is no going back. Please be certain.'
,p_parent_plug_id=>wwv_flow_imp.id(45470961407164498231)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--textContent:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(45470961987241498236)
,p_plug_name=>'Account Deletion Action'
,p_parent_plug_id=>wwv_flow_imp.id(45470961407164498231)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader js-removeLandmark:t-Region--textContent:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(45586304058836686919)
,p_plug_name=>'Account Deletion Password'
,p_parent_plug_id=>wwv_flow_imp.id(45470961407164498231)
,p_region_css_classes=>'password-popup'
,p_region_template_options=>'#DEFAULT#:js-dialog-size600x400'
,p_plug_template=>wwv_flow_imp.id(19471593662015504257)
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(45470962084785498237)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(45470961987241498236)
,p_button_name=>'Delete_Account'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--danger:t-Button--iconLeft:t-Button--hoverIconPush:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(19471882117602504304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Delete Account'
,p_warn_on_unsaved_changes=>null
,p_button_css_classes=>'delete-account-btn'
,p_icon_css_classes=>'fa-radiation'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(45470961572228498232)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(45470960830200498225)
,p_button_name=>'Update_Password'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--success:t-Button--iconLeft:t-Button--hoverIconPush:t-Button--stretch:t-Button--gapTop'
,p_button_template_id=>wwv_flow_imp.id(19471882117602504304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Update Password'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-user-edit'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(45586304250372686921)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(45586304058836686919)
,p_button_name=>'Confirm_Password'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--danger:t-Button--stretch:t-Button--gapTop'
,p_button_template_id=>wwv_flow_imp.id(19471882000429504304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Confirm Password & Delete Account'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(45470961356725498230)
,p_button_sequence=>120
,p_button_plug_id=>wwv_flow_imp.id(23090399668997298237)
,p_button_name=>'Update_Account_Information'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--success:t-Button--iconLeft:t-Button--hoverIconPush:t-Button--stretch:t-Button--gapTop'
,p_button_template_id=>wwv_flow_imp.id(19471882117602504304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Update Account Information'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-user-edit'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(23091200737481298238)
,p_name=>'P17_FIRSTNAME'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(23090399668997298237)
,p_item_source_plug_id=>wwv_flow_imp.id(23090399668997298237)
,p_prompt=>'Firstname'
,p_source=>'FIRSTNAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>50
,p_field_template=>wwv_flow_imp.id(19471880312432504303)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(23091201135787298238)
,p_name=>'P17_LASTNAME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(23090399668997298237)
,p_item_source_plug_id=>wwv_flow_imp.id(23090399668997298237)
,p_prompt=>'Lastname'
,p_source=>'LASTNAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>50
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(19471880312432504303)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(23091201527232298239)
,p_name=>'P17_PHONE'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(23090399668997298237)
,p_item_source_plug_id=>wwv_flow_imp.id(23090399668997298237)
,p_prompt=>'Phone'
,p_source=>'PHONE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>50
,p_field_template=>wwv_flow_imp.id(19471880312432504303)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(23091201922365298239)
,p_name=>'P17_EMAIL'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(23090399668997298237)
,p_item_source_plug_id=>wwv_flow_imp.id(23090399668997298237)
,p_prompt=>'Email'
,p_source=>'EMAIL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>50
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(19471880312432504303)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(23091202398808298239)
,p_name=>'P17_ADDRESS'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(23090399668997298237)
,p_item_source_plug_id=>wwv_flow_imp.id(23090399668997298237)
,p_prompt=>'Address'
,p_source=>'ADDRESS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>50
,p_field_template=>wwv_flow_imp.id(19471880312432504303)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(23091202799126298239)
,p_name=>'P17_CITY_ID'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(23090399668997298237)
,p_item_source_plug_id=>wwv_flow_imp.id(23090399668997298237)
,p_item_default=>'P17_DEFAULT_CITY'
,p_item_default_type=>'ITEM'
,p_prompt=>'City'
,p_source=>'CITY_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT city_name, city_id ',
'FROM   cities',
'WHERE  state_id = :P17_STATE_ID'))
,p_lov_display_null=>'YES'
,p_lov_cascade_parent_items=>'P17_STATE_ID'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(19471880312432504303)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(45470960087711498217)
,p_name=>'P17_CUSTOMER_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(23090399668997298237)
,p_item_source_plug_id=>wwv_flow_imp.id(23090399668997298237)
,p_source=>'CUSTOMER_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(45470960967488498226)
,p_name=>'P17_OLD_PW'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(45470960830200498225)
,p_prompt=>'Enter Old Password'
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(19471880312432504303)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(45470961185551498228)
,p_name=>'P17_NEW_PW'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(45470960830200498225)
,p_prompt=>'Enter New Password'
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(19471880312432504303)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(45470961214957498229)
,p_name=>'P17_CONFIRM_NEW_PW'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(45470960830200498225)
,p_prompt=>'Confirm New Password'
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(19471880312432504303)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(45470962459167498241)
,p_name=>'P17_STATE_ID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(23090399668997298237)
,p_item_source_plug_id=>wwv_flow_imp.id(23090399668997298237)
,p_prompt=>'State '
,p_source=>'STATE_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select state_name, state_id from states'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(19471880312432504303)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(45470962640565498243)
,p_name=>'P17_DEFAULT_CITY'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(23090399668997298237)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(45470962779544498244)
,p_name=>'P17_DEFAULT_STATE'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(23090399668997298237)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(45586303169226686910)
,p_name=>'P17_ERROR_IN_PW'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(45470960830200498225)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(45586303533556686914)
,p_name=>'P17_LOGOUT_URL'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(45586304058836686919)
,p_item_default=>'&LOGOUT_URL.'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'U'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(45586304156117686920)
,p_name=>'P17_PASSWORD_FOR_DELETION'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(45586304058836686919)
,p_prompt=>'Please Enter You Password'
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(19471880312432504303)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(45586305069739686929)
,p_name=>'P17_CONFIRM_PW_ERROR'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(45586304058836686919)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(45586305998176686938)
,p_name=>'P17_REDIRECT_URL'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(45586304058836686919)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(45586306387959686942)
,p_name=>'P17_CUS_TYPE_NAME'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(23090399668997298237)
,p_prompt=>'Account Type'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(19471879438844504303)
,p_item_template_options=>'#DEFAULT#:margin-top-md:margin-bottom-md:margin-left-md:margin-right-md'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(45586302638072686905)
,p_validation_name=>'Validate Old Passowrd'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'RETURN VALIDATIONS.validate_pw (',
'    to_number(:USER_ID),',
'    :P17_OLD_PW',
');'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_associated_item=>wwv_flow_imp.id(45470960967488498226)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(45586302900179686908)
,p_validation_name=>'Validate Confirm Password'
,p_validation_sequence=>20
,p_validation=>':P17_NEW_PW = :P17_CONFIRM_NEW_PW'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'Passwords do not match !'
,p_associated_item=>wwv_flow_imp.id(45470961214957498229)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(45470960653744498223)
,p_name=>'Fetch Customer Data'
,p_event_sequence=>20
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(45470960747693498224)
,p_event_id=>wwv_flow_imp.id(45470960653744498223)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'MANAGE_CUSTOMERS.fetch_customer_data (',
'    to_number(:USER_ID),',
'    :P17_CUS_TYPE_NAME,',
'    :P17_FIRSTNAME,',
'    :P17_LASTNAME,',
'    :P17_PHONE,',
'    :P17_EMAIL,',
'    :P17_ADDRESS,',
'    :P17_DEFAULT_CITY,',
'    :P17_DEFAULT_STATE',
');'))
,p_attribute_03=>'P17_FIRSTNAME,P17_LASTNAME,P17_PHONE,P17_EMAIL,P17_ADDRESS,,P17_DEFAULT_CITY,P17_DEFAULT_STATE,P17_CUS_TYPE_NAME'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(45470962517032498242)
,p_event_id=>wwv_flow_imp.id(45470960653744498223)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$s("P17_STATE_ID", parseInt($v("P17_DEFAULT_STATE")))',
'$s("P17_CITY_ID", parseInt($v("P17_DEFAULT_CITY")))'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(45470962846571498245)
,p_name=>'Update Info'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(45470961356725498230)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(45470962997771498246)
,p_event_id=>wwv_flow_imp.id(45470962846571498245)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'MANAGE_CUSTOMERS.update_customer_general_info (',
'    to_number(:USER_ID),',
'    :P17_FIRSTNAME,',
'    :P17_LASTNAME,',
'    :P17_PHONE,',
'    :P17_EMAIL,',
'    :P17_ADDRESS,',
'    :P17_CITY_ID',
');',
''))
,p_attribute_02=>'P17_FIRSTNAME,P17_LASTNAME,P17_PHONE,P17_EMAIL,P17_ADDRESS,P17_CITY_ID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(45470963016093498247)
,p_event_id=>wwv_flow_imp.id(45470962846571498245)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.message.showPageSuccess( "Account Updated Successfully !" )'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(45470963136618498248)
,p_event_id=>wwv_flow_imp.id(45470962846571498245)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(23090399668997298237)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(45586302486533686903)
,p_name=>'Update Pw'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(45470961572228498232)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(45586303094948686909)
,p_event_id=>wwv_flow_imp.id(45586302486533686903)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    IF NOT VALIDATIONS.validate_pw (to_number(:USER_ID), :P17_OLD_PW) THEN',
'        :P17_ERROR_IN_PW := 1; -- Password Entered Incorrect ',
'    ELSIF NOT :P17_NEW_PW = :P17_CONFIRM_NEW_PW THEN',
'             apex_debug.info(p_message =>''Koen Debudasdasdasg: '');',
'            :P17_ERROR_IN_PW := 2; -- Password and confrim password don''t match ',
'    ELSE',
'        :P17_ERROR_IN_PW := 0;',
'        MANAGE_CUSTOMERS.update_pw (',
'            to_number(:USER_ID),',
'            :P17_NEW_PW',
'        );',
'    END IF;',
'END;'))
,p_attribute_02=>'P17_OLD_PW,P17_NEW_PW,P17_CONFIRM_NEW_PW'
,p_attribute_03=>'P17_ERROR_IN_PW'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(45586302706720686906)
,p_event_id=>wwv_flow_imp.id(45586302486533686903)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'console.log($v("P17_ERROR_IN_PW"))',
'if ($v("P17_ERROR_IN_PW") == 1) {',
'    apex.message.showErrors([',
'        {',
'            type:       "error",',
'            location:   "inline",',
'            pageItem:   "P17_OLD_PW",',
'            message:    "Password Is Incorrect!",',
'            unsafe:     false',
'        }',
'    ]);',
'    ',
'} else if ($v("P17_ERROR_IN_PW") == 2){',
'        apex.message.showErrors([',
'        {',
'            type:       "error",',
'            location:   "inline",',
'            pageItem:   "P17_CONFIRM_NEW_PW",',
'            message:    "Passwords Don''t macth!",',
'            unsafe:     false',
'        }',
'    ]);',
'} else {',
'    apex.message.showPageSuccess( ''Password Changed Successfully'' );',
'    $s("P17_OLD_PW" , "");',
'    $s("P17_NEW_PW" , "");',
'    $s("P17_CONFIRM_NEW_PW" , "");',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(45586303615780686915)
,p_name=>'Delete Account Initiation'
,p_event_sequence=>50
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(45470962084785498237)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(45586303769790686916)
,p_event_id=>wwv_flow_imp.id(45586303615780686915)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Are you sure you want to delete your account? Please take a moment to consider the consequences of this action :',
'<ul>',
'    <li>Data Loss: Deleting your account will result in the permanent loss of all your account information, including your profile, stores, products, and any associated data. This action cannot be undone, and you will not be able to recover your acco'
||'unt once it''s deleted.</li>',
'    <li>Loss of Access: By deleting your account, you will lose access to all the features and benefits of our platform. This includes any content you have created, messages, and any interaction history.</li>',
'    <li>Cancellations: Any active order associated with your account will be canceled.</li>',
'</ul>'))
,p_attribute_02=>'Are You Sure You Want To Delete Your Account'
,p_attribute_03=>'danger'
,p_attribute_04=>'fa-radiation'
,p_attribute_05=>'delete-confirm'
,p_attribute_06=>'Delete Account '
,p_attribute_07=>'Cancel'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(45586303930167686918)
,p_event_id=>wwv_flow_imp.id(45586303615780686915)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_OPEN_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(45586304058836686919)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(45586304429252686923)
,p_name=>'Delete_Account'
,p_event_sequence=>60
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(45470962084785498237)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(45586305316854686932)
,p_event_id=>wwv_flow_imp.id(45586304429252686923)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'console.log("SSSS")'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(45586304727236686926)
,p_name=>'Confirm Password'
,p_event_sequence=>70
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(45586304250372686921)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(45586304936647686928)
,p_event_id=>wwv_flow_imp.id(45586304727236686926)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    IF NOT VALIDATIONS.validate_pw (to_number(:USER_ID), :P17_PASSWORD_FOR_DELETION) THEN',
'        :P17_CONFIRM_PW_ERROR := 1; -- Password Entered Incorrect ',
'    ELSE',
'        :P17_CONFIRM_PW_ERROR := 0; -- Password Entered Is Correct  ',
'    END IF;',
'END;'))
,p_attribute_02=>'P17_PASSWORD_FOR_DELETION'
,p_attribute_03=>'P17_CONFIRM_PW_ERROR'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(45586305145396686930)
,p_event_id=>wwv_flow_imp.id(45586304727236686926)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($v("P17_CONFIRM_PW_ERROR") == 1){',
'        apex.message.showErrors([',
'        {',
'            type:       "error",',
'            location:   "inline",',
'            pageItem:   "P17_PASSWORD_FOR_DELETION",',
'            message:    "Passwords Is Incorrect !",',
'            unsafe:     false',
'        }',
'    ]);',
'}'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(45586304567377686924)
,p_event_id=>wwv_flow_imp.id(45586304727236686926)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    DELETE FROM customer WHERE customer_id = to_number(:USER_ID);',
'',
'    :P17_REDIRECT_URL := APEX_UTIL.PREPARE_URL(''f?p=&APP_ID.:1:0.::::'');',
'END;'))
,p_attribute_03=>'P17_REDIRECT_URL'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P17_CONFIRM_PW_ERROR'
,p_client_condition_expression=>'0'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(45586304637152686925)
,p_event_id=>wwv_flow_imp.id(45586304727236686926)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'console.log($v("P17_REDIRECT_URL"))',
'let url = $v("P17_REDIRECT_URL");',
'apex.page.cancelWarnOnUnsavedChanges();',
'apex.navigation.redirect(url);'))
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P17_CONFIRM_PW_ERROR'
,p_client_condition_expression=>'0'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(23091209973464298245)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(23090399668997298237)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form Account Settings'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>23091209973464298245
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(23091210364574298245)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>23091210364574298245
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(23091209590590298244)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(23090399668997298237)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Account Settings'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>23091209590590298244
);
wwv_flow_imp.component_end;
end;
/
