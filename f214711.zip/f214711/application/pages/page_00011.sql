prompt --application/pages/page_00011
begin
--   Manifest
--     PAGE: 00011
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>6662355588643785590
,p_default_application_id=>214711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_RSWSP'
);
wwv_flow_imp_page.create_page(
 p_id=>11
,p_name=>'product_cat_store'
,p_alias=>'PRODUCT-CAT-STORE'
,p_step_title=>'product_cat_store'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(22381695668883954033)
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'23'
,p_last_updated_by=>'PFE94053@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20230711194752'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(56936756937681157022)
,p_plug_name=>'products '
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--styleA'
,p_plug_template=>wwv_flow_imp.id(19471549395551504237)
,p_plug_display_sequence=>40
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT  p.product_id,',
'        p.product_name,',
'        p.product_description,',
'        p.unit_price,',
'        discount,',
'        NEW_PRICE (P.PRODUCT_ID) new_price,',
'        p.store_id,',
'        pi.image',
'FROM    product p',
'        join (SELECT image_id,',
'            product_id,',
'            image',
'            FROM(SELECT image_id,',
'                        product_id,',
'                        image,',
'                        Row_number()',
'                            over (',
'                            PARTITION BY product_id',
'                            ORDER BY image_id) AS rn',
'                FROM   product_images) img',
'                WHERE  rn = 1) pi',
'        ON p.product_id = pi.product_id',
'WHERE  category_id = :P11_CATEG_ID',
'AND store_id = :P11_STORE_ID;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_ajax_items_to_submit=>'P11_CATEG_ID,P11_STORE_ID'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
,p_pagination_display_position=>'BOTTOM_RIGHT'
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(35049655811200629306)
,p_region_id=>wwv_flow_imp.id(56936756937681157022)
,p_layout_type=>'GRID'
,p_grid_column_count=>5
,p_card_css_classes=>'card'
,p_title_adv_formatting=>false
,p_title_column_name=>'PRODUCT_NAME'
,p_sub_title_adv_formatting=>true
,p_sub_title_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<small>&STORE_ID_L$2.</small><br />',
'<b id="message_&PRODUCT_ID." class="u-success-text u-pullRight">',
'{if QUANTITY/} &QUANTITY. in cart {endif/}',
'</b>',
'<b>$&UNIT_PRICE.</b>'))
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_media_adv_formatting=>false
,p_media_source_type=>'BLOB'
,p_media_blob_column_name=>'IMAGE'
,p_media_display_position=>'FIRST'
,p_media_appearance=>'WIDESCREEN'
,p_media_sizing=>'FIT'
,p_pk1_column_name=>'PRODUCT_ID'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(35049656274586629307)
,p_card_id=>wwv_flow_imp.id(35049655811200629306)
,p_action_type=>'FULL_CARD'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:18:&SESSION.::&DEBUG.:18:P18_PRODUCT_ID:&PRODUCT_ID.'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(37171145815280069214)
,p_card_id=>wwv_flow_imp.id(35049655811200629306)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>20
,p_label=>'wishlist'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'javascript:void(null);'
,p_link_attributes=>'data-id=&PRODUCT_ID.'
,p_button_display_type=>'ICON'
,p_icon_css_classes=>'fa-heart'
,p_action_css_classes=>'heart'
,p_is_hot=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(37171145926429069215)
,p_card_id=>wwv_flow_imp.id(35049655811200629306)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>30
,p_label=>'Add to cart'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:6:P6_PRODUCT_ID,P6_PRICE,P6_QUNATITY:&PRODUCT_ID.,&NEW_PRICE.,1'
,p_button_display_type=>'TEXT_WITH_ICON'
,p_icon_css_classes=>'fa-plus-square'
,p_is_hot=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(34598050261374261117)
,p_name=>'P11_STORE_ID'
,p_item_sequence=>60
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(57001231876180620321)
,p_name=>'P11_CATEG_ID'
,p_item_sequence=>50
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(35049658290460629314)
,p_name=>'Update Shopping Cart Header'
,p_event_sequence=>20
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(56936756937681157022)
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'parseInt(this.data.SHOPPING_CART_ITEMS) > 0'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(35049658716919629315)
,p_event_id=>wwv_flow_imp.id(35049658290460629314)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// Update Badge Text',
'apex.jQuery(".js-shopping-cart-item .t-Button-badge").text(this.data.SHOPPING_CART_ITEMS);',
'',
'// Update Icon',
'apex.jQuery(".js-shopping-cart-item .t-Icon").removeClass(''fa-cart-empty'').addClass(''fa-cart-full'');'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(35049659212679629315)
,p_event_id=>wwv_flow_imp.id(35049658290460629314)
,p_event_result=>'FALSE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// Update Badge Text',
'apex.jQuery(".js-shopping-cart-item .t-Button-badge").text('''');',
'',
'// Update Icon',
'apex.jQuery(".js-shopping-cart-item .t-Icon").removeClass(''fa-cart-full'').addClass(''fa-cart-empty'');'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(38275863391429217704)
,p_name=>'wishlist'
,p_event_sequence=>30
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.heart'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_display_when_type=>'EXPRESSION'
,p_display_when_cond=>'APEX_AUTHENTICATION.IS_AUTHENTICATED'
,p_display_when_cond2=>'PLSQL'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(38275864203538217705)
,p_event_id=>wwv_flow_imp.id(38275863391429217704)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_name=>'set value'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P11_PRODUCT_ID'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'$(this.triggeringElement).data(''id'')'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(38275863724485217704)
,p_event_id=>wwv_flow_imp.id(38275863391429217704)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'console.log($v(''P11_PRODUCT_ID''))'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(38275864730667217705)
,p_event_id=>wwv_flow_imp.id(38275863391429217704)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_name=>'add_wishlist'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'  IF APEX_AUTHENTICATION.IS_AUTHENTICATED THEN',
'    ADD_TO_WISHLIST.ADD_PRODUCT(:P18_PRODUCT_ID, to_number(:USER_ID));',
'  ELSE',
'    apex_error.add_error (',
'      p_message => ''Login first to unlock this action.'',',
'      p_display_location => apex_error.c_inline_in_notification',
'    );',
'  END IF;',
'END;',
''))
,p_attribute_02=>'P11_PRODUCT_ID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(38275865277168217705)
,p_event_id=>wwv_flow_imp.id(38275863391429217704)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.message.showPageSuccess( ''Product added to wishlist'' );'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(38276144361597500671)
,p_name=>'wishlist_error'
,p_event_sequence=>40
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.heart'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_display_when_type=>'EXPRESSION'
,p_display_when_cond=>'not APEX_AUTHENTICATION.IS_AUTHENTICATED'
,p_display_when_cond2=>'PLSQL'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(38276144754501500672)
,p_event_id=>wwv_flow_imp.id(38276144361597500671)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.message.showErrors([',
'    {',
'        type:       "error",',
'        location:   [ "page" ],',
'        message:    "You Must Be Authenticated Before Adding Product To Wishlist !",',
'        unsafe:     false',
'    }',
']);',
''))
);
wwv_flow_imp.component_end;
end;
/
