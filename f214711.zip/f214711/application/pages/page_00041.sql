prompt --application/pages/page_00041
begin
--   Manifest
--     PAGE: 00041
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>6662355588643785590
,p_default_application_id=>214711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_RSWSP'
);
wwv_flow_imp_page.create_page(
 p_id=>41
,p_name=>'Add Product Variant'
,p_alias=>'ADD-PRODUCT-VARIANT'
,p_page_mode=>'MODAL'
,p_step_title=>'Add Product Variant'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'#APP_FILES#scripts/main#MIN#.js'
,p_css_file_urls=>'#APP_FILES#Styling/main_style#MIN#.css'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.create-variant-form {',
'    border-top: 1px solid black;',
'    border-radius: 0;',
'    padding: 20px;',
'}',
'',
'',
'#R58676774746267695574_heading {',
'    text-align: center;',
'    font-family: var(--secondary-header-font);',
'    text-decoration: underline;',
'}',
'',
'.fa-unlock-alt {',
'    cursor: pointer;',
'}',
'',
'.lock-item{',
'    position: absolute;',
'    left: 80%;',
'    top: 43% ;',
'}'))
,p_step_template=>wwv_flow_imp.id(19471535469231504230)
,p_page_template_options=>'#DEFAULT#'
,p_dialog_width=>'900'
,p_protection_level=>'C'
,p_page_component_map=>'16'
,p_last_updated_by=>'PFE94053@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20230801221430'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(29468445003475824639)
,p_plug_name=>'Wizard Progress'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(19471542261328504234)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_list_id=>wwv_flow_imp.id(29468439894855824633)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(19471877875421504302)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(29468445270768824639)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(19471545059842504235)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(58676774746267695574)
,p_plug_name=>'Create Variants For &P41_PRODUCT_NAME.'
,p_region_css_classes=>'create-variant-form'
,p_region_template_options=>'#DEFAULT#:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>70
,p_query_type=>'TABLE'
,p_query_table=>'VARIANT_STOCK'
,p_include_rowid_column=>false
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(42153518123779704849)
,p_plug_name=>'variant_2'
,p_parent_plug_id=>wwv_flow_imp.id(58676774746267695574)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--textContent:t-Region--hiddenOverflow'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>60
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>4
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(42153518289637704850)
,p_plug_name=>'variant_3'
,p_parent_plug_id=>wwv_flow_imp.id(58676774746267695574)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--textContent:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>70
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>4
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(84524944582702999672)
,p_plug_name=>'variant_1'
,p_parent_plug_id=>wwv_flow_imp.id(58676774746267695574)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--textContent:t-Region--hiddenOverflow'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>50
,p_plug_grid_column_span=>4
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(42374005691800189303)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(42153518289637704850)
,p_button_name=>'lock_variant_3'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--tiny:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(19471881378436504304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Lock'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-unlock-alt'
,p_grid_column_css_classes=>'lock-item'
,p_grid_new_row=>'Y'
,p_grid_column_span=>1
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(42371427008227294829)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(84524944582702999672)
,p_button_name=>'lock_variant_1'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--tiny:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(19471881378436504304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Lock Variant 1'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-unlock-alt'
,p_grid_column_css_classes=>'lock-item'
,p_grid_new_row=>'Y'
,p_grid_column_span=>1
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(42374005518086189302)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(42153518123779704849)
,p_button_name=>'lock_variant_2'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--tiny:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(19471881378436504304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Lock'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-unlock-alt'
,p_grid_column_css_classes=>'lock-item'
,p_grid_new_row=>'Y'
,p_grid_column_span=>1
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(29469992360214864950)
,p_button_sequence=>130
,p_button_plug_id=>wwv_flow_imp.id(58676774746267695574)
,p_button_name=>'Add_Variant'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(19471882000429504304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add Variant'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(29468446792401824640)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(29468445270768824639)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(19471882000429504304)
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(29468447048246824640)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(29468445270768824639)
,p_button_name=>'NEXT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(19471882117602504304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add Prdouct Images'
,p_button_position=>'NEXT'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(29468446925441824640)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(29468445270768824639)
,p_button_name=>'PREVIOUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(19471881378436504304)
,p_button_image_alt=>'Previous'
,p_button_position=>'PREVIOUS'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(29468449398209824641)
,p_branch_name=>'Go To Page 42'
,p_branch_action=>'f?p=&APP_ID.:42:&SESSION.::&DEBUG.:42:P42_PRODUCT_ID:&P41_PRODUCT_ID.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(29468447048246824640)
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(29468448698797824641)
,p_branch_name=>'Go To Page 40'
,p_branch_action=>'f?p=&APP_ID.:40:&SESSION.:40:&DEBUG.::P40_PRODUCT_ID:&P41_PRODUCT_ID.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_VALIDATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(29468446925441824640)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(29218968320832353743)
,p_name=>'P41_PRODUCT_ID'
,p_item_sequence=>10
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(29218968443925353744)
,p_name=>'P41_CATEGORY_ID'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(29218968774199353747)
,p_name=>'P41_VARIANT_1_NAME'
,p_item_sequence=>40
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(29218968897900353748)
,p_name=>'P41_VARIANT_2_NAME'
,p_item_sequence=>50
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(29218968914815353749)
,p_name=>'P41_VARIANT_3_NAME'
,p_item_sequence=>60
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(29472288022964419319)
,p_name=>'P41_PRODUCT_NAME'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(42153517132679704839)
,p_name=>'P41_VARIANT_1_LOCKED'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(58676774746267695574)
,p_item_default=>'0'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(42153517209036704840)
,p_name=>'P41_VARIANT_2_LOCKED'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(58676774746267695574)
,p_item_default=>'0'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(42153517350375704841)
,p_name=>'P41_VARIANT_3_LOCKED'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(58676774746267695574)
,p_item_default=>'0'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(42374005436532189301)
,p_name=>'P41_VARIANT_2'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(42153518123779704849)
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(19471880312432504303)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(42374005809132189305)
,p_name=>'P41_VARIANT_3'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(42153518289637704850)
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(19471880312432504303)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(58688957030174218653)
,p_name=>'P41_STOCK_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(58676774746267695574)
,p_item_source_plug_id=>wwv_flow_imp.id(58676774746267695574)
,p_source=>'STOCK_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'I'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(58688957212504218655)
,p_name=>'P41_STOCK_QUANTITY'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(58676774746267695574)
,p_item_source_plug_id=>wwv_flow_imp.id(58676774746267695574)
,p_prompt=>'Stock Quantity'
,p_source=>'STOCK_QUANTITY'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(19471879586967504303)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(84524945408759999676)
,p_name=>'P41_VARIANT_1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(84524944582702999672)
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(19471880312432504303)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(29468447101847824640)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(29468446792401824640)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(46538611817871172002)
,p_event_id=>wwv_flow_imp.id(29468447101847824640)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- DELETING THE PRODUCT IN CASE OF CANCEL',
'DELETE FROM product WHERE product_id = :P41_PRODUCT_ID; '))
,p_attribute_02=>'P41_PRODUCT_ID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(29468447973078824640)
,p_event_id=>wwv_flow_imp.id(29468447101847824640)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(29218968575213353745)
,p_name=>'Add Variant To Database'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(29469992360214864950)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(29472286492191419303)
,p_event_id=>wwv_flow_imp.id(29218968575213353745)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_count number := 0;',
'BEGIN',
'    SELECT count(*)',
'    INTO l_count',
'    FROM variant_stock',
'    WHERE product_id = :P41_PRODUCT_ID',
'          AND variant_1 = :P41_VARIANT_1',
'          AND variant_2 = :P41_VARIANT_2',
'          AND variant_3 = :P41_VARIANT_3;',
'',
'    IF l_count > 0 THEN',
'        UPDATE ',
'            variant_stock ',
'        SET  ',
'            stock_quantity = stock_quantity + :P41_STOCK_QUANTITY ',
'        WHERE product_id = :P41_PRODUCT_ID',
'            AND variant_1 = :P41_VARIANT_1',
'            AND variant_2 = :P41_VARIANT_2',
'            AND variant_3 = :P41_VARIANT_3;    ',
'            ',
'    ELSE',
'        INSERT INTO variant_stock (product_id, variant_1, variant_2, variant_3, stock_quantity)',
'        VALUES(',
'            :P41_PRODUCT_ID,',
'            :P41_VARIANT_1,',
'            :P41_VARIANT_2,',
'            :P41_VARIANT_3,',
'            :P41_STOCK_QUANTITY',
'        );',
'    END IF;',
'END;'))
,p_attribute_02=>'P41_PRODUCT_ID,P41_STOCK_QUANTITY,P41_VARIANT_1,P41_VARIANT_2,P41_VARIANT_3'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(46538612091759172004)
,p_event_id=>wwv_flow_imp.id(29218968575213353745)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'show_notification0("Variants Added Successfully !")'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(29472286568159419304)
,p_event_id=>wwv_flow_imp.id(29218968575213353745)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_name=>'Clear items'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'const variantFields = ["VARIANT_1", "VARIANT_2", "VARIANT_3"];',
'',
'for (const variant of variantFields) {',
'  if ($v(`P41_${variant}_LOCKED`) == 0) {',
'    $s(`P41_${variant}`, null);',
'  }',
'}',
'',
'$s("P41_STOCK_QUANTITY", null);',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(29218969087639353750)
,p_name=>'Get Variants Name '
,p_event_sequence=>30
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(29472286245930419301)
,p_event_id=>wwv_flow_imp.id(29218969087639353750)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'MANAGE_PRODUCTS.get_variants(',
'    :P41_CATEGORY_ID,',
'    :P41_VARIANT_1_NAME,',
'    :P41_VARIANT_2_NAME,',
'    :P41_VARIANT_3_NAME',
');'))
,p_attribute_02=>'P41_CATEGORY_ID'
,p_attribute_03=>'P41_VARIANT_1_NAME,P41_VARIANT_2_NAME,P41_VARIANT_3_NAME'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(29472286942580419308)
,p_event_id=>wwv_flow_imp.id(29218969087639353750)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$("label[for=P41_VARIANT_1]").text($v("P41_VARIANT_1_NAME"));',
'$("label[for=P41_VARIANT_2]").text($v("P41_VARIANT_2_NAME"));',
'$("label[for=P41_VARIANT_3]").text($v("P41_VARIANT_3_NAME"));'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(42153517476416704842)
,p_name=>'Lock Variant 1'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(42371427008227294829)
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(42153517550744704843)
,p_event_id=>wwv_flow_imp.id(42153517476416704842)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P41_VARIANT_1_LOCKED'
,p_attribute_01=>'FUNCTION_BODY'
,p_attribute_06=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN ',
'    IF :P41_VARIANT_1_LOCKED = 1 THEN',
'        RETURN 0;',
'    ELSIF :P41_VARIANT_1_LOCKED = 0 THEN',
'        RETURN 1;',
'    END IF;',
'END;'))
,p_attribute_07=>'P41_VARIANT_1_LOCKED'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(42374006871486189315)
,p_event_id=>wwv_flow_imp.id(42153517476416704842)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if($v("P41_VARIANT_1_LOCKED") == 1) {',
'    $(this.triggeringElement).find(".t-Icon").removeClass("fa-unlock-alt").addClass("fa-lock")',
'}else {',
'    $(this.triggeringElement).find(".t-Icon").removeClass("fa-lock").addClass("fa-unlock-alt ")',
'}',
'',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(42374006004678189307)
,p_name=>'Lock Variant 2'
,p_event_sequence=>50
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(42374005518086189302)
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(42374006117916189308)
,p_event_id=>wwv_flow_imp.id(42374006004678189307)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P41_VARIANT_2_LOCKED'
,p_attribute_01=>'FUNCTION_BODY'
,p_attribute_06=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN ',
'    IF :P41_VARIANT_2_LOCKED = 1 THEN',
'        RETURN 0;',
'    ELSIF :P41_VARIANT_2_LOCKED = 0 THEN',
'        RETURN 1;',
'    END IF;',
'END;'))
,p_attribute_07=>'P41_VARIANT_2_LOCKED'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(42374006702262189314)
,p_event_id=>wwv_flow_imp.id(42374006004678189307)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if($v("P41_VARIANT_2_LOCKED") == 1) {',
'    $(this.triggeringElement).find(".t-Icon").removeClass("fa-unlock-alt").addClass("fa-lock")',
'}else {',
'    $(this.triggeringElement).find(".t-Icon").removeClass("fa-lock").addClass("fa-unlock-alt ")',
'}',
'',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(42374006268323189309)
,p_name=>'Lock Variant 3'
,p_event_sequence=>60
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(42374005691800189303)
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(42374006309693189310)
,p_event_id=>wwv_flow_imp.id(42374006268323189309)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P41_VARIANT_3_LOCKED'
,p_attribute_01=>'FUNCTION_BODY'
,p_attribute_06=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN ',
'    IF :P41_VARIANT_3_LOCKED = 1 THEN',
'        RETURN 0;',
'    ELSIF :P41_VARIANT_3_LOCKED = 0 THEN',
'        RETURN 1;',
'    END IF;',
'END;'))
,p_attribute_07=>'P41_VARIANT_3_LOCKED'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(42374006408490189311)
,p_event_id=>wwv_flow_imp.id(42374006268323189309)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if($v("P41_VARIANT_3_LOCKED") == 1) {',
'    $(this.triggeringElement).find(".t-Icon").removeClass("fa-unlock-alt").addClass("fa-lock")',
'}else {',
'    $(this.triggeringElement).find(".t-Icon").removeClass("fa-lock").addClass("fa-unlock-alt ")',
'}',
'',
''))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(29472287935094419318)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Check if at least one variant exists'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_var_num number;',
'BEGIN',
'    SELECT count(*)',
'    INTO l_var_num',
'    FROM variant_stock',
'    WHERE product_id = :P41_PRODUCT_ID;',
'',
'    IF l_var_num = 0 THEN',
'        apex_error.add_error(',
'            p_message=> ''At least one variant per product is needed !'',',
'            p_display_location => apex_error.c_inline_in_notification',
'    );',
'',
'    END IF;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(29468447048246824640)
,p_internal_uid=>29472287935094419318
);
wwv_flow_imp.component_end;
end;
/
