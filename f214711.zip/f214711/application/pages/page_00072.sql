prompt --application/pages/page_00072
begin
--   Manifest
--     PAGE: 00072
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>6662355588643785590
,p_default_application_id=>214711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_RSWSP'
);
wwv_flow_imp_page.create_page(
 p_id=>72
,p_name=>'Seller Dashboard Products'
,p_alias=>'SELLER-DASHBOARD-PRODUCTS'
,p_step_title=>'Seller Dashboard Products'
,p_autocomplete_on_off=>'OFF'
,p_css_file_urls=>'#APP_FILES#Styling/main_style#MIN#.css'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.overview {',
'    border-left: 10px solid var(--fouth-color);',
'    border-radius: 10px;',
'    padding-left: 10px;',
'    text-align: center;',
'}',
'',
'',
'.overview-title {',
'    color: var(--fouth-color);',
'    font-family: var(--secondary-header-font);',
'    border-bottom: 1px solid rgba(211, 211, 211, 0.5);',
'    padding: 2px;',
'    text-align: center;',
'    ',
'}',
'',
'.overview-data {',
'    font-family: var(--regular-text-font );',
'}',
'',
'.overview-data-prod > span {',
'    font-size: xx-small;',
'    opacity: 0.6;',
'}',
'',
'.overview-data-prod {',
'    font-family: var(--regular-text-font );',
'    display: flex;',
'    flex-direction: column;',
'}',
'',
'.t-Report-colHead {',
'    font-family: var(--secondary-header-font);',
'}',
'',
'.t-Report-cell {',
'    font-family: var(--regular-text-font);',
'}',
'',
'.t-Report-cell > img{',
'    width: 100px !important;',
'    height: 100px !important;',
'    object-fit: contain;',
'    border-radius: 12px;',
'}',
'',
'.delete-prod {',
'    color: var(--danger-color);',
'}',
'',
'.edit-prod {',
'    color: var(--yellow-color);',
'}'))
,p_step_template=>wwv_flow_imp.id(19471509145742504218)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'25'
,p_last_updated_by=>'PFE94053@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20230724125922'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38242827239696699949)
,p_plug_name=>'Seller Dashboard Navigation'
,p_region_css_classes=>'dashboard-side-menu'
,p_region_sub_css_classes=>'dashboard-side-menu-list'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-LinksList--showArrow:t-LinksList--nowrap:t-LinksList--actions:t-LinksList--showTopIcons'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_02'
,p_list_id=>wwv_flow_imp.id(38784043417088031374)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(19471863408174504294)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(39512635438552030922)
,p_plug_name=>'Products Summary'
,p_region_template_options=>'#DEFAULT#:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>10
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(39512635504377030923)
,p_plug_name=>'Most Expensive Product'
,p_region_name=>'overview-item-1'
,p_parent_plug_id=>wwv_flow_imp.id(39512635438552030922)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>4
,p_plug_display_point=>'SUB_REGIONS'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    current_product_name product.product_name%TYPE;',
'    current_product_price product.unit_price%TYPE;',
'    most_expensive_product_name product.product_name%TYPE;',
'    most_expensive_product_price product.unit_price%TYPE := 0;',
'',
'    cursor product_cursor is',
'        select product_name, new_price(product_id) ',
'            into most_expensive_product_name, most_expensive_product_price',
'            from product p, stores s',
'            where p.store_id = s.store_id',
'            and s.customer_id = to_number(:USER_ID);',
'begin',
'',
'    open product_cursor;',
'    loop',
'        fetch product_cursor into current_product_name, current_product_price;',
'        exit when product_cursor%notfound; ',
'',
'        if current_product_price > most_expensive_product_price then ',
'            most_expensive_product_name := current_product_name;',
'            most_expensive_product_price := current_product_price;',
'        end if;',
'    end loop;',
'    close product_cursor;',
'',
'    return ',
'        ''<div class="overview">',
'        <h3 class="overview-title"> Most Expensive Product </h3>',
'        <h4 class="overview-data-prod">'' || most_expensive_product_name || '' <span> Price '' || most_expensive_product_price || '' TND </span>',
'        </h4>',
'        </div> '';',
'end;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(39512635757715030925)
,p_plug_name=>'Product By Category'
,p_region_name=>'chart-1'
,p_region_template_options=>'#DEFAULT#:t-Region--stacked:t-Region--scrollBody:margin-top-md:margin-bottom-md'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>20
,p_plug_grid_column_span=>4
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(39512635836395030926)
,p_region_id=>wwv_flow_imp.id(39512635757715030925)
,p_chart_type=>'pie'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_value_format_type=>'decimal'
,p_value_decimal_places=>0
,p_value_format_scaling=>'none'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>false
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_legend_font_family=>'Courier New'
,p_legend_font_style=>'italic'
,p_legend_font_size=>'10'
,p_legend_font_color=>'#3a3632'
,p_pie_other_threshold=>0
,p_pie_selection_effect=>'highlight'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function modifyOptions(options) {',
'    const colors = ["#3A3632", "#FFB929", "#497620", "#F0E68C", "#00bcd4" , "#8e24aa", "#795548", "#C33522"];',
'    options.dataFilter = function (data) {',
'        for (var i = 0; i < data.series.length; i++) {',
'        data.series[i].color = colors[i]',
'        }',
'',
'        return data;',
'    };',
'',
'    return options;',
'}',
''))
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(39512635939108030927)
,p_chart_id=>wwv_flow_imp.id(39512635836395030926)
,p_seq=>10
,p_name=>'Series 1'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT category_name, count(product_id)',
'FROM categories c, product p, stores s',
'WHERE c.category_id = p.category_id',
'AND p.store_id = s.store_id',
'AND s.customer_id = to_number(:USER_ID)',
'GROUP BY category_name'))
,p_items_value_column_name=>'COUNT(PRODUCT_ID)'
,p_items_label_column_name=>'CATEGORY_NAME'
,p_items_label_rendered=>true
,p_items_label_position=>'outsideSlice'
,p_items_label_display_as=>'COMBO'
,p_items_label_font_family=>'Courier New'
,p_items_label_font_style=>'italic'
,p_items_label_font_size=>'10'
,p_items_label_font_color=>'#3a3632'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(39512637606792030944)
,p_name=>'My Products'
,p_region_name=>'prod-list'
,p_template=>wwv_flow_imp.id(19471808805460504264)
,p_display_sequence=>50
,p_region_css_classes=>'my-products-report'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--altRowsDefault:t-Report--rowHighlight:t-Report--inline:t-Report--hideNoPagination'
,p_grid_row_css_classes=>'products-row'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT  P.PRODUCT_ID,',
'        PRODUCT_NAME,',
'        PRODUCT_DESCRIPTION,',
'        NEW_PRICE(P.PRODUCT_ID) || '' TND'' PRICE,',
'        P.DISCOUNT || ''%'' DISCOUNT,',
'        S.STORE_NAME,',
'        C.CATEGORY_NAME, ',
'        SYS.DBMS_LOB.GETLENGTH(IMAGE) IMAGE, ',
'        GET_STOCK (P.PRODUCT_ID) STOCK,',
'        ''Edit Product'' ,',
'        ''Remove Product'' Del ',
'FROM PRODUCT P, PRODUCT_IMAGES D, STORES S, CATEGORIES C ',
' WHERE  P.PRODUCT_ID = D.PRODUCT_ID',
'    AND P.CATEGORY_ID = C.CATEGORY_ID',
'    AND P.STORE_ID = S.STORE_ID',
'    AND S.CUSTOMER_ID = to_number(:USER_ID)'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>true
,p_query_row_template=>wwv_flow_imp.id(19471847069031504283)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'No Products Yet ! '
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(40021823791946182107)
,p_query_column_id=>1
,p_column_alias=>'PRODUCT_ID'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(40021823896465182108)
,p_query_column_id=>2
,p_column_alias=>'PRODUCT_NAME'
,p_column_display_sequence=>30
,p_column_heading=>'Product Name'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(40021824807121182118)
,p_query_column_id=>3
,p_column_alias=>'PRODUCT_DESCRIPTION'
,p_column_display_sequence=>40
,p_column_heading=>'Product Description'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(40021823959074182109)
,p_query_column_id=>4
,p_column_alias=>'PRICE'
,p_column_display_sequence=>50
,p_column_heading=>'Unit Price'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(40021824027994182110)
,p_query_column_id=>5
,p_column_alias=>'DISCOUNT'
,p_column_display_sequence=>60
,p_column_heading=>'Discount'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(40021824164169182111)
,p_query_column_id=>6
,p_column_alias=>'STORE_NAME'
,p_column_display_sequence=>70
,p_column_heading=>'Store Name'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(40021824299742182112)
,p_query_column_id=>7
,p_column_alias=>'CATEGORY_NAME'
,p_column_display_sequence=>80
,p_column_heading=>'Category Name'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(40021824367087182113)
,p_query_column_id=>8
,p_column_alias=>'IMAGE'
,p_column_display_sequence=>20
,p_column_heading=>'Product Image'
,p_use_as_row_header=>'N'
,p_column_format=>'IMAGE:PRODUCT_IMAGES:IMAGE:PRODUCT_ID::::::::'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(40021824402108182114)
,p_query_column_id=>9
,p_column_alias=>'STOCK'
,p_column_display_sequence=>90
,p_column_heading=>'Stock'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(40021824768979182117)
,p_query_column_id=>10
,p_column_alias=>'''EDITPRODUCT'''
,p_column_display_sequence=>100
,p_column_heading=>'Edit Product'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:60:&SESSION.::&DEBUG.:60:P60_PRODUCT_ID:#PRODUCT_ID#'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(40021824569620182115)
,p_query_column_id=>11
,p_column_alias=>'DEL'
,p_column_display_sequence=>110
,p_column_heading=>'Remove Product'
,p_use_as_row_header=>'N'
,p_column_link=>'javascript:void(null)'
,p_column_linktext=>'<span class="t-Icon fa fa-trash delete-prod" aria-hidden="true"></span>'
,p_column_link_attr=>'data-id=#PRODUCT_ID#'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(40021824910701182119)
,p_plug_name=>'Discount Analysis'
,p_region_name=>'chart-2'
,p_region_template_options=>'#DEFAULT#:t-Region--stacked:t-Region--scrollBody:margin-top-md:margin-bottom-md'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>4
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(40021825081711182120)
,p_region_id=>wwv_flow_imp.id(40021824910701182119)
,p_chart_type=>'pie'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_value_format_type=>'decimal'
,p_value_decimal_places=>0
,p_value_format_scaling=>'none'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>false
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_legend_font_family=>'Courier New'
,p_legend_font_style=>'italic'
,p_legend_font_size=>'10'
,p_legend_font_color=>'#3a3632'
,p_pie_other_threshold=>0
,p_pie_selection_effect=>'highlightAndExplode'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function modifyOptions(options) {',
'    const colors = ["#3A3632", "#FFB929", "#497620", "#F0E68C", "#00bcd4" , "#8e24aa", "#795548", "#C33522"];',
'    options.dataFilter = function (data) {',
'        for (var i = 0; i < data.series.length; i++) {',
'        data.series[i].color = colors[i]',
'        }',
'',
'        return data;',
'    };',
'',
'    return options;',
'}',
''))
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(40021825125573182121)
,p_chart_id=>wwv_flow_imp.id(40021825081711182120)
,p_seq=>10
,p_name=>'Series 1'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT  discount || ''%'', count(product_id)',
'FROM    stores s, product p',
'WHERE   s.store_id = p.store_id',
'AND     s.customer_id = to_number(:USER_ID)',
'GROUP BY discount'))
,p_items_value_column_name=>'COUNT(PRODUCT_ID)'
,p_items_label_column_name=>'DISCOUNT||''%'''
,p_items_short_desc_column_name=>'COUNT(PRODUCT_ID)'
,p_items_label_rendered=>true
,p_items_label_position=>'outsideSlice'
,p_items_label_display_as=>'COMBO'
,p_items_label_font_family=>'Courier New'
,p_items_label_font_style=>'italic'
,p_items_label_font_size=>'10'
,p_items_label_font_color=>'#3a3632'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(40021825408229182124)
,p_plug_name=>'Product Stock Status Distribution'
,p_region_name=>'chart-3'
,p_region_template_options=>'#DEFAULT#:t-Region--stacked:t-Region--scrollBody:margin-top-md:margin-bottom-md'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(40021825556971182125)
,p_region_id=>wwv_flow_imp.id(40021825408229182124)
,p_chart_type=>'donut'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_value_format_type=>'decimal'
,p_value_decimal_places=>0
,p_value_format_scaling=>'none'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_legend_font_family=>'Courier New'
,p_legend_font_style=>'italic'
,p_legend_font_size=>'10'
,p_legend_font_color=>'#3a3632'
,p_pie_other_threshold=>0
,p_pie_selection_effect=>'highlight'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function modifyOptions(options) {',
'    const colors = ["#FFB929", "#3A3632", "#497620", "#F0E68C", "#00bcd4" , "#8e24aa", "#795548", "#C33522"];',
'    options.dataFilter = function (data) {',
'        for (var i = 0; i < data.series.length; i++) {',
'        data.series[i].color = colors[i]',
'        }',
'',
'        return data;',
'    };',
'',
'    return options;',
'}',
''))
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(40021825635624182126)
,p_chart_id=>wwv_flow_imp.id(40021825556971182125)
,p_seq=>10
,p_name=>'Series 1'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    CASE WHEN GET_STOCK(product_id) = ''In Stock'' THEN ''In Stock'' ELSE ''Out of Stock'' END AS stock_status,',
'    COUNT(*) AS product_count',
'FROM variant_stock',
'GROUP BY CASE WHEN GET_STOCK(product_id) = ''In Stock'' THEN ''In Stock'' ELSE ''Out of Stock'' END;',
'',
''))
,p_items_value_column_name=>'PRODUCT_COUNT'
,p_items_label_column_name=>'STOCK_STATUS'
,p_items_label_rendered=>true
,p_items_label_position=>'outsideSlice'
,p_items_label_display_as=>'ALL'
,p_items_label_font_family=>'Courier New'
,p_items_label_font_style=>'italic'
,p_items_label_font_size=>'10'
,p_items_label_font_color=>'#3a3632'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(40021825950811182129)
,p_name=>'P72_FILTER'
,p_item_sequence=>60
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41154316597474227814)
,p_name=>'P72_PROD_TO_DELETE'
,p_item_sequence=>70
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(41154316280268227811)
,p_name=>'Delete Product'
,p_event_sequence=>10
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.delete-prod'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(41154316324496227812)
,p_event_id=>wwv_flow_imp.id(41154316280268227811)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Are You sure you want to delete this product ? ',
'this action is irreversible !!'))
,p_attribute_02=>'Delete Product'
,p_attribute_03=>'danger'
,p_attribute_04=>'fa-remove'
,p_attribute_05=>'delete-confirm'
,p_attribute_06=>'Delete product '
,p_attribute_07=>'Cancel'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(41154316748683227816)
,p_event_id=>wwv_flow_imp.id(41154316280268227811)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P72_PROD_TO_DELETE'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'$(this.triggeringElement).parent().data(''id'');'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(41154316637438227815)
,p_event_id=>wwv_flow_imp.id(41154316280268227811)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DELETE FROM product',
'WHERE product_id = :P72_PROD_TO_DELETE;'))
,p_attribute_02=>'P72_PROD_TO_DELETE'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(41154316949474227818)
,p_event_id=>wwv_flow_imp.id(41154316280268227811)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.region(''overview-item-1'').refresh();',
'apex.region(''chart-1'').refresh();',
'apex.region(''chart-2'').refresh();',
'apex.region(''chart-3'').refresh();',
'apex.region(''prod-list'').refresh();'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(42374009139290189338)
,p_name=>'Refresh page'
,p_event_sequence=>20
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(39512637606792030944)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(42374009206140189339)
,p_event_id=>wwv_flow_imp.id(42374009139290189338)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(39512637606792030944)
);
wwv_flow_imp.component_end;
end;
/
