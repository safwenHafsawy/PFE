prompt --application/pages/page_00074
begin
--   Manifest
--     PAGE: 00074
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>6662355588643785590
,p_default_application_id=>214711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_RSWSP'
);
wwv_flow_imp_page.create_page(
 p_id=>74
,p_name=>'Seller Dashboard Delivery'
,p_alias=>'SELLER-DASHBOARD-DELIVERY'
,p_step_title=>'Seller Dashboard Delivery'
,p_welcome_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.22/pdfmake.min.js"></script>',
'<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/0.4.1/html2canvas.min.js"></script>',
'<script type="text/javascript">',
'    function ExportDetails() {',
'    html2canvas(document.getElementById("PDF"), {',
'        onrendered: function(canvas) {',
'            var data=canvas.toDataURL();',
'',
'            var docDefinition= {',
'                content: [ {',
'                    image: data,',
'                    width: 500',
'                }',
'',
'                ]',
'            }',
'',
'            ;',
'            pdfMake.createPdf(docDefinition).download("DeliveryDetails.pdf");',
'        }',
'    });',
'',
'}',
'',
'</script>'))
,p_autocomplete_on_off=>'OFF'
,p_css_file_urls=>'#APP_FILES#Styling/main_style#MIN#.css'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.overall-summary-region-container {',
'    padding: 10px;',
'}',
'',
'.overall-summary-region-row{',
'    padding: 0 0 50px;',
'}',
'',
'.overall-summary-region {',
'    margin: 0 10px 10px 10px;',
'    min-height: 100%;',
'    box-shadow: -1px 33px 35px -13px rgba(207,193,193,0.59);',
'    -webkit-box-shadow: -1px 33px 35px -13px rgba(207,193,193,0.59);',
'    -moz-box-shadow: -1px 33px 35px -13px rgba(207,193,193,0.59);',
'    border-radius: 10px !important;',
'    transition: all 300ms;',
'}',
'',
'.overall-summary-region:hover {',
'    transform: scale(1.05);',
'    box-shadow: -1px 33px 35px -20px rgba(207,193,193,0.99);',
'    -webkit-box-shadow: -1px 33px 35px -20px rgba(207,193,193,0.99);',
'    -moz-box-shadow: -1px 33px 35px -20px rgba(207,193,193,0.99);',
'}',
'',
'.overview {',
'    border-left: 10px solid var(--fouth-color);',
'    border-radius: 10px;',
'    padding-left: 10px;',
'    text-align: center;',
'}',
'',
'.overview-danger {',
'    border-left: 10px solid var(--danger-color);',
'    border-radius: 10px;',
'    padding-left: 10px;',
'    text-align: center;',
'}',
'',
'.overview-success{',
'    border-left: 10px solid var(--success-color);',
'    border-radius: 10px;',
'    padding-left: 10px;',
'    text-align: center;',
'}',
'',
'.overview-warning {',
'    border-left: 10px solid var(--warning-color);',
'    border-radius: 10px;',
'    padding-left: 10px;',
'    text-align: center;',
'}',
'',
'.overview-title {',
'    text-align: center;',
'    color: var(--fouth-color);',
'    font-family: var(--secondary-header-font);',
'    border-bottom: 1px solid rgba(211, 211, 211, 0.5);',
'    padding: 2px;',
'}',
'',
'.overview-title > span {',
'    margin-right: 5px;',
'}',
'',
'.overview-data {',
'    font-family: var(--regular-text-font );',
'}',
'',
'.overview-data-prod > span {',
'    font-size: xx-small;',
'    opacity: 0.6;',
'}',
'',
'',
'.t-Report-colHead{',
'    font-family: var(--secondary-header-font);',
'    text-align: center;',
'}',
'',
'.t-Report-cell{',
'    font-family: var(--regular-text-font);',
'    text-align: center;',
'}',
'',
'',
'.del-order {',
'    color: var(--danger-color);',
'}',
'',
'.confirm-order {',
'    color: var(--fouth-color);',
'}'))
,p_step_template=>wwv_flow_imp.id(19471509145742504218)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'25'
,p_last_updated_by=>'PFE94053@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20230817220557'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(39275505321660429144)
,p_plug_name=>'Seller Dashboard Navigation'
,p_region_css_classes=>'dashboard-side-menu'
,p_region_sub_css_classes=>'dashboard-side-menu-list'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-LinksList--showArrow:t-LinksList--nowrap:t-LinksList--actions:t-LinksList--showIcons'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_02'
,p_list_id=>wwv_flow_imp.id(38784043417088031374)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(19471863408174504294)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(46538613212385172016)
,p_plug_name=>'Status-based Delivery Tracker'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>20
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(46538613324527172017)
,p_region_id=>wwv_flow_imp.id(46538613212385172016)
,p_chart_type=>'pie'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_value_format_type=>'decimal'
,p_value_decimal_places=>0
,p_value_format_scaling=>'none'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_pie_other_threshold=>0
,p_pie_selection_effect=>'highlight'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(46538613448113172018)
,p_chart_id=>wwv_flow_imp.id(46538613324527172017)
,p_seq=>10
,p_name=>'Series 1'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  COUNT(distinct d.delivery_id), delivery_status',
'    from    delivery d, order_items oi, product p, stores s',
'    where   d.order_id = oi.order_id',
'    and     oi.product_id = p.product_id',
'    and     p.store_id = s.store_id',
'    and     s.customer_id = to_number(:USER_ID) ',
'    GROUP BY delivery_status;'))
,p_items_value_column_name=>'COUNT(DISTINCTD.DELIVERY_ID)'
,p_items_label_column_name=>'DELIVERY_STATUS'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_items_label_display_as=>'LABEL'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(46538613780287172021)
,p_plug_name=>'Earnings Forecast vs. Actual Performance'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>30
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(46538614006777172024)
,p_region_id=>wwv_flow_imp.id(46538613780287172021)
,p_chart_type=>'lineWithArea'
,p_height=>'400'
,p_animation_on_display=>'alphaFade'
,p_animation_on_data_change=>'slideToRight'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'bottom'
,p_legend_font_family=>'Courier New'
,p_legend_font_style=>'oblique'
,p_legend_font_size=>'12'
,p_legend_font_color=>'#3a3632'
,p_no_data_found_message=>'No Deliveries Yet !'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(46538614195478172025)
,p_chart_id=>wwv_flow_imp.id(46538614006777172024)
,p_seq=>10
,p_name=>'Projected Earnings Per Month'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH all_months AS (',
'  SELECT TO_CHAR(ADD_MONTHS(TRUNC(SYSDATE, ''YYYY''), LEVEL - 1), ''YYYY-MM'') AS month',
'  FROM DUAL',
'  CONNECT BY LEVEL <= 12 ',
')',
'SELECT am.month, COALESCE(SUM(d.price), 0)  AS revenue',
'FROM all_months am',
'LEFT JOIN orders o ON am.month = TO_CHAR(o.order_datetime, ''YYYY-MM'')',
'LEFT JOIN delivery d ON d.order_id = o.order_id',
'                    AND (d.delivery_status = ''Awaiting'' OR d.delivery_status = ''Confirmed'' OR d.delivery_status = ''Returned'')',
'LEFT JOIN order_items oi ON o.order_id = oi.order_id',
'LEFT JOIN product p ON oi.product_id = p.product_id',
'LEFT JOIN stores s ON p.store_id = s.store_id',
'                   AND s.customer_id = to_number(:USER_ID)',
'GROUP BY am.month',
'ORDER BY am.month;'))
,p_items_value_column_name=>'REVENUE'
,p_items_label_column_name=>'MONTH'
,p_color=>'#3a3632'
,p_line_style=>'solid'
,p_line_type=>'auto'
,p_marker_rendered=>'on'
,p_marker_shape=>'triangleUp'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_items_label_font_family=>'Courier New'
,p_items_label_font_style=>'italic'
,p_items_label_font_size=>'10'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(46538614480834172028)
,p_chart_id=>wwv_flow_imp.id(46538614006777172024)
,p_seq=>20
,p_name=>'Confirmed Earnings Per Month'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH all_months AS (',
'  SELECT TO_CHAR(ADD_MONTHS(TRUNC(SYSDATE, ''YYYY''), LEVEL - 1), ''YYYY-MM'') AS month',
'  FROM DUAL',
'  CONNECT BY LEVEL <= 12 ',
')',
'SELECT am.month, COALESCE(SUM(d.price), 0)  AS revenue',
'FROM all_months am',
'LEFT JOIN orders o ON am.month = TO_CHAR(o.order_datetime, ''YYYY-MM'')',
'LEFT JOIN delivery d ON d.order_id = o.order_id',
'LEFT JOIN order_items oi ON o.order_id = oi.order_id',
'LEFT JOIN product p ON oi.product_id = p.product_id',
'LEFT JOIN stores s ON p.store_id = s.store_id',
'                   AND s.customer_id = to_number(:USER_ID)',
'WHERE d.delivery_status = ''Delivered''',
'GROUP BY am.month',
'ORDER BY am.month;'))
,p_items_value_column_name=>'REVENUE'
,p_items_label_column_name=>'MONTH'
,p_color=>'#497620'
,p_line_style=>'solid'
,p_line_type=>'auto'
,p_marker_rendered=>'on'
,p_marker_shape=>'diamond'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_items_label_font_family=>'Courier New'
,p_items_label_font_style=>'italic'
,p_items_label_font_size=>'10'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(46538615429250172038)
,p_chart_id=>wwv_flow_imp.id(46538614006777172024)
,p_axis=>'y2'
,p_is_rendered=>'off'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_split_dual_y=>'auto'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(46538614297953172026)
,p_chart_id=>wwv_flow_imp.id(46538614006777172024)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(46538614392237172027)
,p_chart_id=>wwv_flow_imp.id(46538614006777172024)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_title=>'Revenue In TND'
,p_title_font_family=>'Courier New'
,p_title_font_style=>'oblique'
,p_title_font_size=>'10'
,p_title_font_color=>'#000000'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(46538615540414172039)
,p_plug_name=>'Earnings Forecast vs. Shortfalls'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(46538615638485172040)
,p_region_id=>wwv_flow_imp.id(46538615540414172039)
,p_chart_type=>'lineWithArea'
,p_height=>'400'
,p_animation_on_display=>'alphaFade'
,p_animation_on_data_change=>'slideToLeft'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'bottom'
,p_legend_font_family=>'Courier New'
,p_legend_font_style=>'oblique'
,p_legend_font_size=>'12'
,p_legend_font_color=>'#3a3632'
,p_no_data_found_message=>'No Deliveries Yet !'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(46538615789699172041)
,p_chart_id=>wwv_flow_imp.id(46538615638485172040)
,p_seq=>10
,p_name=>'Projected Earnings Per Month'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH all_months AS (',
'  SELECT TO_CHAR(ADD_MONTHS(TRUNC(SYSDATE, ''YYYY''), LEVEL - 1), ''YYYY-MM'') AS month',
'  FROM DUAL',
'  CONNECT BY LEVEL <= 12 ',
')',
'SELECT am.month, COALESCE(SUM(d.price), 0)  AS revenue',
'FROM all_months am',
'LEFT JOIN orders o ON am.month = TO_CHAR(o.order_datetime, ''YYYY-MM'')',
'LEFT JOIN delivery d ON d.order_id = o.order_id',
'                    AND (d.delivery_status = ''Awaiting'' OR d.delivery_status = ''Confirmed'' OR d.delivery_status = ''Returned'')',
'LEFT JOIN order_items oi ON o.order_id = oi.order_id',
'LEFT JOIN product p ON oi.product_id = p.product_id',
'LEFT JOIN stores s ON p.store_id = s.store_id',
'                   AND s.customer_id = to_number(:USER_ID)',
'GROUP BY am.month',
'ORDER BY am.month;'))
,p_items_value_column_name=>'REVENUE'
,p_items_label_column_name=>'MONTH'
,p_color=>'#3a3632'
,p_line_style=>'solid'
,p_line_type=>'auto'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_items_label_font_family=>'Courier New'
,p_items_label_font_style=>'italic'
,p_items_label_font_size=>'10'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(46538615989912172043)
,p_chart_id=>wwv_flow_imp.id(46538615638485172040)
,p_seq=>30
,p_name=>'Negative Earnings Per Month'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH all_months AS (',
'  SELECT TO_CHAR(ADD_MONTHS(TRUNC(SYSDATE, ''YYYY''), LEVEL - 1), ''YYYY-MM'') AS month',
'  FROM DUAL',
'  CONNECT BY LEVEL <= 12 ',
')',
'SELECT am.month, COALESCE(SUM(d.price), 0)  AS revenue',
'FROM all_months am',
'LEFT JOIN orders o ON am.month = TO_CHAR(o.order_datetime, ''YYYY-MM'')',
'LEFT JOIN delivery d ON d.order_id = o.order_id',
'LEFT JOIN order_items oi ON o.order_id = oi.order_id',
'LEFT JOIN product p ON oi.product_id = p.product_id',
'LEFT JOIN stores s ON p.store_id = s.store_id',
'                   AND s.customer_id = to_number(:USER_ID)',
'WHERE d.delivery_status = ''Returned''',
'GROUP BY am.month',
'ORDER BY am.month;'))
,p_items_value_column_name=>'REVENUE'
,p_items_label_column_name=>'MONTH'
,p_color=>'#c33522'
,p_line_style=>'solid'
,p_line_type=>'auto'
,p_marker_rendered=>'on'
,p_marker_shape=>'circle'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_items_label_font_family=>'Courier New'
,p_items_label_font_style=>'italic'
,p_items_label_font_size=>'10'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(46538616072473172044)
,p_chart_id=>wwv_flow_imp.id(46538615638485172040)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(46538616145207172045)
,p_chart_id=>wwv_flow_imp.id(46538615638485172040)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(46538616290728172046)
,p_chart_id=>wwv_flow_imp.id(46538615638485172040)
,p_axis=>'y2'
,p_is_rendered=>'off'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_split_dual_y=>'auto'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(46538616352484172047)
,p_name=>'Delivery List'
,p_template=>wwv_flow_imp.id(19471808805460504264)
,p_display_sequence=>50
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT d.delivery_id, dm.DELIVERY_METHOD ,o.order_id, d.approx_date, d.delivery_location, d.delivery_status, ''Delivery Details''',
'FROM delivery d',
'JOIN orders o ON d.order_id = o.order_id',
'JOIN delivery_type dm ON d.delivery_type_id = dm.delivery_type_id',
'JOIN order_items oi ON o.order_id = oi.order_id',
'JOIN product p ON oi.product_id = p.product_id',
'JOIN stores s ON p.store_id = s.store_id',
'WHERE s.customer_id = TO_NUMBER(:USER_ID);'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(19471847069031504283)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(47546670287958340344)
,p_query_column_id=>1
,p_column_alias=>'DELIVERY_ID'
,p_column_display_sequence=>10
,p_column_heading=>'Delivery Id'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(47738993670718838009)
,p_query_column_id=>2
,p_column_alias=>'DELIVERY_METHOD'
,p_column_display_sequence=>40
,p_column_heading=>'Delivery Method'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(47546670339581340345)
,p_query_column_id=>3
,p_column_alias=>'ORDER_ID'
,p_column_display_sequence=>20
,p_column_heading=>'Order Id'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(47546670436394340346)
,p_query_column_id=>4
,p_column_alias=>'APPROX_DATE'
,p_column_display_sequence=>30
,p_column_heading=>'Approx Date'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(47546670561963340347)
,p_query_column_id=>5
,p_column_alias=>'DELIVERY_LOCATION'
,p_column_display_sequence=>50
,p_column_heading=>'Delivery Location'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(47546670615391340348)
,p_query_column_id=>6
,p_column_alias=>'DELIVERY_STATUS'
,p_column_display_sequence=>60
,p_column_heading=>'Delivery Status'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(47546670707971340349)
,p_query_column_id=>7
,p_column_alias=>'''DELIVERYDETAILS'''
,p_column_display_sequence=>70
,p_column_heading=>'&#x27;deliverydetails&#x27;'
,p_use_as_row_header=>'N'
,p_column_link=>'javascript:void(null)'
,p_column_linktext=>'<span aria-hidden="true" class="fa fa-expand expand-delivery "></span>'
,p_column_link_attr=>'data-id=#DELIVERY_ID#'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(47546669400138340336)
,p_plug_name=>'Delivery Details'
,p_region_template_options=>'#DEFAULT#:js-dialog-size600x400'
,p_plug_template=>wwv_flow_imp.id(19471593662015504257)
,p_plug_display_sequence=>60
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(47738992966030838002)
,p_plug_name=>'Order Details'
,p_region_name=>'PDF'
,p_parent_plug_id=>wwv_flow_imp.id(47546669400138340336)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>70
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(126033021944455701722)
,p_plug_name=>'Delivery Overview'
,p_region_name=>'order-overview'
,p_region_css_classes=>'overall-summary-region-container'
,p_region_template_options=>'#DEFAULT#:t-Region--textContent:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>5
,p_plug_display_point=>'REGION_POSITION_08'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(46538612943111172013)
,p_plug_name=>'Confirmed Earnings'
,p_parent_plug_id=>wwv_flow_imp.id(126033021944455701722)
,p_region_css_classes=>'overall-summary-region'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    l_sum number := 0;',
'begin',
'    select  COALESCE(sum(d.price), 0)',
'    into    l_sum',
'    from    delivery d, order_items oi, product p, stores s',
'    where   d.delivery_status = ''Delivered''   ',
'    and     d.order_id = oi.order_id',
'    and     oi.product_id = p.product_id',
'    and     p.store_id = s.store_id',
'    and     s.customer_id = to_number(:USER_ID) ;',
'',
'    return ',
'        '' <div class="overview-success">',
'        <h3 class="overview-title"> Confirmed Earnings </h3>',
'        <h4 class="overview-data">'' || l_sum || '' TND',
'        </h4>',
'        </div> '';',
'end;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
,p_plug_display_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(46538613168547172015)
,p_plug_name=>'Negative Earnings'
,p_parent_plug_id=>wwv_flow_imp.id(126033021944455701722)
,p_region_css_classes=>'overall-summary-region'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    l_sum number := 0;',
'begin',
'    select  COALESCE(sum(d.price), 0)',
'    into    l_sum',
'    from    delivery d, order_items oi, product p, stores s',
'    where   d.delivery_status = ''Returned''   ',
'    and     d.order_id = oi.order_id',
'    and     oi.product_id = p.product_id',
'    and     p.store_id = s.store_id',
'    and     s.customer_id = to_number(:USER_ID) ;',
'',
'    return ',
'        '' <div class="overview-danger">',
'        <h3 class="overview-title"> Negative Earnings </h3>',
'        <h4 class="overview-data">'' || l_sum || '' TND',
'        </h4>',
'        </div> '';',
'end;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
,p_plug_display_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(87209142719162993321)
,p_plug_name=>'To Be Dispatched'
,p_parent_plug_id=>wwv_flow_imp.id(126033021944455701722)
,p_region_css_classes=>'overall-summary-region'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>60
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>4
,p_plug_display_point=>'SUB_REGIONS'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_count number;',
'begin',
'    select  count(distinct delivery_id)',
'    into    l_count',
'    from    delivery d, order_items oi, product p, stores s',
'    where   d.delivery_status = ''Awaiting''  ',
'    and     d.order_id = oi.order_id',
'    and     oi.product_id = p.product_id',
'    and     p.store_id = s.store_id',
'    and     s.customer_id = to_number(:USER_ID) ;',
'',
'    return ',
'        '' <div class="overview-warning">',
'        <h3 class="overview-title"> To Be Dispatched </h3>',
'        <h4 class="overview-data">'' || l_count || '' Order(s)',
'        </h4>',
'        </div> '';',
'end;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
,p_plug_display_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(87209142889386993322)
,p_plug_name=>'Returned From Customer'
,p_parent_plug_id=>wwv_flow_imp.id(126033021944455701722)
,p_region_css_classes=>'overall-summary-region'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>70
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>4
,p_plug_display_point=>'SUB_REGIONS'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    l_count number;',
'begin',
'    select  count(distinct delivery_id)',
'    into    l_count',
'    from    delivery d, order_items oi, product p, stores s',
'    where   d.delivery_status = ''Returned''  ',
'    and     d.order_id = oi.order_id',
'    and     oi.product_id = p.product_id',
'    and     p.store_id = s.store_id',
'    and     s.customer_id = to_number(:USER_ID) ;',
'',
'    return ',
'        '' <div class="overview-danger">',
'        <h3 class="overview-title"> Returned From Customer </h3>',
'        <h4 class="overview-data">'' || l_count || '' Order(s)',
'        </h4>',
'        </div> '';',
'end;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
,p_plug_display_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(126033022119818701724)
,p_plug_name=>'Projected Earnings'
,p_parent_plug_id=>wwv_flow_imp.id(126033021944455701722)
,p_region_css_classes=>'overall-summary-region'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>10
,p_plug_grid_row_css_classes=>'overall-summary-region-row'
,p_plug_display_point=>'SUB_REGIONS'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    l_sum number := 0;',
'begin',
'    select  COALESCE(sum(d.price), 0)',
'    into    l_sum',
'    from    delivery d, order_items oi, product p, stores s',
'    where     d.order_id = oi.order_id',
'    and     oi.product_id = p.product_id',
'    and     p.store_id = s.store_id',
'    and     s.customer_id = to_number(:USER_ID) ;',
'',
'    return ',
'        '' <div class="overview">',
'        <h3 class="overview-title"> Projected Earnings </h3>',
'        <h4 class="overview-data">'' || l_sum || '' TND',
'        </h4>',
'        </div> '';',
'end;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
,p_plug_display_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(126033022358956701726)
,p_plug_name=>'Delivered To Customer'
,p_parent_plug_id=>wwv_flow_imp.id(126033021944455701722)
,p_region_css_classes=>'overall-summary-region'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>50
,p_plug_grid_column_span=>4
,p_plug_display_point=>'SUB_REGIONS'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    l_count number;',
'begin',
'    select  count(distinct delivery_id)',
'    into    l_count',
'    from    delivery d, order_items oi, product p, stores s',
'    where   d.delivery_status = ''Delivered''  ',
'    and     d.order_id = oi.order_id',
'    and     oi.product_id = p.product_id',
'    and     p.store_id = s.store_id',
'    and     s.customer_id = to_number(:USER_ID) ;',
'',
'    return ',
'        '' <div class="overview-success">',
'        <h3 class="overview-title"> Delivered To Customer </h3>',
'        <h4 class="overview-data">'' || l_count || '' Order(s)',
'        </h4>',
'        </div> '';',
'end;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
,p_plug_display_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(47546669886426340340)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_imp.id(47546669400138340336)
,p_button_name=>'Download_Details'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(19471882000429504304)
,p_button_image_alt=>'Download Details'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(47546669566113340337)
,p_name=>'P74_DELIVERY_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(47546669400138340336)
,p_prompt=>'Delivery Id'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(19471879586967504303)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(47738993266628838005)
,p_name=>'P74_ORDER_ID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(47546669400138340336)
,p_prompt=>'Delivery Id'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(19471879586967504303)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(47738993396785838006)
,p_name=>'P74_DATE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(47546669400138340336)
,p_prompt=>'Delivery Id'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(19471879586967504303)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(47738993464805838007)
,p_name=>'P74_LOCATION'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(47546669400138340336)
,p_prompt=>'Delivery Id'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(19471879586967504303)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>6662355588643785590
,p_default_application_id=>214711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_RSWSP'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(47738993507240838008)
,p_name=>'P74_STATUS'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(47546669400138340336)
,p_prompt=>'Delivery Id'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(19471879586967504303)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(47738993725243838010)
,p_name=>'P74_DELIVERY_METHOD'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(47546669400138340336)
,p_prompt=>'Delivery Method'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(19471879586967504303)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(47546669195909340333)
,p_name=>'Expand Delivery'
,p_event_sequence=>10
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.expand-delivery'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(47546670802142340350)
,p_event_id=>wwv_flow_imp.id(47546669195909340333)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$s("P74_DELIVERY_ID", $(this.triggeringElement).parent().data(''deliveryID''))'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(47546669794295340339)
,p_event_id=>wwv_flow_imp.id(47546669195909340333)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_OPEN_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(47546669400138340336)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(47546669993137340341)
,p_name=>'Download'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(47546669886426340340)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(47738993146779838004)
,p_event_id=>wwv_flow_imp.id(47546669993137340341)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'ExportDetails();'
);
wwv_flow_imp.component_end;
end;
/
