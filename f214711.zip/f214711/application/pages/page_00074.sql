prompt --application/pages/page_00074
begin
--   Manifest
--     PAGE: 00074
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>6662355588643785590
,p_default_application_id=>214711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_RSWSP'
);
wwv_flow_imp_page.create_page(
 p_id=>74
,p_name=>'Seller Dashboard Invoices'
,p_alias=>'SELLER-DASHBOARD-INVOICES'
,p_step_title=>'Seller Dashboard Invoices'
,p_autocomplete_on_off=>'OFF'
,p_css_file_urls=>'#APP_FILES#Styling/main_style#MIN#.css'
,p_step_template=>wwv_flow_imp.id(19471509145742504218)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'06'
,p_last_updated_by=>'PFE94053@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20230714140746'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(39275505321660429144)
,p_plug_name=>'Seller Dashboard Navigation'
,p_region_css_classes=>'dashboard-side-menu'
,p_region_sub_css_classes=>'dashboard-side-menu-list'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-LinksList--showArrow:t-LinksList--nowrap:t-LinksList--actions:t-LinksList--showIcons'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_02'
,p_list_id=>wwv_flow_imp.id(38784043417088031374)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(19471863408174504294)
);
wwv_flow_imp.component_end;
end;
/
