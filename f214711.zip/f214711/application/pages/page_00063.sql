prompt --application/pages/page_00063
begin
--   Manifest
--     PAGE: 00063
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>6662355588643785590
,p_default_application_id=>214711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_RSWSP'
);
wwv_flow_imp_page.create_page(
 p_id=>63
,p_name=>'Edit Product Images'
,p_alias=>'EDIT-PRODUCT-IMAGES1'
,p_page_mode=>'MODAL'
,p_step_title=>'Edit Product Images'
,p_autocomplete_on_off=>'OFF'
,p_css_file_urls=>'#APP_FILES#Styling/main_style#MIN#.css'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.image-card-container {',
'    padding: 10px;',
'    box-sizing: border-box;',
'}',
'',
'.image-card {',
'   border: transparent;',
'   box-shadow: 1px 1px 1px 1px grey;',
'',
'}',
'',
'.image-card > div:first-child {',
'    background-color: transparent;',
'}',
'',
'.image-card > .a-CardView-actions {',
'    background-color: transparent;',
'    display: flex;',
'    justify-content: center;',
'    align-items: center;',
'}',
'',
'.delete-img {',
'    background-color: var(--danger-color);',
'}'))
,p_step_template=>wwv_flow_imp.id(19471535469231504230)
,p_page_template_options=>'#DEFAULT#'
,p_dialog_width=>'1200'
,p_protection_level=>'C'
,p_page_component_map=>'23'
,p_last_updated_by=>'PFE94053@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20230731181635'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(33838606200335159666)
,p_plug_name=>'Wizard Progress'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(19471542261328504234)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_list_id=>wwv_flow_imp.id(33838191074647159655)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(19471877875421504302)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(33838606334618159666)
,p_plug_name=>'Edit Product Images'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(19471549395551504237)
,p_plug_display_sequence=>20
,p_query_type=>'TABLE'
,p_query_table=>'PRODUCT_IMAGES'
,p_query_where=>'product_id = :P63_PRODUCT_ID'
,p_include_rowid_column=>false
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_ajax_items_to_submit=>'P63_PRODUCT_ID'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(33825345778748128828)
,p_region_id=>wwv_flow_imp.id(33838606334618159666)
,p_layout_type=>'GRID'
,p_component_css_classes=>'image-card-container'
,p_card_css_classes=>'image-card'
,p_title_adv_formatting=>false
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_media_adv_formatting=>false
,p_media_source_type=>'BLOB'
,p_media_blob_column_name=>'IMAGE'
,p_media_display_position=>'FIRST'
,p_media_appearance=>'WIDESCREEN'
,p_media_sizing=>'FIT'
,p_media_css_classes=>'prod-img'
,p_media_description=>'&IMAGE_FILENAME.'
,p_pk1_column_name=>'IMAGE_ID'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(33825345848320128829)
,p_card_id=>wwv_flow_imp.id(33825345778748128828)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>10
,p_label=>'Delete Image'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'javascript:void(null)'
,p_link_attributes=>'data-id=&IMAGE_ID.'
,p_button_display_type=>'TEXT_WITH_ICON'
,p_icon_css_classes=>'fa-remove'
,p_action_css_classes=>'delete-img'
,p_is_hot=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(33838606405617159666)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(19471545059842504235)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(33838607919079159667)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(33838606405617159666)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(19471882000429504304)
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(33838608088846159667)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(33838606405617159666)
,p_button_name=>'FINISH'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(19471882000429504304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Finish Updating Product'
,p_button_position=>'NEXT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(33838608127894159667)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(33838606405617159666)
,p_button_name=>'PREVIOUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(19471881378436504304)
,p_button_image_alt=>'Previous'
,p_button_position=>'PREVIOUS'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(33838609812824159668)
,p_branch_action=>'f?p=&APP_ID.:62:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_VALIDATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(33838608127894159667)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(33825345669992128827)
,p_name=>'P63_PRODUCT_ID'
,p_item_sequence=>10
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(33825345969246128830)
,p_name=>'P63_IMAGE_TO_DELETE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(33838606334618159666)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(33838608319053159667)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(33838607919079159667)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(33838609140733159667)
,p_event_id=>wwv_flow_imp.id(33838608319053159667)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(33825346706224128838)
,p_name=>'Delete Image'
,p_event_sequence=>20
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.delete-img'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(33825346982477128840)
,p_event_id=>wwv_flow_imp.id(33825346706224128838)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'Are you sure you want to delete the image? This action is irreversible !!'
,p_attribute_02=>'Delete Image'
,p_attribute_03=>'danger'
,p_attribute_04=>'fa-remove'
,p_attribute_06=>'Delete Image'
,p_attribute_07=>'Cancel'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(33825346894372128839)
,p_event_id=>wwv_flow_imp.id(33825346706224128838)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P63_IMAGE_TO_DELETE'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'$(this.triggeringElement).data(''id'');'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(33825347016979128841)
,p_event_id=>wwv_flow_imp.id(33825346706224128838)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'delete from product_images',
'where image_id = :P63_IMAGE_TO_DELETE;'))
,p_attribute_02=>'P63_IMAGE_TO_DELETE'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(33825347150991128842)
,p_event_id=>wwv_flow_imp.id(33825346706224128838)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(33838606334618159666)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(33838610673496159668)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>33838610673496159668
);
wwv_flow_imp.component_end;
end;
/
