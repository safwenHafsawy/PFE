prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>6662355588643785590
,p_default_application_id=>214711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_RSWSP'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>'Home'
,p_alias=>'HOME'
,p_step_title=>'&APP_NAME. - Home'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'#APP_FILES#scripts/main#MIN#.js'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(".heart").hover(function(){',
'  $(this).css("color", "#B43757");',
'  }, function(){',
'  $(this).css("color", "black");',
'});'))
,p_css_file_urls=>'#APP_FILES#Styling/main_style#MIN#.css'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.slide{',
'    background-color: transparent;',
'    }',
'',
'.col col-12 apex-col-auto col-start col-end{',
'    background-color: aqua;',
'}',
'',
'.a-Region-carouselNav {',
'    position: absolute;',
'    bottom: 10%;',
'}',
'',
'',
'.a-CardView-items {',
'    margin: 0 2%;',
'}',
'',
'.new_product_card {',
'    position: relative;',
'}',
'',
'.a-CardView-media {',
'    margin-top: 50px;',
'}',
'',
'.region-title {',
'    font-family: var(--secondary-header-font);',
'    text-align: center;',
'}',
'',
'.new-products {',
'    background-color: #FDF1F3;',
'}',
'',
'.promo {',
'    background-color: #FBF9DB;',
'}',
'',
'.recomd-products {',
'    background-color: #F1FBFA;',
'}',
'',
'.recent-seen {',
'    background-color: var(--second-color);',
'}',
'',
'.a-GV-pageButton  {',
'    background-color: var(--fouth-color);',
'    color: var(--first-color);',
'    ',
'}',
'',
'.js-pg-next {',
'    position: absolute;',
'    right: 0;',
'    bottom: 50%;',
'}',
'',
'.js-pg-prev {',
'    position: absolute;',
'    left: 0;',
'    bottom: 50%;',
'}'))
,p_page_template_options=>'#DEFAULT#:js-pageStickyMobileHeader'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'PFE94053@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20230802201958'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(33829156460654289632)
,p_plug_name=>'slide container'
,p_region_css_classes=>'slide'
,p_region_template_options=>'t-Region--noPadding:js-useLocalStorage:t-Region--showCarouselControls:js-cycle5s:t-Region--carouselSpin:t-Region--removeHeader:t-Region--noBorder:t-Region--hiddenOverflow:margin-top-none:margin-bottom-none:margin-left-none:margin-right-none'
,p_plug_template=>wwv_flow_imp.id(19471551224673504238)
,p_plug_display_sequence=>50
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
''))
,p_landmark_type=>'region'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(33829156852180289636)
,p_plug_name=>'image 1'
,p_parent_plug_id=>wwv_flow_imp.id(33829156460654289632)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<image src="	#APP_FILES#8fff7ee9d1f31c391b4ba187ef5d7ce90737debd_apothika desk.jpg"',
' onclick="window.location.href=''f?p=&APP_ID.:2:&SESSION.:::11:P11_CATEG_ID:2:P11_STORE_ID:1'';" ',
'  width="100%" ',
'  height= "auto"></image>',
'',
''))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(33829156902879289637)
,p_plug_name=>'image 2'
,p_parent_plug_id=>wwv_flow_imp.id(33829156460654289632)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>10
,p_plug_grid_column_css_classes=>'slide_image'
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<img src="#APP_FILES#Cahaya Dewi.png" ',
'onclick="window.location.href=''f?p=&APP_ID.:2:&SESSION.:::11:P11_CATEG_ID:2:P11_STORE_ID:1'';" ',
'width="100%" ',
'height="auto">',
''))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(33829157065461289638)
,p_plug_name=>'image 3'
,p_parent_plug_id=>wwv_flow_imp.id(33829156460654289632)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<image src="#APP_FILES#f4d40e61300d691ed227eb38df3db0954344845f_sliders-web solaire alania.jpg" ',
'onclick="window.location.href=''f?p=&APP_ID.:2:&SESSION.:::11:P11_CATEG_ID:2:P11_STORE_ID:1'';"  ',
'width="100%" ',
'height= "auto"></image>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(33829157256057289640)
,p_plug_name=>'Bestsellers'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>80
,p_plug_source=>'<h2 class="region-title "> BESTSELLERS </h1>'
,p_plug_display_condition_type=>'FUNCTION_BODY'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_count number;',
'',
'begin',
'',
'    select count(*) into v_count from order_items;',
'            if v_count = 0 then ',
'                    return false ;',
'            else',
'                    return true;',
'             end if;       ',
'',
'end;'))
,p_plug_display_when_cond2=>'PLSQL'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(33829158274812289650)
,p_plug_name=>'Bestsellers_card'
,p_parent_plug_id=>wwv_flow_imp.id(33829157256057289640)
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--styleB'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(19471549395551504237)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT  p.product_id,',
'        p.product_name,',
'        p.unit_price,',
'        p.category_id,',
'        p.store_id,',
'        s.store_name,',
'        s.customer_id as store_owner,',
'        discount,',
'        NEW_PRICE (P.PRODUCT_ID) new_price,',
'        AMOUNT_SOLD(P.PRODUCT_ID) amount_sold,',
'        pi.image',
'FROM    product p',
'        join (SELECT image_id,',
'            product_id,',
'            image',
'            FROM(SELECT image_id,',
'                        product_id,',
'                        image,',
'                        Row_number()',
'                            over (',
'                            PARTITION BY product_id',
'                            ORDER BY image_id) AS rn',
'                FROM   product_images) img',
'                WHERE  rn = 1) pi',
'        ON p.product_id = pi.product_id',
'        join( select distinct product_id from order_items) o  ',
'        on p.product_id = o.product_id,',
'        stores s',
'WHERE   ROWNUM <= 5 ',
'AND p.store_id = s.store_id',
'ORDER BY AMOUNT_SOLD DESC;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(34598048689092261101)
,p_region_id=>wwv_flow_imp.id(33829158274812289650)
,p_layout_type=>'GRID'
,p_grid_column_count=>5
,p_card_css_classes=>'card'
,p_title_adv_formatting=>false
,p_title_column_name=>'PRODUCT_NAME'
,p_sub_title_adv_formatting=>true
,p_sub_title_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{case DISCOUNT/}',
'{when 0/}',
'<b>&NEW_PRICE. TN</b>',
'{otherwise/}',
'&DISCOUNT.% &emsp;',
'<b>&NEW_PRICE. TN </b>&emsp;',
'<s> &UNIT_PRICE. TN</s>',
'',
'',
'{endcase/}'))
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_media_adv_formatting=>false
,p_media_source_type=>'BLOB'
,p_media_blob_column_name=>'IMAGE'
,p_media_display_position=>'FIRST'
,p_media_appearance=>'SQUARE'
,p_media_sizing=>'FIT'
,p_pk1_column_name=>'PRODUCT_ID'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(34598048788125261102)
,p_card_id=>wwv_flow_imp.id(34598048689092261101)
,p_action_type=>'FULL_CARD'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:18:&SESSION.::&DEBUG.:18:P18_PRODUCT_ID:&PRODUCT_ID.'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(38242826505186699942)
,p_card_id=>wwv_flow_imp.id(34598048689092261101)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>20
,p_label=>'Store : &STORE_NAME.'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:5:P5_STORE_ID,P5_STORE_OWNER_ID,P5_STORE_NAME:&STORE_ID.,&STORE_OWNER.,&STORE_NAME.'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'to_store'
,p_is_hot=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(34598053393376261148)
,p_card_id=>wwv_flow_imp.id(34598048689092261101)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>30
,p_label=>'add to wishlist'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'javascript:void(null);'
,p_link_attributes=>'data-id=&PRODUCT_ID.'
,p_button_display_type=>'ICON'
,p_icon_css_classes=>'fa-heart-o'
,p_action_css_classes=>'heart'
,p_is_hot=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(34598053468781261149)
,p_card_id=>wwv_flow_imp.id(34598048689092261101)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>40
,p_label=>'Add to Cart'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:12:&SESSION.::&DEBUG.:12:P12_PRODUCT_ID,P12_CATEGORY_ID:&PRODUCT_ID.,&CATEGORY_ID.'
,p_button_display_type=>'TEXT'
,p_is_hot=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(33829157399633289641)
,p_plug_name=>'Promo'
,p_region_css_classes=>'promo'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--stacked:t-Region--scrollBody:margin-top-none'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>70
,p_plug_source=>'<h2 class="region-title "> Special Prices </h1>'
,p_plug_display_condition_type=>'FUNCTION_BODY'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_count number;',
'',
'begin',
'',
'    select count(*) into v_count from product where discount > 0;',
'            if v_count = 0 then ',
'                    return false ;',
'            else',
'                    return true;',
'             end if;       ',
'',
'end;'))
,p_plug_display_when_cond2=>'PLSQL'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(33829157621762289644)
,p_plug_name=>'promo_card'
,p_parent_plug_id=>wwv_flow_imp.id(33829157399633289641)
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--styleB'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(19471549395551504237)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT  p.product_id,',
'        p.product_name,',
'        p.unit_price,',
'        p.category_id,',
'        p.store_id,',
'        s.store_name,',
'        s.customer_id as store_owner,',
'        discount,',
'        NEW_PRICE (P.PRODUCT_ID) new_price,',
'        pi.image',
'FROM    product p',
'        join (SELECT image_id,',
'            product_id,',
'            image',
'            FROM(SELECT image_id,',
'                        product_id,',
'                        image,',
'                        Row_number()',
'                            over (',
'                            PARTITION BY product_id',
'                            ORDER BY image_id) AS rn',
'                FROM   product_images) img',
'                WHERE  rn = 1) pi',
'        ON p.product_id = pi.product_id,',
'        stores s',
'WHERE nvl(discount,0)>0',
'AND   p.store_id = s.store_id;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(33829157772322289645)
,p_region_id=>wwv_flow_imp.id(33829157621762289644)
,p_layout_type=>'GRID'
,p_grid_column_count=>5
,p_card_css_classes=>'card'
,p_title_adv_formatting=>false
,p_title_column_name=>'PRODUCT_NAME'
,p_sub_title_adv_formatting=>true
,p_sub_title_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'&DISCOUNT.% &emsp;',
'<b>&NEW_PRICE. TN </b>&emsp;',
'<s> &UNIT_PRICE. TN</s>',
'',
'',
''))
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_media_adv_formatting=>false
,p_media_source_type=>'BLOB'
,p_media_blob_column_name=>'IMAGE'
,p_media_display_position=>'FIRST'
,p_media_appearance=>'SQUARE'
,p_media_sizing=>'FIT'
,p_pk1_column_name=>'PRODUCT_ID'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(33829157898344289646)
,p_card_id=>wwv_flow_imp.id(33829157772322289645)
,p_action_type=>'FULL_CARD'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:18:&SESSION.::&DEBUG.:18:P18_PRODUCT_ID:&PRODUCT_ID.'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(38242826478790699941)
,p_card_id=>wwv_flow_imp.id(33829157772322289645)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>20
,p_label=>'Store : &STORE_NAME.'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:5:P5_STORE_ID,P5_STORE_OWNER_ID,P5_STORE_NAME:&STORE_ID.,&STORE_OWNER.,&STORE_NAME.'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'to_store'
,p_is_hot=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(34598053131423261146)
,p_card_id=>wwv_flow_imp.id(33829157772322289645)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>30
,p_label=>'add to wishlist'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'javascript:void(null);'
,p_link_attributes=>'data-id=&PRODUCT_ID.'
,p_button_display_type=>'ICON'
,p_icon_css_classes=>'fa-heart'
,p_action_css_classes=>'heart'
,p_is_hot=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(34598053248588261147)
,p_card_id=>wwv_flow_imp.id(33829157772322289645)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>40
,p_label=>'Add to Cart'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:12:&SESSION.::&DEBUG.:12:P12_PRODUCT_ID,P12_CATEGORY_ID:&PRODUCT_ID.,&CATEGORY_ID.'
,p_button_display_type=>'TEXT'
,p_is_hot=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(33829157473007289642)
,p_plug_name=>'New products'
,p_region_css_classes=>'new-products'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--stacked:t-Region--scrollBody:margin-top-none:margin-bottom-none:margin-left-none:margin-right-none'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>60
,p_plug_source=>'<h2 class="region-title">New Products</h2>'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(34598049674877261111)
,p_plug_name=>'new_product_card'
,p_region_name=>'product_card'
,p_parent_plug_id=>wwv_flow_imp.id(33829157473007289642)
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--styleB:margin-top-none:margin-bottom-none:margin-left-none:margin-right-none'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(19471549395551504237)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT  p.product_id,',
'        p.product_name,',
'        p.unit_price,',
'        p.category_id,',
'         p.store_id,',
'        s.store_name,',
'        s.customer_id as store_owner,',
'        discount,',
'        NEW_PRICE (P.PRODUCT_ID) new_price,',
'        created_at,',
'        pi.image',
'FROM    product p',
'        join (SELECT image_id,',
'            product_id,',
'            image',
'            FROM(SELECT image_id,',
'                        product_id,',
'                        image,',
'                        Row_number()',
'                            over (',
'                            PARTITION BY product_id',
'                            ORDER BY image_id) AS rn',
'                FROM   product_images) img',
'                WHERE  rn = 1) pi',
'        ON p.product_id = pi.product_id,',
'        STORES s',
'',
'WHERE   ROWNUM <= 15',
'AND    p.store_id = s.store_id',
'ORDER BY created_at DESC;',
'',
''))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows=>5
,p_plug_query_num_rows_type=>'SET'
,p_plug_query_no_data_found=>'No Products Yet !'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(34598049797400261112)
,p_region_id=>wwv_flow_imp.id(34598049674877261111)
,p_layout_type=>'GRID'
,p_grid_column_count=>5
,p_card_css_classes=>'card'
,p_title_adv_formatting=>false
,p_title_column_name=>'PRODUCT_NAME'
,p_sub_title_adv_formatting=>true
,p_sub_title_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{case DISCOUNT/}',
'{when 0/}',
'<b>&NEW_PRICE. TN</b>',
'{otherwise/}',
'&DISCOUNT.% &emsp;',
'<b>&NEW_PRICE. TN </b>&emsp;',
'<s> &UNIT_PRICE. TN</s>',
'',
'',
'{endcase/}'))
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_media_adv_formatting=>false
,p_media_source_type=>'BLOB'
,p_media_blob_column_name=>'IMAGE'
,p_media_display_position=>'FIRST'
,p_media_appearance=>'SQUARE'
,p_media_sizing=>'FIT'
,p_pk1_column_name=>'PRODUCT_ID'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(34598049881284261113)
,p_card_id=>wwv_flow_imp.id(34598049797400261112)
,p_action_type=>'FULL_CARD'
,p_display_sequence=>20
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:18:&SESSION.::&DEBUG.:18:P18_PRODUCT_ID:&PRODUCT_ID.'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(38242826263300699939)
,p_card_id=>wwv_flow_imp.id(34598049797400261112)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>30
,p_label=>'Store : &STORE_NAME.'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:5:P5_STORE_ID,P5_STORE_OWNER_ID,P5_STORE_NAME:&STORE_ID.,&STORE_OWNER.,&STORE_NAME.'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'to_store'
,p_is_hot=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(34598052586006261140)
,p_card_id=>wwv_flow_imp.id(34598049797400261112)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>40
,p_label=>'add to wishlist'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'javascript:void(null);'
,p_link_attributes=>'data-id=&PRODUCT_ID.'
,p_button_display_type=>'ICON'
,p_icon_css_classes=>'fa-heart'
,p_action_css_classes=>'heart'
,p_is_hot=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(34598052469169261139)
,p_card_id=>wwv_flow_imp.id(34598049797400261112)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>50
,p_label=>'Add to Cart'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:12:&SESSION.::&DEBUG.:12:P12_PRODUCT_ID,P12_CATEGORY_ID:&PRODUCT_ID.,&CATEGORY_ID.'
,p_button_display_type=>'TEXT'
,p_is_hot=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(33829157513602289643)
,p_plug_name=>'Recently Seen'
,p_region_css_classes=>'recent-seen'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>100
,p_plug_source=>'<h2 class="region-title"> Recently Seen Products</h2>'
,p_plug_display_condition_type=>'FUNCTION_BODY'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_count number;',
'',
'begin',
'if to_number(:USER_ID) is not null then ',
'    select count(*) into v_count from customer_activity where customer_id = to_number(:USER_ID);',
'            if v_count = 0 then ',
'                    return false ;',
'            else',
'                    return true;',
'             end if;       ',
'else ',
'return false;',
'end if ;',
'end;'))
,p_plug_display_when_cond2=>'PLSQL'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(34598051279543261127)
,p_plug_name=>'Recently_seen_card'
,p_parent_plug_id=>wwv_flow_imp.id(33829157513602289643)
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--styleB'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(19471549395551504237)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT p.product_id,',
'        p.product_name,',
'        p.unit_price,',
'        p.category_id,',
'        p.store_id,',
'        s.store_name,',
'        discount,',
'        NEW_PRICE (P.PRODUCT_ID) new_price,',
'        AMOUNT_SOLD(P.PRODUCT_ID) amount_sold,',
'        pi.image,',
'        c.customer_id,',
'        s.customer_id as store_owner',
'FROM    product p',
'        join (SELECT image_id,',
'            product_id,',
'            image',
'            FROM(SELECT image_id,',
'                        product_id,',
'                        image,',
'                        Row_number()',
'                            over (',
'                            PARTITION BY product_id',
'                            ORDER BY image_id) AS rn',
'                FROM   product_images) img',
'                WHERE  rn = 1) pi',
'        ON p.product_id = pi.product_id',
'',
'        join (select distinct customer_id,',
'                product_id',
'            from customer_activity)c',
'            on p.product_id = c.product_id,',
'        stores s',
'WHERE to_number(:USER_ID) = c.customer_id',
'AND p.store_id = s.store_id;',
'',
'',
''))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(34598051306793261128)
,p_region_id=>wwv_flow_imp.id(34598051279543261127)
,p_layout_type=>'GRID'
,p_grid_column_count=>5
,p_card_css_classes=>'card'
,p_title_adv_formatting=>false
,p_title_column_name=>'PRODUCT_NAME'
,p_sub_title_adv_formatting=>true
,p_sub_title_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{case DISCOUNT/}',
'{when 0/}',
'<b>&NEW_PRICE. TN</b>',
'{otherwise/}',
'&DISCOUNT.% &emsp;',
'<b>&NEW_PRICE. TN </b>&emsp;',
'<s> &UNIT_PRICE. TN</s>',
'',
'',
'{endcase/}'))
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_media_adv_formatting=>false
,p_media_source_type=>'BLOB'
,p_media_blob_column_name=>'IMAGE'
,p_media_display_position=>'FIRST'
,p_media_appearance=>'SQUARE'
,p_media_sizing=>'FIT'
,p_pk1_column_name=>'PRODUCT_ID'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(38242826768395699944)
,p_card_id=>wwv_flow_imp.id(34598051306793261128)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>10
,p_label=>'Store : &STORE_NAME.'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:5:P5_STORE_ID,P5_STORE_NAME,P5_STORE_OWNER_ID:&STORE_ID.,&STORE_NAME.,&STORE_OWNER.'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'to_store'
,p_is_hot=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(34598051406659261129)
,p_card_id=>wwv_flow_imp.id(34598051306793261128)
,p_action_type=>'FULL_CARD'
,p_display_sequence=>20
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:18:&SESSION.::&DEBUG.:18:P18_PRODUCT_ID:&PRODUCT_ID.'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(34598053537549261150)
,p_card_id=>wwv_flow_imp.id(34598051306793261128)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>30
,p_label=>'add to wishlist'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'javascript:void(null);'
,p_link_attributes=>'data-id=&PRODUCT_ID.'
,p_button_display_type=>'ICON'
,p_icon_css_classes=>'fa-heart-o'
,p_action_css_classes=>'heart'
,p_is_hot=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(35414744739723934201)
,p_card_id=>wwv_flow_imp.id(34598051306793261128)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>40
,p_label=>'Add to Cart'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:12:&SESSION.::&DEBUG.:12:P12_PRODUCT_ID,P12_QUANTITY:&PRODUCT_ID.,&CATEGORY_ID.'
,p_button_display_type=>'TEXT'
,p_is_hot=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(34598052615634261141)
,p_plug_name=>'Recommended for you'
,p_region_css_classes=>'recomd-products'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(19471808805460504264)
,p_plug_display_sequence=>90
,p_plug_source=>'<h2 class="region-title"> RECOMMENDED FOR YOU</h2>'
,p_plug_display_condition_type=>'FUNCTION_BODY'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    v_count number;',
'',
'begin',
'    if to_number(:USER_ID) is not null then ',
'        select count(*) into v_count from customer_activity where customer_id = to_number(:USER_ID);',
'                if v_count = 0 then ',
'                        return false ;',
'                else',
'                        return true;',
'                 end if;       ',
'    else ',
'        return false;',
'    end if ;',
'end;'))
,p_plug_display_when_cond2=>'PLSQL'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(34598052748447261142)
,p_plug_name=>'Recommended_card'
,p_parent_plug_id=>wwv_flow_imp.id(34598052615634261141)
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--styleB'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(19471549395551504237)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT p.product_id,',
'       p.product_name,',
'       p.unit_price,',
'       discount,',
'       p.store_id,',
'       s.store_name,',
'       NEW_PRICE(P.PRODUCT_ID) AS new_price,',
'       AMOUNT_SOLD(P.PRODUCT_ID) AS amount_sold,',
'       pi.image,',
'       p.category_id,',
'       s.customer_id as store_owner',
'FROM product p',
'',
'JOIN (',
'  SELECT image_id,',
'         product_id,',
'         image',
'  FROM (',
'    SELECT image_id,',
'           product_id,',
'           image,',
'           ROW_NUMBER() OVER (PARTITION BY product_id ORDER BY image_id) AS rn',
'    FROM product_images',
'  ) img',
'  WHERE rn = 1',
') pi ON p.product_id = pi.product_id,',
'stores s',
'WHERE p.category_id IN (',
'  SELECT category_id',
'  FROM product',
'  WHERE product_id IN (',
'    SELECT DISTINCT product_id',
'    FROM customer_activity',
'    WHERE customer_id = TO_NUMBER(:USER_ID)',
'  )',
')',
'AND p.product_id NOT IN (',
'  SELECT DISTINCT product_id',
'  FROM customer_activity',
'  WHERE customer_id = TO_NUMBER(:USER_ID)',
')',
'AND  s.store_id = p.store_id;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(34598052838400261143)
,p_region_id=>wwv_flow_imp.id(34598052748447261142)
,p_layout_type=>'GRID'
,p_grid_column_count=>5
,p_card_css_classes=>'card'
,p_title_adv_formatting=>false
,p_title_column_name=>'PRODUCT_NAME'
,p_sub_title_adv_formatting=>true
,p_sub_title_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{case DISCOUNT/}',
'{when 0/}',
'<b>&NEW_PRICE. TN</b>',
'{otherwise/}',
'&DISCOUNT.% &emsp;',
'<b>&NEW_PRICE. TN </b>&emsp;',
'<s> &UNIT_PRICE. TN</s>',
'',
'',
'{endcase/}'))
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_media_adv_formatting=>false
,p_media_source_type=>'BLOB'
,p_media_blob_column_name=>'IMAGE'
,p_media_display_position=>'FIRST'
,p_media_appearance=>'SQUARE'
,p_media_sizing=>'FIT'
,p_pk1_column_name=>'PRODUCT_ID'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(34598052996000261144)
,p_card_id=>wwv_flow_imp.id(34598052838400261143)
,p_action_type=>'FULL_CARD'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:18:&SESSION.::&DEBUG.:18:P18_PRODUCT_ID:&PRODUCT_ID.'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(38242826651087699943)
,p_card_id=>wwv_flow_imp.id(34598052838400261143)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>20
,p_label=>'Store : &STORE_NAME.'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:5:P5_STORE_ID,P5_STORE_NAME,P5_STORE_OWNER_ID:&STORE_ID.,&STORE_NAME.,&STORE_OWNER.'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'to_store'
,p_is_hot=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(35414744817449934202)
,p_card_id=>wwv_flow_imp.id(34598052838400261143)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>30
,p_label=>'add to wishlist'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'javascript:void(null);'
,p_link_attributes=>'data-id=&PRODUCT_ID.'
,p_button_display_type=>'ICON'
,p_icon_css_classes=>'fa-heart-o'
,p_action_css_classes=>'heart'
,p_is_hot=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(35414744942164934203)
,p_card_id=>wwv_flow_imp.id(34598052838400261143)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>40
,p_label=>'Add to Cart'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:12:&SESSION.::&DEBUG.:12:P12_PRODUCT_ID,P12_CATEGORY_ID:&PRODUCT_ID.,&CATEGORY_ID.'
,p_button_display_type=>'TEXT'
,p_is_hot=>true
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(35414747842203934232)
,p_name=>'P1_SHOPPING_CART_ITEMS'
,p_item_sequence=>30
,p_item_default=>':SHOPPING_CART_ITEMS '
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(35414749592209934249)
,p_name=>'P1_PRODUCT_ID'
,p_item_sequence=>40
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(35414745666552934210)
,p_name=>'set shopping cart header'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(34598049674877261111)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(35414747939659934233)
,p_event_id=>wwv_flow_imp.id(35414745666552934210)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// Update Badge Text',
'apex.jQuery(".js-shopping-cart-item .t-Button-badge").text(this.data.P12_SHOPPING_CART_ITEMS);',
'',
'// Update Icon',
'apex.jQuery(".js-shopping-cart-item .t-Icon").removeClass(''fa-cart-empty'').addClass(''fa-cart-full'');'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(35414748148878934235)
,p_name=>'set shopping cart header 2'
,p_event_sequence=>20
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(33829157621762289644)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>6662355588643785590
,p_default_application_id=>214711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_RSWSP'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(35414748216522934236)
,p_event_id=>wwv_flow_imp.id(35414748148878934235)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// Update Badge Text',
'apex.jQuery(".js-shopping-cart-item .t-Button-badge").text(this.data.P12_SHOPPING_CART_ITEMS);',
'',
'// Update Icon',
'apex.jQuery(".js-shopping-cart-item .t-Icon").removeClass(''fa-cart-empty'').addClass(''fa-cart-full'');'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(35414748497526934238)
,p_name=>'set shopping cart header3'
,p_event_sequence=>30
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(34598051279543261127)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(35414748554881934239)
,p_event_id=>wwv_flow_imp.id(35414748497526934238)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// Update Badge Text',
'apex.jQuery(".js-shopping-cart-item .t-Button-badge").text(this.data.P12_SHOPPING_CART_ITEMS);',
'',
'// Update Icon',
'apex.jQuery(".js-shopping-cart-item .t-Icon").removeClass(''fa-cart-empty'').addClass(''fa-cart-full'');'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(35414748786721934241)
,p_name=>'set shopping cart header 4'
,p_event_sequence=>40
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(34598052748447261142)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(35414748864986934242)
,p_event_id=>wwv_flow_imp.id(35414748786721934241)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// Update Badge Text',
'apex.jQuery(".js-shopping-cart-item .t-Button-badge").text(this.data.P12_SHOPPING_CART_ITEMS);',
'',
'// Update Icon',
'apex.jQuery(".js-shopping-cart-item .t-Icon").removeClass(''fa-cart-empty'').addClass(''fa-cart-full'');'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(35414749356165934247)
,p_name=>'wishlist'
,p_event_sequence=>50
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.heart'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_display_when_type=>'EXPRESSION'
,p_display_when_cond=>'APEX_AUTHENTICATION.IS_AUTHENTICATED'
,p_display_when_cond2=>'PLSQL'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(35414749497437934248)
,p_event_id=>wwv_flow_imp.id(35414749356165934247)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_name=>'set value'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P1_PRODUCT_ID'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'$(this.triggeringElement).data(''id'')'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(35414749669154934250)
,p_event_id=>wwv_flow_imp.id(35414749356165934247)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_name=>'add_wishlist'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'  IF APEX_AUTHENTICATION.IS_AUTHENTICATED THEN',
'    ADD_TO_WISHLIST.ADD_PRODUCT(:P1_PRODUCT_ID, to_number(:USER_ID));',
'  ELSE',
'    apex_error.add_error (',
'      p_message => ''Login first to unlock this action.'',',
'      p_display_location => apex_error.c_inline_in_notification',
'    );',
'  END IF;',
'END;',
''))
,p_attribute_02=>'P1_PRODUCT_ID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(37171144801373069204)
,p_event_id=>wwv_flow_imp.id(35414749356165934247)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'show_notification0( ''Product added to wishlist'' );'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(37730487394433642718)
,p_name=>'wishlist_error'
,p_event_sequence=>60
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.heart'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_display_when_type=>'EXPRESSION'
,p_display_when_cond=>'not APEX_AUTHENTICATION.IS_AUTHENTICATED'
,p_display_when_cond2=>'PLSQL'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(37730487923912642724)
,p_event_id=>wwv_flow_imp.id(37730487394433642718)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'show_Alert("You Must Be Authenticated Before Adding Product To Wishlist !")'
);
wwv_flow_imp.component_end;
end;
/
